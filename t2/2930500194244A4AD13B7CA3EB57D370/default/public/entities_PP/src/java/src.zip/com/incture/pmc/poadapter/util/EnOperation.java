package com.incture.pmc.poadapter.util;

public enum EnOperation {
	CREATE, RETRIEVE, UPDATE, DELETE;
}