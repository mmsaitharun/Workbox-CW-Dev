package com.incture.pmc.dto;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Saurabh
 * 
 *         PMCReportBaseDto is the Base Class for Report Download story [PMC] - Sprint 3
 */
@XmlRootElement
public abstract class PMCReportBaseDto {

}
