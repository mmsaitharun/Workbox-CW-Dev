package com.incture.pmc.services;

import javax.ejb.Local;

@Local
public interface ArchivingServiceLocal {

	void doArchiving();

}
