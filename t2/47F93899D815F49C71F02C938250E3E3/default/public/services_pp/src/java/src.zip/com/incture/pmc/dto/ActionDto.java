package com.incture.pmc.dto;

public class ActionDto {

	private String action;
	

	public String getAction() {
		return action;
	}


	public void setAction(String action) {
		this.action = action;
	}


	@Override
	public String toString() {
		return "ActionDto [action=" + action + "]";
	}
	
	
}
