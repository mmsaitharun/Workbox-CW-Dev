package com.incture.pmc.services;

import javax.ejb.Stateless;

/**
 * Session Bean implementation class InboxFacade
 */
@Stateless
public class WorkboxFacade {



	/**
	 * Default constructor. 
	 */
	public WorkboxFacade() {
		// TODO Auto-generated constructor stub
	}



}
