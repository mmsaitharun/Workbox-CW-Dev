package com.incture.pmc.entity;

/**
 * @author VINU
 */
public interface BaseDo {
	public Object getPrimaryKey();
}
