package com.incture.pmc.util;

public enum FaultStatus {

	OK, ERROR, WARNING

}
