package com.incture.pmc.reports;

import com.incture.pmc.dto.DownloadReportResponseDto;
import com.incture.pmc.dto.ReportFormattedDto;

/**
 * @author Saurabh
 *
 */
public class PDF extends File{

	@Override
	public DownloadReportResponseDto pushData(ReportFormattedDto reportFormattedDto) {
		return null;
	}
}
