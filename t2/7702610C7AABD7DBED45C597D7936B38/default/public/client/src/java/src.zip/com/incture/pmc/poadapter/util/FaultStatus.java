package com.incture.pmc.poadapter.util;

public enum FaultStatus {

	OK, ERROR, WARNING

}
