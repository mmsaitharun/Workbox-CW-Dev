package com.sap.bpm.jms.api;

import javax.jms.Message;
import javax.jms.MessageListener;

import com.sap.bpm.api.BPMFactory;

/**
 * This abstract class is intended to be sub-classed by custom implementations to specifically react on incoming messages as described in
 * the package description.
 * <p>
 * The implementations need to apply the <code>&#0064;MessageDriven</code> annotation by their own similar to the given example:
 * </p>
 * 
 * <pre>
 * &#064;MessageDriven(activationConfig = {
 *         &#064;ActivationConfigProperty(propertyName = &quot;destinationType&quot;, propertyValue = &quot;javax.jms.Topic&quot;),
 *         &#064;ActivationConfigProperty(propertyName = &quot;messageSelector&quot;, propertyValue = SELECT_EVENT_PROCESS_STARTED + &quot; OR &quot;
 *                 + SELECT_EVENT_PROCESS_COMPLETED + &quot; OR &quot; + SELECT_EVENT_PROCESS_CANCELED + &quot; OR &quot; + SELECT_EVENT_USERTASK_CREATED + &quot; OR &quot;
 *                 + SELECT_EVENT_USERTASK_COMPLETED + &quot; OR &quot; + SELECT_EVENT_USERTASK_CLAIMED + &quot; OR &quot; + SELECT_EVENT_USERTASK_CANCELED
 *                 + &quot; OR &quot; + SELECT_EVENT_USERTASK_ACTIVATED + &quot; OR &quot; + SELECT_EVENT_SERVICETASK_STARTED + &quot; OR &quot;
 *                 + SELECT_EVENT_SERVICETASK_COMPLETED + &quot; OR &quot; + SELECT_EVENT_INTERMEDIATE_MESSAGE_TRIGGERED + &quot; OR &quot;
 *                 + SELECT_EVENT_CALLACTIVITY_STARTED + &quot; OR &quot; + SELECT_EVENT_CALLACTIVITY_COMPLETED) }, mappedName = AbstractBPMMessageListener.JMS_TOPIC_NAME)
 * public class BPMEventLogTestBean extends AbstractBPMMessageListener {
 * 
 *     public BPMEventLogTestBean() {}
 * 
 *     public void onBPMEvent(final BPMEventMessage bpmEventMessage) {
 *     // process message
 *     }
 * 
 *     public void onBPMProcessEvent(final BPMProcessEventMessage bpmProcessEventMessage) {
 *     // process message
 *     };
 * 
 *     public void onBPMTaskEvent(final BPMTaskEventMessage bpmTaskEventMessage) {
 *     // process message
 *     };
 * }
 * </pre>
 */
public abstract class AbstractBPMMessageListener implements MessageListener {

    /**
     * The mappedName of the JMS topic which can be used in the &#0064;MessageDriven annotation
     */
    public static final String JMS_TOPIC_NAME = "BPMEventTopic";
    private final BPMJmsManager BPM_JMS_MANAGER = BPMFactory.getBPMJmsManager();

    /**
     * This method is always invoked on incoming BPMEventMesssages. In addition the more specific
     * {@link #onBPMProcessEvent(BPMProcessEventMessage)} or {@link #onBPMTaskEvent(BPMTaskEventMessage)} listeners are called. This allows
     * to implement different variations of generic and specific reaction on the incoming messages.
     * 
     * @param bpmEventMessage
     *            The message related to the given event.
     */
    public void onBPMEvent(final BPMEventMessage bpmEventMessage) {};

    /**
     * This method is always invoked on incoming BPMProcessEventMessage (in addition to {@link #onBPMEvent(BPMEventMessage)}). This allows
     * to specifically implement behaviour for process-related events.
     * 
     * @param bpmProcessEventMessage
     *            The message related to the given event.
     */
    public void onBPMProcessEvent(final BPMProcessEventMessage bpmProcessEventMessage) {};

    /**
     * This method is always invoked on incoming BPMTaskEventMessage (in addition to {@link #onBPMEvent(BPMEventMessage)}). This allows to
     * specifically implement behaviour for task-related events.
     * 
     * @param bpmTaskEventMessage
     *            The message related to the given event.
     */
    public void onBPMTaskEvent(final BPMTaskEventMessage bpmTaskEventMessage) {};

    @Override
    public final void onMessage(final Message message) {
        final BPMEventMessage bpmMessage = BPM_JMS_MANAGER.mapJmsMessageToBPMEventMessage(message);
        if (bpmMessage.getBPMEventType().isProcessEventType()) {
            onBPMProcessEvent((BPMProcessEventMessage) bpmMessage);
        }
        if (bpmMessage.getBPMEventType().isTaskEventType()) {
            onBPMTaskEvent((BPMTaskEventMessage) bpmMessage);
        }
        onBPMEvent(bpmMessage);
    }
}
