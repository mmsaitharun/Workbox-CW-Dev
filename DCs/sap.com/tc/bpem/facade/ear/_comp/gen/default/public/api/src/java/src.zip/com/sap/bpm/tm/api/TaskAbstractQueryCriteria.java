package com.sap.bpm.tm.api;

/**
 * Descriptor to specify query criteria for getting {@link TaskAbstract}(s) while querying using {@link TaskInstanceManager}. *
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * </p>
 * 
 * @sap.ApiForReference
 * @see TaskAbstractSortCriteria
 * @see TaskAbstractCustomAttributesCriteria
 * @see TaskAbstractStatusCriteria
 * @see TaskAbstractModelCriteria
 */
public interface TaskAbstractQueryCriteria {

}
