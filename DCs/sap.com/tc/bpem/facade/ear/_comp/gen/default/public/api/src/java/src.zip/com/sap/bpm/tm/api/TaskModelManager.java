package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.ejb.Local;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * Central access point for getting {@link TaskModel} objects. <br>
 * <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
@Local
public interface TaskModelManager {

    /**
     * Returns {@link TaskModel} for the given task model id.
     * 
     * @param taskModelId
     *            the id of the task model.
     * @return an instance of {@link TaskModel}. Returns <code>null</code> if the {@link TaskModel} for the given {@link URI} does not
     *         exist.
     * @throws BPMIllegalArgumentException
     *             if the argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public TaskModel getTaskModel(URI taskModelId) throws BPMException;

    /**
     * Returns {@link TaskModel} for the given task model id with specified language.
     * 
     * @param taskModelId
     *            the id of the task model.
     * @param language
     *            parameter of type {@link String} specifying the locale of the fetched results.
     * @return an instance of {@link TaskModel}. Returns <code>null</code> if the {@link TaskModel} for the given {@link URI} does not
     *         exist.
     * @throws BPMIllegalArgumentException
     *             if the argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public TaskModel getTaskModel(URI taskModelId, String language) throws BPMException;

    /**
     * Returns a {@link List} of {@link TaskModel}s for the searched task model name.
     * 
     * @param searchPattern
     *            Search pattern to find the task model by name. The search pattern may contain 0..n asterisks <b>*</b> which are
     *            placeholders for 0..n characters. The search has 'contains' semantic and is case-insensitive. Empty string will be equal
     *            to search with '*'. The search is based on the task model names as given for the current user's locale.
     * @return {@link List} of found {@link TaskModel}s according to the following rules:
     *         <ul>
     *         <li>Contains distinct instances of {@link TaskModel}.</li>
     *         <li>The names of the returned TaskModels are provided in the language according to the current user's locale.</li>
     *         <li>Returns an empty {@link List} in case no TaskModel with the searched name could be found.</li>
     *         <li>Never returns null.</li>
     *         </ul>
     * @throws BPMIllegalArgumentException
     *             If one of the parameter is null
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public List<TaskModel> getTaskModelsByName(String searchPattern) throws BPMException;

    /**
     * Returns a {@link List} of {@link TaskModel}s for the searched task model name.
     * 
     * @param searchPattern
     *            Search pattern to find the task model by name. The search pattern may contain 0..n asterisks <b>*</b> which are
     *            placeholders for 0..n characters. The search has 'contains' semantic and is case-insensitive. Empty string will be equal
     *            to search with '*'.
     * @param locale
     *            The search is based on the task model names as given for the specified locale.
     * @return {@link List} of found {@link TaskModel}s according to the following rules:
     *         <ul>
     *         <li>Contains distinct instances of {@link TaskModel}.</li>
     *         <li>The names of the returned TaskModels are provided in the language according to the specified locale.</li>
     *         <li>Returns an empty {@link List} in case no TaskModel with the searched name could be found.</li>
     *         <li>Never returns null.</li>
     *         </ul>
     * @throws BPMIllegalArgumentException
     *             If one of the parameter is null
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public List<TaskModel> getTaskModelsByName(String searchPattern, Locale locale) throws BPMException;

    /**
     * Returns {@link List} of {@link TaskModel}s for which task instances exist in one of the the given task statuses for the logged in
     * user.
     * 
     * @param statuses
     *            set of task status for which task models are returned. All active instances will be considered if null.
     * @return a {@link List} of {@link TaskModel}s.
     * @throws BPMException
     *             in case of any error
     */
    public List<TaskModel> getMyTaskmodels(Set<Status> statuses) throws BPMException;

    /**
     * Returns {@link List} of {@link TaskModel}s for which task instances exist in one of the the given task statuses for the logged in
     * user with specified language.
     * 
     * @param statuses
     *            set of task status for which task models are returned. All active instances will be considered if null.
     * @param language
     *            parameter of type {@link String} specifying the locale of the fetched results.
     * @return a {@link List} of {@link TaskModel}s.
     * @throws BPMException
     *             in case of any error
     */
    public List<TaskModel> getMyTaskmodels(Set<Status> statuses, String language) throws BPMException;

}
