package com.sap.bpm.tm.api;

import java.net.URI;

/**
 * A basic representation of a task model.
 * 
 * <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
public interface TaskModel {

    /**
     * Returns the unique identifier for {@link TaskModel}.
     *  
     * @return an instance of {@link URI}
     */
    public URI getId();

    /**
     * Returns the active task definition name for {@link TaskModel}.
     * 
     * @return the name of the {@link TaskModel} by which it can be identified.
     */
    public String getName();
    
    /**
     * Returns the name of the development component for {@link TaskModel}.
     * 
     * @return development component name where {@link TaskModel} is located.
     */
    public String getDcName();
    
    /**
     * Returns vendor name of the development component for {@link TaskModel}.
     * 
     * @return vendor name of the development component where {@link TaskModel} is located.
     */
    public String getDcVendor();
}
