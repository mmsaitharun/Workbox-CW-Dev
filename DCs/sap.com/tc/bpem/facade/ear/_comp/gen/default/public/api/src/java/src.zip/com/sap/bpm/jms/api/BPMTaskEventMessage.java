package com.sap.bpm.jms.api;

import java.net.URI;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.pm.api.ProcessDefinition;
import com.sap.bpm.pm.api.ProcessInstance;
import com.sap.bpm.pm.api.ProcessInstanceManager;
import com.sap.bpm.tm.api.TaskAbstract;
import com.sap.bpm.tm.api.TaskInstanceManager;

/**
 * A set of getter methods specific to {@link BPMEventType}s related to tasks. Instances of {@link BPMEventMessage} can be casted to this
 * interface in such cases:
 * 
 * <pre>
 * BPMTaskEventMessage bpmTaskEventMessage = null;
 * if (bpmEventMessage.getBPMEventType().isTaskEventType()) {
 *     bpmTaskEventMessage = (BPMTaskEventMessage) bpmEventMessage;
 *     // process message 
 * }
 * </pre>
 * <p>
 * The entities related to {@link URI}s returned by {@link #getProcessDefinitionId()}, {@link #getProcessInstanceId()} and
 * {@link #getTaskInstanceId()} can be retrieved from {@link ProcessInstanceManager} or {@link TaskInstanceManager} respectively.
 * </p>
 * 
 * @sap.ApiForReference
 */
public interface BPMTaskEventMessage extends BPMEventMessage {

    /**
     * Returns the ID of the related process definition
     * 
     * @return The {@link URI} of the {@link ProcessDefinition} related to the event
     * @throws BPMException
     *             In case of any error
     */
    public URI getProcessDefinitionId() throws BPMException;

    /**
     * Returns the ID of the related process instance
     * 
     * @return The {@link URI} of the {@link ProcessInstance} related to the event
     * @throws BPMException
     *             In case of any error
     */
    public URI getProcessInstanceId() throws BPMException;

    /**
     * Returns the ID of the related task instance
     * 
     * @return The {@link URI} of the {@link TaskAbstract} related to the event
     * @throws BPMException
     *             In case of any error
     */
    public URI getTaskInstanceId() throws BPMException;
}
