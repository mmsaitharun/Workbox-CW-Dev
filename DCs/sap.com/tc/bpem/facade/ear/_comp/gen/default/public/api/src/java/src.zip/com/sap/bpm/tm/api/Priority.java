package com.sap.bpm.tm.api;

/**
 * Represents a task priority
 * 
 */
public enum Priority {

    VERY_HIGH,

    HIGH,

    MEDIUM,

    LOW,

    VERY_LOW

}
