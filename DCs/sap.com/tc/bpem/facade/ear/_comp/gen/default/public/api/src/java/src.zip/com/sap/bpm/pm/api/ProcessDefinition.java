package com.sap.bpm.pm.api;

import java.net.URI;

/**
 * Represents one version of a process model in the process repository of SAP NetWeaver Business Process Management. A
 * {@link ProcessDefinition} can be started using the {@link ProcessStartManager}.
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
public interface ProcessDefinition {

    /**
     * Returns a unique identifier for the {@link ProcessDefinition}.
     * 
     * @return an instance of {@link URI}
     */
    public URI getId();

    /**
     * Returns the name of the {@link ProcessDefinition}.
     * 
     * @return {@link String}
     */
    public String getName();

    /**
     * Returns the process model's identifier.
     * 
     * @return the {@code URI} identifying the process model.
     */
    public URI getModelId();

    /**
     * When a process definition implements a conditional start pattern, it can not be started via the BPM Public API. It has to be started via a
     * webservice call to its start endpoint.
     * 
     * @return true if the {@link ProcessDefinition} is implementing a conditional start pattern, otherwise false
     */
    public boolean isConditionalStart();
}
