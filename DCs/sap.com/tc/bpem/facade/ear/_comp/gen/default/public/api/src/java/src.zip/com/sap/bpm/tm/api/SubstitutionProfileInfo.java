package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.Locale;

/**
 * This interface represents information about a {@link SubstitutionProfile} which is used in a {@link SubstitutionRule}.
 * <p>
 * <b>NOTE</b>: As this interface can be extended, it can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
public interface SubstitutionProfileInfo {

    /**
     * Returns identifier of the {@link SubstitutionProfileInfo}.
     * 
     * @return identifier of the {@link SubstitutionProfileInfo}.
     */
    public URI getId();

    /**
     * Returns key of the {@link SubstitutionProfileInfo}. The key of the substitution profile represents a technical name of the profile.
     * 
     * @return key of the {@link SubstitutionProfileInfo}.
     */
    public String getKey();

    /**
     * Same as {@link #getLocalizedName(Locale)}, but takes the Locale from the currently logged on user.
     * 
     * @return the localized name.
     */
    public String getLocalizedName();

    /**
     * Returns the localized name for the given Locale. If no matching localized name is available (e.g. en-US), the base localization for
     * the language (en) is used. If this is also not available, the default name set with
     * {@link SubstitutionProfile#setDefaultName(String)} is returned.
     * <p>
     * 
     * @param locale
     *            The user's Locale which should be used for retrieving the localized name
     * @return the localized name.
     */
    public String getLocalizedName(Locale locale);
}
