package com.sap.bpm.reporting.api;

/**
 * Enumeration of the supported reporting field data types. Each data type is bound to a primitive or derived XML data type defined in the
 * XML schema <a href="http://www.w3.org/2001/XMLSchema">http://www.w3.org/2001/XMLSchema</a>.
 */
public enum ReportingFieldDataType {
    /**
     * Reporting field data type bound to the primitive XML data type {@code http://www.w3.org/2001/XMLSchema#boolean}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#boolean">XML Schema Part 2: Datatypes Second Edition</a>
     */
    BOOLEAN("boolean"),
    /**
     * Reporting field data type bound to the derived XML data type {@code http://www.w3.org/2001/XMLSchema#byte}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#byte">XML Schema Part 2: Datatypes Second Edition</a>
     */
    BYTE("byte"),
    /**
     * Reporting field data type bound to the primitive XML data type {@code http://www.w3.org/2001/XMLSchema#date}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#date">XML Schema Part 2: Datatypes Second Edition</a>
     */
    DATE("date"),
    /**
     * Reporting field data type bound to the primitive XML data type {@code http://www.w3.org/2001/XMLSchema#dateTime}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#dateTime">XML Schema Part 2: Datatypes Second Edition</a>
     */
    DATETIME("dateTime"),
    /**
     * Reporting field data type bound to the primitive XML data type {@code http://www.w3.org/2001/XMLSchema#decimal}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#decimal">XML Schema Part 2: Datatypes Second Edition</a>
     */
    DECIMAL("decimal"),
    /**
     * Reporting field data type bound to the primitive XML data type {@code http://www.w3.org/2001/XMLSchema#double}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#double">XML Schema Part 2: Datatypes Second Edition</a>
     */
    DOUBLE("double"),
    /**
     * Reporting field data type bound to the primitive XML data type {@code http://www.w3.org/2001/XMLSchema#float}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#float">XML Schema Part 2: Datatypes Second Edition</a>
     */
    FLOAT("float"),
    /**
     * Reporting field data type bound to the derived XML data type {@code http://www.w3.org/2001/XMLSchema#integer}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#integer">XML Schema Part 2: Datatypes Second Edition</a>
     */
    INTEGER("integer"),
    /**
     * Reporting field data type bound to the derived XML data type {@code http://www.w3.org/2001/XMLSchema#long}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#long">XML Schema Part 2: Datatypes Second Edition</a>
     */
    LONG("long"),
    /**
     * Reporting field data type bound to the derived XML data type {@code http://www.w3.org/2001/XMLSchema#short}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#short">XML Schema Part 2: Datatypes Second Edition</a>
     */
    SHORT("short"),
    /**
     * Reporting field data type bound to the primitive XML data type {@code http://www.w3.org/2001/XMLSchema#string}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#string">XML Schema Part 2: Datatypes Second Edition</a>
     */
    STRING("string"),
    /**
     * Reporting field data type bound to the primitive XML data type {@code http://www.w3.org/2001/XMLSchema#time}.
     * 
     * @see <a href="http://www.w3.org/TR/xmlschema-2/#time">XML Schema Part 2: Datatypes Second Edition</a>
     */
    TIME("time");

    private static final String xsdNamespaceURI = "http://www.w3.org/2001/XMLSchema"; // $NON-NLS-1$
    private final String xsdName;

    private ReportingFieldDataType(final String xsdName) {
        this.xsdName = xsdName;
    }

    @Override
    public String toString() {
        final StringBuilder buffer = new StringBuilder(xsdNamespaceURI.length() + xsdName.length() + 1);
        buffer.append(xsdNamespaceURI).append('#').append(xsdName);
        return buffer.toString();
    }
}
