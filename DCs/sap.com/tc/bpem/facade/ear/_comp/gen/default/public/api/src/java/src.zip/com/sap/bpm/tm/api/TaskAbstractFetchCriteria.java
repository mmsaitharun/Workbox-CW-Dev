package com.sap.bpm.tm.api;

/**
 * A marker interface to be used when querying for tasks, i.e. {@link TaskAbstract}(s), using the {@link TaskInstanceManager}.
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * </p>
 * 
 * @sap.ApiForReference
 * @see TaskAbstractFilterCriteria
 * @see TaskAbstractOwnerCriteria
 * @see TaskAbstractSubstitutionCriteria
 * @see TaskAbstractCustomAttributesCriteria
 * @see TaskAbstractCustomAttributesOrFilterCriteria
 * @see TaskAbstractSortCriteria
 */
public interface TaskAbstractFetchCriteria {

}
