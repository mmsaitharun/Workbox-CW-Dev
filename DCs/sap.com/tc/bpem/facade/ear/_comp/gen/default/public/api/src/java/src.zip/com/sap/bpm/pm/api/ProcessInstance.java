package com.sap.bpm.pm.api;

import java.net.URI;
import java.util.Date;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.security.api.IUser;
import com.sap.security.api.UMFactory;
import com.sap.security.api.srvUser.IServiceUserFactory;

/**
 * Represents an instance of a {@link ProcessDefinition} in the process repository of SAP NetWeaver Business Process Management.
 * 
 * <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 *
 * @sap.ApiForReference
 */
public interface ProcessInstance {

    /**
     * Returns the unique identifier of the {@link ProcessInstance}.
     * 
     * @return an instance of {@link URI}
     */
    public URI getId();

    /**
     * Returns the name of the the {@link ProcessInstance}.
     * 
     * @return {@link String}
     */
    public String getName();

    /**
     * Returns the subject of the the {@link ProcessInstance}.
     * 
     * 
     * @return {@link String}, may return null
     */
    public String getSubject();

    /**
     * Returns the presentation subject of the {@link ProcessInstance}.
     * 
     * @deprecated Use {@link #getSubject()} instead to get the process subject of this {@link ProcessInstance}.
     * 
     * @return {@link String}
     */
    @Deprecated
    public String getPresentationSubject();

    /**
     * Returns the date when the {@link ProcessInstance} was started (UTC).
     * 
     * @return {@link Date}
     */
    public Date getStartDate();

    /**
     * Returns the end date of the {@link ProcessInstance} (UTC).
     * 
     * @return {@link Date} Returns <code>null</code> in case the instance is still running.
     */
    public Date getEndDate();

    /**
     * Returns the {@code ProcessModel} object identifier of the {@code ProcessDefinition} object used to instantiate this process instance.
     * 
     * @return the {@code ProcessModel} object identifier.
     */
    public URI getModelId();

    /**
     * Returns the identifier of the {@code ProcessDefinition} object corresponding to the version used to instantiate this process
     * instance.
     * 
     * @return the {@code ProcessDefinition} object identifier.
     */
    public URI getDefinitionId();

    /**
     * Returns the current status of this process instance.
     * 
     * @return the process instance status.
     */
    public ProcessStatus getStatus();

    /**
     * Returns the identifier of the process instance responsible for the creation of this process instance via a referenced sub-process
     * activity if it exists. Otherwise, {@code null} is returned. The process instances having a non-null parent process instance are
     * commonly known as sub-process instances.
     * 
     * @return the identifier of the parent {@code ProcessInstance} object or {@code null} if this process instance is not a sub-process.
     * 
     * @throws BPMIllegalAccessException
     *             if the user who requested this process instance is not authorized to access the parent instance.
     */
    public URI getParentProcessInstanceId() throws BPMException;

    /**
     * Returns the identifier of the process instance without parent process instance and responsible for the creation of this process
     * instance via one or more referenced sub-process activities if it exists. Otherwise {@code null} is returned.
     * 
     * @return the identifier of the root {@code ProcessInstance} object or {@code null} if this process instance is not a sub-process.
     * 
     * @throws BPMIllegalAccessException
     *             if the user who requested this process instance is not authorized to access the root instance.
     */
    public URI getRootProcessInstanceId() throws BPMException;

    /**
     * Returns the user who initiated the creation of this process instance. The user might be in certain case (e.g. sub-process instances)
     * a service user. The {@link IServiceUserFactory} can be used to distinguish between real users and service users.
     * 
     * @see UMFactory#getServiceUserFactory()
     * @see IServiceUserFactory#isServiceUser(IUser)
     * 
     * @return the {@code IUser} object associated to the initiator of this process instance.
     */
    public IUser getProcessInitiator();

}
