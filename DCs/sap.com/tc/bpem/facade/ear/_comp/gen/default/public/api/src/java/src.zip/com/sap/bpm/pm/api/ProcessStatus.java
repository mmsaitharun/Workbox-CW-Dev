/**
 * 
 */
package com.sap.bpm.pm.api;

/**
 * Enumerates the possible statuses for a process instance. 
 */
public enum ProcessStatus {

    /**
     * Status set when the process instance is being executed.
     */
    IN_PROGRESS,

    /**
     * Status set when the process instance completed its execution.
     */
    COMPLETED,

    /**
     * Status set when the execution of the process instance was cancelled by an administrator.
     */
    CANCELLED,

    /**
     * Status set when the execution of the process instance was suspended by an administrator.
     */
    SUSPENDED,

    /**
     * Status set when the execution of the process instance could not continue because of an error and was suspended automatically.
     */
    IN_ERROR,

    /**
     * Status set when an internal error, most likely recoverable, occurred while executing a path in the flow of the process instance.
     */
    FAILED;

}
