package com.sap.bpm.exception.api;

/**
 * This exception indicates an illegal access, most likely caused by missing authorization.
 */
public class BPMIllegalAccessException extends BPMException {

    private static final long serialVersionUID = 32202L;

    public BPMIllegalAccessException(String message, Throwable cause) {
        super(message, cause);
    }

    public BPMIllegalAccessException(String message) {
        super(message);
    }

    public BPMIllegalAccessException(Throwable cause) {
        super(cause);
    }

}
