package com.sap.bpm.pm.api;

import java.net.URI;

/**
 * Entity representing a process model. The process model is version-independent and the different model versions are represented by the
 * {@code ProcessDefinition} entity. Additionally, each {@code ProcessModel} object has a unique identifier generated when the process model
 * is created. The identifier remains the same when the process model is changed, even if the process model's name is changed. Notice that
 * if the process model is deleted and recreated, the identifier of the newly created model will be different from the identifier of the
 * deleted process model and whereas the models share the same name and the same development component, they will be represented by two
 * different {@code ProcessModel} objects.
 * <p>
 * The following schema shows the relationships between the main process-related entities in the SAP NetWeaver BPM API:
 * <blockquote>
 * <div style="display: block; vertical-align: center; margin: 1em 0 1em 0;">
 *  <div style="display: inline-block; border: solid 2px #000; text-align: center; float: left; padding: 0.5em 1em 0.5em 1em;">
 *      {@link ProcessModel}
 *      <p>
 *      (aka. Process Definition<p>
 *      in NetWeaver Administrator)
 *  </div>
 *  <div style="display: inline-block; width: 50px; border-bottom: solid 1px #000; float: left; margin-top: 2.25em;">
 *      <span style="float: left; font-height: 0.8em; padding-left: 2px;">1</span>
 *      <span style="float: right; font-height: 0.8em; padding-right: 3px;">1..n</span>
 *  </div>
 *  <div style="display: inline-block; border: solid 2px #000; text-align: center; float: left; padding: 0.5em 1em 0.5em 1em;">
 *      {@link ProcessDefinition}
 *      <p>
 *      (aka. Process Definition Version <p>
 *      in NetWeaver Administrator)
 *  </div>
 *  <div style="display: inline-block; width: 50px; border-bottom: solid 1px #000; float: left; margin-top: 2.25em;">
 *      <span style="float: left; font-height: 0.8em; padding-left: 2px;">1</span>
 *      <span style="float: right; font-height: 0.8em; padding-right: 3px;">0..n</span>
 *  </div>
 *  <div style="display: inline-block; border: solid 2px #000; text-align: center; float: left; padding: 0.5em 1em 0.5em 1em;">
 *      {@link ProcessInstance}
 *      <p>
 *      (aka. Process Instance<p>
 *      in NetWeaver Administrator)
 *  </div>
 *  <div style="display: inline-block; padding: 0.5em 1em 0.5em 1em;">
 *      &nbsp;<p>&nbsp;<p>&nbsp;
 *  </div>
 * </div>
 * </blockquote>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
public interface ProcessModel {

    /**
     * Returns the unique identifier of the process model.
     * 
     * @return the process model's identifier.
     */
    public URI getId();

    /**
     * Returns the current name of the process model. The name is taken from the active {@code ProcessDefinition} associated to this model.
     * In case no {@code ProcessDefinition} is active, the name of the latest deployed {@code ProcessDefinition} is used.
     * 
     * @return the process model's name.
     */
    public String getName();

}
