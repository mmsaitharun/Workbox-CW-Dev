package com.sap.bpm.tm.api;

import java.math.BigDecimal;
import java.util.Date;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMIllegalStateException;

/**
 * Descriptor to specify the custom attribute filter criteria matching exact values for task abstract queries.
 * <p>
 * One or more instances of this class might be instantiated with different custom attributes and values to apply them as filter arguments to the
 * method {@link TaskInstanceManager#getTaskAbstracts(com.sap.bpm.api.QueryResultParameters, TaskAbstractFetchCriteria...)}.
 * </p>
 * <p>
 * In case the same custom attribute is specified in filters multiple times, the provided filter values are connected with 'OR' logic.
 * Different custom attributes are connected with 'AND' logic. Filters related to custom attributes are combined with 'AND' logic in regards
 * to filters related to properties of a task using {@link TaskAbstractFilterCriteria}.
 * </p>
 * <p>
 * Several constructors are provided which can be utilized for a modelled custom attribute depending on its type:
 * </p>
 * <table border="1" summary="Mapping of custom attributes' datatypes to Java datatypes">
 * <tr>
 * <th>Modelled Data Type</th>
 * <th>Java Data Type</th>
 * <th>Specific Date Type based on {@link TaskAbstractCustomAttributeDateFilterType}</th>
 * </tr>
 * <tr>
 * <td>boolean</td>
 * <td>{@link Boolean}</td>
 * <td>&nbsp;</td>
 * </tr>
 * <tr>
 * <td>date</td>
 * <td>{@link Date}</td>
 * <td>{@link TaskAbstractCustomAttributeDateFilterType#DATE}</td>
 * </tr>
 * <tr>
 * <td>dateTime</td>
 * <td>{@link Date}</td>
 * <td>{@link TaskAbstractCustomAttributeDateFilterType#DATE_TIME}</td>
 * </tr>
 * <tr>
 * <td>decimal</td>
 * <td>{@link BigDecimal}</td>
 * <td>&nbsp;</td>
 * </tr>
 * <tr>
 * <td>float</td>
 * <td>{@link Float}</td>
 * <td>&nbsp;</td>
 * </tr>
 * <tr>
 * <td>integer</td>
 * <td>{@link Integer}</td>
 * <td>&nbsp;</td>
 * </tr>
 * <tr>
 * <td>string</td>
 * <td>{@link String}</td>
 * <td>&nbsp;</td>
 * </tr>
 * <tr>
 * <td>time</td>
 * <td>{@link Date}</td>
 * <td>{@link TaskAbstractCustomAttributeDateFilterType#TIME}</td>
 * </tr>
 * </table>
 * <p>
 * The following example queries for {@link TaskAbstract}s owned by the logged on user, filtered by the following logical condition: (status
 * == READY or status == RESERVED) and (orderId == "4711" or orderId == "4712")
 * </p>
 * 
 * <pre>
 * TaskAbstractFetchCriteria statusCriteria = new TaskAbstractFilterCriteria(TaskAbstractFilterProperty.STATUS, Status.READY, Status.RESERVED);
 * TaskAbstractFetchCriteria customAttributeCriteria = new TaskAbstractCustomAttributesValueFilterCriteria(&quot;orderId&quot;, &quot;4711&quot;, &quot;4712&quot;);
 * List&lt;TaskAbstract&gt; taskAbstracts = taskInstanceManager.getTaskAbstracts(null, taskAbstractOwnerCriteria, statusCriteria,
 *         customAttributeCriteria);
 * </pre>
 * <p>
 * The provided constructors are performing checks on the provided parameter values. If one of the following conditions for the provided
 * parameter values are not fulfilled, an {@link BPMIllegalArgumentException} is thrown:
 * </p>
 * <ul>
 * <li>customAttributeName must not be null</li>
 * <li>Filtering at a time is only supported for one specific data type for a given custom attribute name. The data type is specified by the
 * usage of the different constructors of this class</li>
 * <li>Filtering for a given custom attribute name at a time is only supported for either using
 * {@link TaskAbstractCustomAttributesValueFilterCriteria} or {@link TaskAbstractCustomAttributesRangeFilterCriteria}</li>
 * <li>filterValues must not be null</li>
 * </ul>
 * 
 * @sap.ApiForReference
 */
public final class TaskAbstractCustomAttributesValueFilterCriteria extends TaskAbstractCustomAttributesFilterCriteria {

    /**
     * To specify the exact type of the date as modelled in the constructor
     * {@link TaskAbstractCustomAttributesValueFilterCriteria#TaskAbstractCustomAttributesValueFilterCriteria(String, TaskAbstractCustomAttributeDateFilterType, Date...)}
     * .
     */
    public enum TaskAbstractCustomAttributeDateFilterType {
        DATE_TIME,
        DATE,
        TIME
    }

    private final String[] filterValuesString;
    private final Integer[] filterValuesInteger;
    private final Long[] filterValuesLong;
    private final Date[] filterValuesDate;
    private final Boolean[] filterValuesBoolean;
    private final BigDecimal[] filterValuesBigDecimal;
    private final Float[] filterValuesFloat;

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link String} for single and multiple values
     * combined with OR logic.
     * <p>
     * Filtering for string values usually performs exact matches for the full string. In order to execute filtering with partial matches
     * like 'contains' or 'startsWith', the asterisk '*' can be used within the filter value parameters. The asterisk '*' character can be
     * escaped with the backslash character '\'; latter can be escaped by itself.
     * </p>
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param filterValues
     *            One or more filter values for the type {@link String}
     * @throws BPMIllegalArgumentException
     *             In case of illegal arguments as described in class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     */
    public TaskAbstractCustomAttributesValueFilterCriteria(final String customAttributeName, final String... filterValues)
            throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.STRING);
        validateInputParameters(customAttributeName, filterValues);
        this.filterValuesString = filterValues;
        this.filterValuesInteger = null;
        this.filterValuesLong = null;
        this.filterValuesDate = null;
        this.filterValuesBoolean = null;
        this.filterValuesBigDecimal = null;
        this.filterValuesFloat = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link Integer} for single and multiple values
     * combined with OR logic.
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param filterValues
     *            One or more filter values for the type {@link Integer}
     * @throws BPMIllegalArgumentException
     *             In case of illegal arguments as described in class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     */
    public TaskAbstractCustomAttributesValueFilterCriteria(final String customAttributeName, final Integer... filterValues)
            throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.INTEGER);
        validateInputParameters(customAttributeName, filterValues);
        this.filterValuesString = null;
        this.filterValuesInteger = filterValues;
        this.filterValuesLong = null;
        this.filterValuesDate = null;
        this.filterValuesBoolean = null;
        this.filterValuesBigDecimal = null;
        this.filterValuesFloat = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link Long} for single and multiple values
     * combined with OR logic.
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param filterValues
     *            One or more filter values for the type {@link Long}
     * @throws BPMIllegalArgumentException
     *             In case of illegal arguments as described in class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     */
    public TaskAbstractCustomAttributesValueFilterCriteria(final String customAttributeName, final Long... filterValues)
            throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.LONG);
        validateInputParameters(customAttributeName, filterValues);
        this.filterValuesString = null;
        this.filterValuesInteger = null;
        this.filterValuesLong = filterValues;
        this.filterValuesDate = null;
        this.filterValuesBoolean = null;
        this.filterValuesBigDecimal = null;
        this.filterValuesFloat = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link Date} for single and multiple values
     * combined with OR logic.
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param dateFilterType
     *            Is required to specify the exact type of the date as modelled. Must not be null
     * @param filterValues
     *            One or more filter values for the type {@link Date}
     * @throws BPMIllegalArgumentException
     *             In case of dateFilterType is null or any other illegal arguments as described in class documentation
     *             {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     */
    public TaskAbstractCustomAttributesValueFilterCriteria(final String customAttributeName,
            final TaskAbstractCustomAttributeDateFilterType dateFilterType, final Date... filterValues) throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.convertDateFilterType(dateFilterType));
        validateInputParameters(customAttributeName, filterValues);
        this.filterValuesString = null;
        this.filterValuesInteger = null;
        this.filterValuesLong = null;
        this.filterValuesDate = filterValues;
        this.filterValuesBoolean = null;
        this.filterValuesBigDecimal = null;
        this.filterValuesFloat = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link Boolean} for single and multiple values
     * combined with OR logic.
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param filterValues
     *            One or more filter values for the type {@link Boolean}
     * @throws BPMIllegalArgumentException
     *             In case of illegal arguments as described in class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     */
    public TaskAbstractCustomAttributesValueFilterCriteria(final String customAttributeName, final Boolean... filterValues)
            throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.BOOLEAN);
        validateInputParameters(customAttributeName, filterValues);
        this.filterValuesString = null;
        this.filterValuesInteger = null;
        this.filterValuesLong = null;
        this.filterValuesDate = null;
        this.filterValuesBoolean = filterValues;
        this.filterValuesBigDecimal = null;
        this.filterValuesFloat = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link BigDecimal} for single and multiple values
     * combined with OR logic.
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param filterValues
     *            One or more filter values for the type {@link BigDecimal}
     * @throws BPMIllegalArgumentException
     *             In case of illegal arguments as described in class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     */
    public TaskAbstractCustomAttributesValueFilterCriteria(final String customAttributeName, final BigDecimal... filterValues)
            throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.DECIMAL);
        validateInputParameters(customAttributeName, filterValues);
        this.filterValuesString = null;
        this.filterValuesInteger = null;
        this.filterValuesLong = null;
        this.filterValuesDate = null;
        this.filterValuesBoolean = null;
        this.filterValuesBigDecimal = filterValues;
        this.filterValuesFloat = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link Float} for single and multiple values
     * combined with OR logic.
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param filterValues
     *            One or more filter values for the type {@link Float}
     * @throws BPMIllegalArgumentException
     *             In case of illegal arguments as described in class documentation {@link TaskAbstractCustomAttributesValueFilterCriteria}.
     */
    public TaskAbstractCustomAttributesValueFilterCriteria(final String customAttributeName, final Float... filterValues)
            throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.FLOAT);
        validateInputParameters(customAttributeName, filterValues);
        this.filterValuesString = null;
        this.filterValuesInteger = null;
        this.filterValuesLong = null;
        this.filterValuesDate = null;
        this.filterValuesBoolean = null;
        this.filterValuesBigDecimal = null;
        this.filterValuesFloat = filterValues;
    }

    protected void validateInputParameters(final String customAttributeName, final Object[] filterValues) {
        if (customAttributeName == null) {
            throw new BPMIllegalArgumentException("Custom attribute name must not be null");
        }
        if (filterValues == null) {
            throw new BPMIllegalArgumentException("filterValues must not be null");
        }
        for (final Object value : filterValues) {
            if (value == null) {
                throw new BPMIllegalArgumentException("filterValue must not be null");
            }
        }
    }


    /**
     * Returns the filter values of the custom attribute
     * 
     * @return the filter values of the custom attribute
     * @throws BPMException
     *             In case of any error
     */
    public Object[] getCustomAttributeFilterValues() throws BPMException {
        if (filterValuesString != null) {
            return filterValuesString;
        }
        if (filterValuesInteger != null) {
            return filterValuesInteger;
        }
        if (filterValuesLong != null) {
            return filterValuesLong;
        }
        if (filterValuesDate != null) {
            return filterValuesDate;
        }
        if (filterValuesBoolean != null) {
            return filterValuesBoolean;
        }
        if (filterValuesBigDecimal != null) {
            return filterValuesBigDecimal;
        }
        if (filterValuesFloat != null) {
            return filterValuesFloat;
        }
        throw new BPMIllegalStateException("Unexpectedly, no filter value has been set yet.");
    }
}
