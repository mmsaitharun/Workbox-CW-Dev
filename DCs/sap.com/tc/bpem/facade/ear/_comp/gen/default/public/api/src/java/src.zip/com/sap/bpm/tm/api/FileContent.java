package com.sap.bpm.tm.api;

import java.io.InputStream;
import java.net.URI;

/**
 * Represents a {@link FileContent} for a {@link File} attachment
 */
public interface FileContent {

    /**
     * Returns a unique identifier of the attachment.
     * 
     * @return URI
     */
    public URI getId();

    /**
     * Returns the content of the {@link Attachment} as
     * 
     * @return the content of the {@link Attachment} as input stream
     */
    public InputStream getContent();
}
