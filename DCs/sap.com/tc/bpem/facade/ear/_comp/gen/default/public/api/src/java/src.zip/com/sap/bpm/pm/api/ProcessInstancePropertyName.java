package com.sap.bpm.pm.api;

/**
 * Enumerates names of {@link ProcessInstance} properties which can be used to filter process instances while querying using
 * {@link ProcessInstanceManager}.
 */
public enum ProcessInstancePropertyName {
    /**
     * Process instance ID.
     */
    ID,

    /**
     * Process instance start date.
     */
    START_DATE,

    /**
     * Process instance end date.
     */
    END_DATE,

    /**
     * Process instance definition ID.
     */
    DEFINITION_ID,

    /**
     * Process instance status.
     */
    STATUS,

    /**
     * Parent process instance ID.
     */
    PARENT_PROCESS_INSTANCE_ID,

    /**
     * Root process instance ID.
     */
    ROOT_PROCESS_INSTANCE_ID,

    /**
     * Process instance initiator.
     */
    PROCESS_INITIATOR
}
