package com.sap.bpm.api;

import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.sap.bpm.analytics.api.AnalyticsManager;
import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.helper.api.BPMIdHelper;
import com.sap.bpm.jms.api.BPMJmsManager;
import com.sap.bpm.message.api.MessageManager;
import com.sap.bpm.pm.api.ProcessDefinitionManager;
import com.sap.bpm.pm.api.ProcessInstanceManager;
import com.sap.bpm.pm.api.ProcessModelManager;
import com.sap.bpm.pm.api.ProcessStartManager;
import com.sap.bpm.reporting.api.ReportingDataSourceManager;
import com.sap.bpm.tm.api.SubstitutionProfileManager;
import com.sap.bpm.tm.api.SubstitutionRuleManager;
import com.sap.bpm.tm.api.TaskDefinitionManager;
import com.sap.bpm.tm.api.TaskInstanceManager;
import com.sap.bpm.tm.api.TaskModelManager;

/**
 * Main access point for the SAP NetWeaver BPM Process and Task Management Facade.
 * 
 * @see ProcessDefinitionManager
 * @see ProcessInstanceManager
 * @see ProcessStartManager
 * @see TaskInstanceManager
 */
public final class BPMFactory {

    private static final String JNDI_NAME_PROCESS_MODEL_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/ProcessModelManager/com.sap.bpm.pm.api.ProcessModelManager"; // $NON-NLS-1$
    private static final String JNDI_NAME_PROCESS_DEFINITION_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/ProcessDefinitionManager/com.sap.bpm.pm.api.ProcessDefinitionManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_PROCESS_INSTANCE_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/ProcessInstanceManager/com.sap.bpm.pm.api.ProcessInstanceManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_PROCESS_START_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/ProcessStartManager/com.sap.bpm.pm.api.ProcessStartManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_TASK_INSTANCE_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/TaskInstanceManager/com.sap.bpm.tm.api.TaskInstanceManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_TASK_DEFINITION_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/TaskDefinitionManager/com.sap.bpm.tm.api.TaskDefinitionManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_TASK_MODEL_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/TaskModelManager/com.sap.bpm.tm.api.TaskModelManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_SUBSTITUTION_RULE_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/SubstitutionRuleManagerPublic/com.sap.bpm.tm.api.SubstitutionRuleManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_REPORTING_DATASOURCE_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/ReportingDataSourceManager/com.sap.bpm.reporting.api.ReportingDataSourceManager"; // $NON-NLS-1$ //$NON-NLS-1$
    private static final String JNDI_NAME_ANALYTICS_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/AnalyticsManager/com.sap.bpm.analytics.api.AnalyticsManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_BPM_ID_HELPER = "sap.com/tc~bpem~facade~ear/LOCAL/BPMIdHelper/com.sap.bpm.helper.api.BPMIdHelper"; //$NON-NLS-1$
    private static final String JNDI_NAME_MESSAGE_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/MessageManager/com.sap.bpm.message.api.MessageManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_SUBSTITUTION_PROFILE_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/SubstitutionProfileManager/com.sap.bpm.tm.api.SubstitutionProfileManager"; //$NON-NLS-1$
    private static final String JNDI_NAME_BPM_JMS_MANAGER = "sap.com/tc~bpem~facade~ear/LOCAL/BPMJmsManager/com.sap.bpm.jms.api.BPMJmsManager"; //$NON-NLS-1$

    // private constructor to avoid instantiation of this class. Do not remove
    private BPMFactory() {}

    /**
     * Provides access to the {@link ProcessModelManager}.
     * 
     * @return an instance of {@link ProcessModelManager}.
     * @throws BPMException
     *             if it cannot instantiate an instance of {@code ProcessModelManager}.
     */
    public static ProcessModelManager getProcessModelManager() throws BPMException {
        return lookup(JNDI_NAME_PROCESS_MODEL_MANAGER, ProcessModelManager.class);
    }

    /**
     * Provides access to the {@link ProcessDefinitionManager}
     * 
     * @return an instance of {@link ProcessDefinitionManager}
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link ProcessDefinitionManager}
     */
    public static ProcessDefinitionManager getProcessDefinitionManager() throws BPMException {
        return lookup(JNDI_NAME_PROCESS_DEFINITION_MANAGER, ProcessDefinitionManager.class);
    }

    /**
     * Provides access to the {@link ProcessInstanceManager}
     * 
     * @return an instance of {@link ProcessInstanceManager}
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link ProcessInstanceManager}
     */
    public static ProcessInstanceManager getProcessInstanceManager() throws BPMException {
        return lookup(JNDI_NAME_PROCESS_INSTANCE_MANAGER, ProcessInstanceManager.class);
    }

    /**
     * Provides access to the {@link ProcessStartManager}
     * 
     * @return an instance of {@link ProcessStartManager}
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link ProcessStartManager}
     */
    public static ProcessStartManager getProcessStartManager() throws BPMException {
        return lookup(JNDI_NAME_PROCESS_START_MANAGER, ProcessStartManager.class);
    }

    /**
     * Provides access to the {@link TaskInstanceManager}
     * 
     * @return an instance of {@link TaskInstanceManager}
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link TaskInstanceManager}
     */
    public static TaskInstanceManager getTaskInstanceManager() throws BPMException {
        return lookup(JNDI_NAME_TASK_INSTANCE_MANAGER, TaskInstanceManager.class);
    }

    /**
     * Provides access to the {@link TaskDefinitionManager}
     * 
     * @return an instance of {@link TaskDefinitionManager}
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link TaskDefinitionManager}
     */
    public static TaskDefinitionManager getTaskDefinitionManager() throws BPMException {
        return lookup(JNDI_NAME_TASK_DEFINITION_MANAGER, TaskDefinitionManager.class);
    }

    /**
     * Provides access to the {@link TaskModelManager}
     * 
     * @return an instance of {@link TaskModelManager}
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link TaskModelManager}
     */
    public static TaskModelManager getTaskModelManager() throws BPMException {
        return lookup(JNDI_NAME_TASK_MODEL_MANAGER, TaskModelManager.class);
    }

    /**
     * Provides access to the {@link SubstitutionRuleManager}
     * 
     * @return an instance of {@link SubstitutionRuleManager}
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link SubstitutionRuleManager}
     */
    public static SubstitutionRuleManager getSubstitutionRuleManager() throws BPMException {
        return lookup(JNDI_NAME_SUBSTITUTION_RULE_MANAGER, SubstitutionRuleManager.class);
    }

    /**
     * Provides access to the {@link ReportingDataSourceManager}.
     * 
     * @return an instance of {@link ReportingDataSourceManager}.
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link ReportingDataSourceManager}.
     */
    public static ReportingDataSourceManager getReportingDataSourceManager() throws BPMException {
        return lookup(JNDI_NAME_REPORTING_DATASOURCE_MANAGER, ReportingDataSourceManager.class);
    }

    /**
     * Provides access to the {@link AnalyticsManager}.
     * 
     * @return an instance of {@link AnalyticsManager}.
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link AnalyticsManager}
     */
    public static AnalyticsManager getAnalyticsManager() throws BPMException {
        return lookup(JNDI_NAME_ANALYTICS_MANAGER, AnalyticsManager.class);
    }

    /**
     * Provides access to the {@link BPMIdHelper}.
     * 
     * @return an instance of {@link BPMIdHelper}.
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link BPMIdHelper}
     */
    public final static BPMIdHelper getBPMIdHelper() throws BPMException {
        return lookup(JNDI_NAME_BPM_ID_HELPER, BPMIdHelper.class);
    }

    /**
     * Provides access to the {@link MessageManager}.
     * 
     * @return an instance of {@link MessageManager}.
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link MessageManager}
     */
    public final static MessageManager getMessageManager() throws BPMException {
        return lookup(JNDI_NAME_MESSAGE_MANAGER, MessageManager.class);
    }

    /**
     * Provides access to the {@link SubstitutionProfileManager}.
     * 
     * @return an instance of {@link SubstitutionProfileManager}.
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link SubstitutionProfileManager}
     */
    public final static SubstitutionProfileManager getSubstitutionProfileManager() throws BPMException {
        return lookup(JNDI_NAME_SUBSTITUTION_PROFILE_MANAGER, SubstitutionProfileManager.class);
    }

    private static <T> T lookup(String jndiName, Class<T> clazz) throws BPMException {
        try {
            Properties props = new Properties();
            props.put("domain", "true"); //$NON-NLS-1$//$NON-NLS-2$
            InitialContext initialContext = new InitialContext(props);
            Object obj = initialContext.lookup(jndiName);
            return clazz.cast(obj);
        } catch (NamingException e) {
            throw new BPMException("Unable to lookup the following component: " + clazz, e); //$NON-NLS-1$
        }
    }

    /**
     * Provides access to the {@link BPMJmsManager}.
     * 
     * @return an instance of {@link BPMJmsManager}.
     * @throws BPMException
     *             if it cannot instantiate an instance of {@link BPMJmsManager}
     */
    public final static BPMJmsManager getBPMJmsManager() throws BPMException {
        return lookup(JNDI_NAME_BPM_JMS_MANAGER, BPMJmsManager.class);
    }

}
