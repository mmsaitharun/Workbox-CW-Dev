package com.sap.bpm.reporting.api;

import java.math.BigDecimal;
import java.math.BigInteger;

import java.net.URI;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import javax.ejb.Local;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * Allows to retrieve information about the reporting data sources and reporting data source versions deployed in the system, to query them
 * and finally to search for process instances based on the process context data reported in the reporting data sources.
 * 
 * <h3>Reporting Data Source Versions and Reporting Data Sources</h3>
 * <p>
 * The reporting data source definitions are versioned. When a reporting data source definition is changed, a new version is created. The
 * corresponding reporting data source version is created during the deployment. The data created by the process definition versions
 * deployed at the same time are then stored in this reporting data source version. Consequently, the data are dispatched through several
 * reporting data source versions. To lower the development efforts, the <code>ReportingDataSourceManager</code> supports the aggregation of
 * all reporting data source versions issued from the same reporting data source definition into one reporting data source. It is however
 * only possible when only compatible changes were performed on the reporting data source definition (e.g. the datatype of the reporting
 * field {@code price} is changed from {@code float} to {@code double}).
 * <p>
 * When incompatible changes are detected, the exception {@link ReportingDataSourceNotFoundException} is thrown and the cause is an instance
 * of {@link ReportingFieldIncompatibilityException}.
 * 
 * <h3>Reporting Data Source Identifiers</h3>
 * <p>
 * The reporting data source identifier is an URI supporting two different formats depending on the type of reporting data source to
 * identify. An URI identifying a reporting data source version must be formatted as following:
 * 
 * <pre>
 * bpm://bpm.sap.com/reporting-datasource/<i>&lt;Name of the reporting data source version&gt;</i>
 * </pre>
 * 
 * where the name of the reporting data source version is the name displayed in Visual Composer or in the SAP Business Warehouse system
 * connected to the SAP NetWeaver BPM system. For example, the URI to identify the reporting data source version {@code Order_1346435787}
 * will be:
 * 
 * <pre>
 * bpm://bpm.sap.com/reporting-datasource/Order_1346435787
 * </pre>
 * 
 * An URI identifying a reporting data source must be formatted as following:
 * 
 * <pre>
 * bpm://bpm.sap.com/reporting-datasource/<i>&lt;DC vendor&gt;</i>/<i>&lt;DC name&gt;</i>/<i>&lt;Name of the reporting data source&gt;</i>
 * </pre>
 * 
 * where the name of the reporting data source is the name defined in the NetWeaver Developer Studio. For example, the URI to identify the
 * reporting data source {@code Order} defined in the development component {@code mydc/myprocess [mycompany.com]} will be:
 * 
 * <pre>
 * bpm://bpm.sap.com/reporting-datasource/mycompany.com/mydc/myprocess/Order
 * </pre>
 * 
 * <h3>Search &amp; Query Term Format</h3>
 * <p>
 * The reporting data sources search by default for field values matching exactly the searched term. For example, if the term &laquo;
 * {@code pencil} &raquo; is searched in the field {@code material}, the process instances having the values for this field set to &laquo;
 * {@code black pencil} &raquo; or &laquo; {@code pencils} &raquo; won't be returned. The wildcard characters <code>&#42;</code> - any
 * characters - or <code>&#63;</code> - one character - should be used for partial match search. The search term to return the process
 * instances from the previous example should be &laquo; <code>&#42;pencil&#63;</code> &raquo;. Finally, the text search is case sensitive.
 * For example, the search for the term &laquo; {@code pencil} &raquo; won't return process instances with the value &laquo; {@code Pencil}
 * &raquo;.
 * <p>
 * The reporting data sources also allow to search for numbers and booleans. For boolean based search, the search term must be either
 * {@code true} or {@code false}. The search uses {@link Boolean#parseBoolean(String)} to convert the search term into a boolean. For number
 * based search, the numbers must be java formatted numbers. Locale-dependent number formats are not supported. The following table
 * indicates which methods are used to parse the search term into a number according to the datatype of the field used in the search:
 * <blockquote>
 * <table summary="Parsing method depending on the datatype">
 * <tr>
 * <th align="left">Field Data Type</th>
 * <th align="left">Java Number Class</th>
 * <th align="left">Java Number Parsing Method</th>
 * </tr>
 * <tr>
 * <td>{@code BYTE}</td>
 * <td>{@code java.lang.Byte}</td>
 * <td>{@link Byte#parseByte(String)}</td>
 * </tr>
 * <tr>
 * <td>{@code SHORT}</td>
 * <td>{@code java.lang.Short}</td>
 * <td>{@link Short#parseShort(String)}</td>
 * </tr>
 * <tr>
 * <td>{@code INTEGER}</td>
 * <td>{@code java.math.BigInteger}</td>
 * <td>{@link BigInteger#BigInteger(String)}</td>
 * </tr>
 * <tr>
 * <td>{@code LONG}</td>
 * <td>{@code java.lang.Long}</td>
 * <td>{@link Long#parseLong(String)}</td>
 * </tr>
 * <tr>
 * <td>{@code FLOAT}</td>
 * <td>{@code java.lang.Float}</td>
 * <td>{@link Float#parseFloat(String)}</td>
 * </tr>
 * <tr>
 * <td>{@code DOUBLE}</td>
 * <td>{@code java.lang.Double}</td>
 * <td>{@link Double#parseDouble(String)}</td>
 * </tr>
 * <tr>
 * <td>{@code DECIMAL}</td>
 * <td>{@code java.math.BigDecimal}</td>
 * <td>{@link BigDecimal#BigDecimal(String)}</td>
 * </tr>
 * </table>
 * </blockquote>
 * 
 * <p>
 * If the term cannot be parsed into a valid number, the search method will simply return an empty set. Finally, the wildcard search for
 * numbers and boolean is supported. Search terms like &laquo; <code>163&#42;</code> &raquo; or &laquo; <code>&#42;65.5&#63;</code> &raquo;
 * are accepted.
 * 
 * <h3>Search &amp; Query Performances</h3>
 * <p>
 * The search and query performances can be controlled with different actions. First, the search in one specific reporting field is faster
 * than the search in a reporting data source. Whereas the search engine excludes the reporting fields that the datatype does not fit to the
 * searched term, the database queries are more selective when restricting the search to one reporting field. Secondly, the maximum number
 * of hits to return helps to reduce significantly the time spent by the search. It will not look for all process instances matching the
 * searched term but will stop as soon as the given maximum is reached. Finally, the data store used to search plays an important role in
 * the search performance. The business log and the event log, introduced with 7.31 SP6, are used by the search engine. The event log is
 * faster than the business log but its usage is only possible when the following conditions are met:
 * <ul>
 * <li>The searched reporting data source must be a reporting data source, not a reporting data source version.</li>
 * <li>The reporting field must be of type {@code STRING} when the methods {@link #search(URI, String, String)} or
 * {@link #search(URI, String, String, int)} are invoked with a searched term containing wildcard characters.</li>
 * <li>All reporting fields must be of type {@code STRING} when the methods {@link #search(URI, String)} or
 * {@link #search(URI, String, int)} are invoked with a searched term containing wildcard characters.</li>
 * </ul>
 * Additionally, the advanced application configuration property <code>reporting.search.restrict-to-event-log</code> must be set to {@code
 * true} to prevent the search engine to use the business log to find further hits. The same applies to the <code>query</code> methods
 * returning records matching the searched term.
 * <p>
 * The search performance can be investigated by increasing the severity to {@code INFO} for the location {@code
 * com.sap.bpm.reporting.api.ReportingDataSourceManager}. It will dump in the default trace for every search and query operations the search
 * or the query execution time together with the number of returned hits or records. For deeper performance investigations, the severity
 * should be increased to {@code INFO} for the 3 following locations:
 * <ul>
 * <li>{@code com.sap.bpem.reporting.impl.DataStore}</li>
 * <li>{@code com.sap.bpem.reporting.impl.BusinessLogDataStore}</li>
 * <li>{@code com.sap.bpem.reporting.impl.EventLogDataStore}</li>
 * </ul>
 * It will dump in the default trace the execution time spent for every search or query operations in the respective data stores. It helps
 * to find out first which data stores are used and secondly the execution time of each database operations performed by the search or query
 * methods.
 */
@Local
public interface ReportingDataSourceManager {

    /**
     * Returns all reporting data sources deployed in the system. The method is protected by the UME action <code>SAP_BPM_RDS_View</code> .
     * 
     * @return the list of deployed reporting data sources.
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_View</code>.
     */
    Collection<ReportingDataSource> getReportingDataSources() throws BPMException;

    /**
     * Returns the reporting data source identified by the given identifier. The method is protected by the UME action
     * <code>SAP_BPM_RDS_View</code>.
     * 
     * @param reportingDataSourceId
     *            a reporting data source identifier.
     * @return the identified reporting data source.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws BPMIllegalArgumentException
     *             if the given identifier is not a valid reporting data source identifier.
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_View</code>.
     */
    ReportingDataSource getReportingDataSource(URI reportingDataSourceId) throws BPMException;

    /**
     * Returns all the reporting data source versions deployed in the system and identified by the given identifier. The reporting data
     * sources are sorted by ascending last modification date. It is useful to access to all reporting data source versions when a reporting
     * data source does not exist because of incompatible changes. The method is protected by the UME action <code>SAP_BPM_RDS_View</code>.
     * 
     * @param reportingDataSourceId
     *            a reporting data source identifier.
     * @return the identified reporting data source versions.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws BPMIllegalArgumentException
     *             if the given identifier is not a valid reporting data source identifier.
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_View</code>.
     */
    List<ReportingDataSource> getReportingDataSources(URI reportingDataSourceId) throws BPMException;

    /**
     * Searches for process instances that persisted data matching the searched term in the given reporting field. The method returns the
     * identifiers of all found process instances. The method is protected by the UME action <code>SAP_BPM_RDS_Search</code> or
     * <code>SAP_BPM_RDS_Query</code>.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to search in.
     * @param reportingFieldName
     *            the name of the reporting field to search in.
     * @param term
     *            the term to search.
     * @return the identifiers of all process instances containing the searched term.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingFieldNotFoundException
     *             if no reporting field with the given name exists in the reporting data source.
     * @throws ReportingDataSourceSearchException
     *             if an error occurred during the search and caused it to fail.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid; if the reporting field name is {@code null} or empty; if the term
     *             to search is {@code null}; if the designated reporting field does not support search (see
     *             {@link ReportingField#isSearchable()}).
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Search</code> or <code>SAP_BPM_RDS_Query</code>.
     */
    Set<URI> search(URI reportingDataSourceId, String reportingFieldName, String term) throws BPMException;

    /**
     * Searches for process instances that persisted data matching the searched term in the given reporting field. The search stops as soon
     * as the maximum number of process instances to return is reached. If the maximum value is negative or equals to zero, it behaves
     * exactly like {@link #search(URI, String, String)}. The method is protected by the UME action <code>SAP_BPM_RDS_Search</code> or
     * <code>SAP_BPM_RDS_Query</code>.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to search in.
     * @param reportingFieldName
     *            the name of the reporting field to search in.
     * @param term
     *            the term to search.
     * @param maxHits
     *            the maximum number of process instances to return.
     * @return the identifiers of the process instances containing the searched term.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingFieldNotFoundException
     *             if no reporting field with the given name exists in the reporting data source.
     * @throws ReportingDataSourceSearchException
     *             if an error occurred during the search and caused it to fail.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid; if the reporting field name is {@code null} or empty; if the term
     *             to search is {@code null}; if the designated reporting field does not support search (see
     *             {@link ReportingField#isSearchable()}).
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Search</code> or <code>SAP_BPM_RDS_Query</code>.
     */
    Set<URI> search(URI reportingDataSourceId, String reportingFieldName, String term, int maxHits) throws BPMException;

    /**
     * Searches for process instances that persisted data matching the searched term in at least one reporting field of the given reporting
     * data source. The method returns the identifiers of all found process instances. The method is protected by the UME action
     * <code>SAP_BPM_RDS_Search</code> or <code>SAP_BPM_RDS_Query</code>.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to search in.
     * @param term
     *            the term to search.
     * @return the identifiers of all process instances containing the searched term.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingDataSourceSearchException
     *             if an error occurred during the search and caused it to fail.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid or if the term to search is {@code null}.
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Search</code> or <code>SAP_BPM_RDS_Query</code>.
     */
    Set<URI> search(URI reportingDataSourceId, String term) throws BPMException;

    /**
     * Searches for process instances that persisted data matching the searched term in at least one reporting field of the given reporting
     * data source. The search stops as soon as the maximum number of process instances to return is reached. If the maximum value is
     * negative or equals to zero, it behaves exactly like {@link #search(URI, String)}. The method is protected by the UME action
     * <code>SAP_BPM_RDS_Search</code> or <code>SAP_BPM_RDS_Query</code>.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to search in.
     * @param term
     *            the term to search.
     * @param maxHits
     *            the maximum number of process instances to return.
     * @return the identifiers of the process instances containing the searched term.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingDataSourceSearchException
     *             if an error occurred during the search and caused it to fail.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid or if the term to search is {@code null}.
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Search</code> or <code>SAP_BPM_RDS_Query</code>.
     */
    Set<URI> search(URI reportingDataSourceId, String term, int maxHits) throws BPMException;

    /**
     * Returns all records created in the given reporting data source by the given process instances. The method is protected by the UME
     * action <code>SAP_BPM_RDS_Query</code>.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to query.
     * @param processInstanceIds
     *            the identifiers of process instances.
     * @return a {@code ReportingResultSet} object containing the found records.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingDataSourceQueryException
     *             if an error occurred while querying the reporting data source and prevented to retrieve all records.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid or if the set of process instance identifiers is {@code null}.
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Query</code>.
     */
    ReportingResultSet query(URI reportingDataSourceId, Set<URI> processInstanceIds) throws BPMException;

    /**
     * Returns all records created in the given reporting data source by the given process instances. The method is protected by the UME
     * action <code>SAP_BPM_RDS_Query</code>.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to query.
     * @param processInstanceIds
     *            the identifiers of process instances.
     * @return a {@code ReportingResultSet} object containing the found records.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingDataSourceQueryException
     *             if an error occurred while querying the reporting data source and prevented to retrieve all records.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid; if the set of process instance identifiers is {@code null}.
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Query</code>.
     */
    ReportingResultSet query(URI reportingDataSourceId, URI... processInstanceIds) throws BPMException;

    /**
     * Queries the given reporting data source for all records containing at least the searched term in in one of the searcheable reporting
     * fields. The method is protected by the UME action <code>SAP_BPM_RDS_Query</code>.
     * <p>
     * All data fetched by the query are loaded in memory. To limit the memory consumption, ensure the term to search is very selective.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to query.
     * @param term
     *            the term to search for.
     * @return a {@code ReportingResultSet} object containing records with the searched term.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingDataSourceQueryException
     *             if an error occurred while querying the reporting data source.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid; if the term to search is {@code null}.
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Query</code>.
     */
    ReportingResultSet query(URI reportingDataSourceId, String term) throws BPMException;

    /**
     * Queries the given reporting data source for all records containing at least the searched term in in one of the searcheable reporting
     * fields. The query stops as soon as the maximum number of records to return is reached. If the maximum value is negative or equals to
     * zero, it behaves exactly like {@link #query(URI, String)}. The method is protected by the UME action <code>SAP_BPM_RDS_Query</code>.
     * <p>
     * All data fetched by the query are loaded in memory. To limit the memory consumption, ensure the term to search is very selective or
     * restrict the query to a maximum number of records.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to query.
     * @param term
     *            the term to search.
     * @param maxRecords
     *            the maximum number of records to return.
     * @return a {@code ReportingResultSet} object containing records with the searched term.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingDataSourceQueryException
     *             if an error occurred while querying the reporting data source.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid; if the term to search is {@code null}.
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Query</code>.
     */
    ReportingResultSet query(URI reportingDataSourceId, String term, int maxRecords) throws BPMException;

    /**
     * Queries the given reporting data source for all records that the value of the designated reporting field matches the term to search
     * for. The method is protected by the UME action <code>SAP_BPM_RDS_Query</code>.
     * <p>
     * All data fetched by the query are loaded in memory. To limit the memory consumption, ensure the term to search is very selective.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to query.
     * @param reportingFieldName
     *            the name of the reporting field to search in.
     * @param term
     *            the term to search.
     * @return a {@code ReportingResultSet} object containing records with the searched term.
     * @throws ReportingDataSourceQueryException
     *             if an error occurred while querying the reporting data source.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingFieldNotFoundException
     *             if the given reporting field does not exist in the reporting data source.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid; if the reporting field name is {@code null} or empty; if the term
     *             to search is {@code null}; if the designated reporting field does not support search (see
     *             {@link ReportingField#isSearchable()}).
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Query</code>.
     */
    ReportingResultSet query(URI reportingDataSourceId, String reportingFieldName, String term) throws BPMException;

    /**
     * Queries the given reporting data source for all records that the value of the designated reporting field matches the term to search
     * for. The query stops as soon as the maximum number of records to return is reached. If the maximum value is negative or equals to
     * zero, it behaves exactly like {@link #query(URI, String, String)}. The method is protected by the UME action
     * <code>SAP_BPM_RDS_Query</code>.
     * <p>
     * All data fetched by the query are loaded in memory. To limit the memory consumption, ensure the term to search is very selective or
     * restrict the query to a maximum number of records.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source to query.
     * @param reportingFieldName
     *            the name of the reporting field to search in.
     * @param term
     *            the term to search.
     * @param maxRecords
     *            the maximum number of records to return.
     * @return a {@code ReportingResultSet} object containing records with the searched term.
     * @throws ReportingDataSourceQueryException
     *             if an error occurred while querying the reporting data source.
     * @throws ReportingDataSourceNotFoundException
     *             if no reporting data source deployed in the system is identified by the given identifier.
     * @throws ReportingFieldNotFoundException
     *             if the given reporting field does not exist in the reporting data source.
     * @throws BPMIllegalArgumentException
     *             if the reporting data source identifier is not valid; if the reporting field name is {@code null} or empty; if the term
     *             to search is {@code null}; if the designated reporting field does not support search (see
     *             {@link ReportingField#isSearchable()}).
     * @throws BPMIllegalAccessException
     *             if the user is not granted with the UME action <code>SAP_BPM_RDS_Query</code>.
     */
    ReportingResultSet query(URI reportingDataSourceId, String reportingFieldName, String term, int maxRecords) throws BPMException;
}
