package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.Date;

import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * Descriptor to specify the filter criteria for task abstract queries.
 * 
 * @sap.ApiForReference
 */
public final class TaskAbstractFilterCriteria implements TaskAbstractFetchCriteria {

    private static final String NO_PROPERTY_ERROR_MSG = "Property must be specified for the filter criteria.";
    private static final String NO_VALUES_ERROR_MSG = "Value(s) must be specified for the filter criteria.";

    private final TaskAbstractFilterProperty<?> property;
    private final Object[] values;

    /**
     * <p>
     * One or more instances of this class might be instantiated with different properties and values to apply them as filter arguments to
     * the method {@link TaskInstanceManager#getTaskAbstracts(com.sap.bpm.api.QueryResultParameters, TaskAbstractFetchCriteria...)}.
     * </p>
     * <table border="1" summary="Overview on valid occurrences of the values">
     * <tr>
     * <th>Property Type</th>
     * <th>Valid occurrence of values</th>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#STATUS}</td>
     * <td>one to many values of type {@link Status}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#PRIORITY}</td>
     * <td>one to many values of type {@link Priority}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#INITIATOR}</td>
     * <td>one to many string literals representing the initiator of the task</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#MODEL_ID}</td>
     * <td>one to many values of type {@link URI} representing a TaskModelId</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#CREATED_FROM}</td>
     * <td>exactly one value of type {@link Date}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#CREATED_TO}</td>
     * <td>exactly one value of type {@link Date}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#COMPLETED_FROM}</td>
     * <td>exactly one value of type {@link Date}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#COMPLETED_TO}</td>
     * <td>exactly one value of type {@link Date}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#COMPLETION_DEADLINE_FROM}</td>
     * <td>exactly one value of type {@link Date}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#COMPLETION_DEADLINE_TO}</td>
     * <td>exactly one value of type {@link Date}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterProperty#INSTANCE_ID_GREATER}</td>
     * <td>exactly one value of type {@link URI} representing a TaskInstanceId</td>
     * </tr>
     * </table>
     * <p>
     * In case the same property type is specified multiple times, the values are connected with 'OR' logic. Different property types are
     * connected with 'AND' logic.
     * </p>
     * <p>
     * The following example queries for {@link TaskAbstract}s owned by the logged on user, filtered by the following logical condition:
     * (status == READY or status == RESERVED) and (modelId == model1 or modelId == model2)
     * </p>
     * 
     * <pre>
     * TaskAbstractFetchCriteria statusCriteria = new TaskAbstractFilterCriteria(TaskAbstractFilterProperty.STATUS, Status.READY, Status.RESERVED);
     * TaskAbstractFetchCriteria model1Criteria = new TaskAbstractFilterCriteria(TaskAbstractFilterProperty.MODEL_ID, model1);
     * TaskAbstractFetchCriteria model2Criteria = new TaskAbstractFilterCriteria(TaskAbstractFilterProperty.MODEL_ID, model2);
     * List&lt;TaskAbstract&gt; taskAbstracts = taskInstanceManager.getTaskAbstracts(null, taskAbstractOwnerCriteria, statusCriteria, model1Criteria,
     *         model2Criteria);
     * </pre>
     * 
     * @param property
     *            A constant value from {@link TaskAbstractFilterProperty}
     * @param values
     *            Depending on the property type as described in the table above
     * @param <T>
     *            The datatype depending on the values
     */
    public <T> TaskAbstractFilterCriteria(TaskAbstractFilterProperty<T> property, T... values) {
        if (property == null) {
            throw new BPMIllegalArgumentException(NO_PROPERTY_ERROR_MSG);
        }

        if (values == null || values.length == 0) {
            throw new BPMIllegalArgumentException(NO_VALUES_ERROR_MSG);
        }

        this.property = property;
        this.values = values;
    }

    public final TaskAbstractFilterProperty<?> getProperty() {
        return property;
    }

    public final Object[] getValues() {
        return values;
    }
}
