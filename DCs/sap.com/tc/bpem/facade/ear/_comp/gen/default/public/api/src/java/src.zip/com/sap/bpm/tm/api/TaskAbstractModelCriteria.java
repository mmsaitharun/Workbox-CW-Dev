package com.sap.bpm.tm.api;

import java.net.URI;

/**
 * Descriptor to specify the model for task queries
 */

public class TaskAbstractModelCriteria implements TaskAbstractQueryCriteria {

	private final URI taskModelId;

	public TaskAbstractModelCriteria(URI taskModelId) {
		this.taskModelId = taskModelId;
	}

	public URI getTaskModelId() {
		return taskModelId;
	}

}
