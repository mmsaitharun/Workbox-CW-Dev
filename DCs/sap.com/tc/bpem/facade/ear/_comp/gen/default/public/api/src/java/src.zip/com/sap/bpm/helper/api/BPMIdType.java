package com.sap.bpm.helper.api;

/**
 * <p>
 * Provides an enumeration of resources which can be identified by BPM identifiers.
 * </p>
 * <p>
 * It is typically used when converting BPM identifiers using the helper {@link BPMIdHelper}.
 * 
 * @sap.ApiForReference
 */
public enum BPMIdType {
    /*
     * Maintenance: keep this enumeration in sync with com.sap.bpem.util.IDConverter<U> and
     * com.sap.bpem.helper.impl.BPMIdHelperBean.convertToUri(String, BPMIdType)
     */
    ProcessModelId("process-model"),
    ProcessDefinitionId("process-definition"),
    ProcessInstanceId("process-instance"),
    TaskModelId("task-model"),
    TaskDefinitionId("task-definition"),
    TaskInstanceId("task-instance"),
    StartEventId("start-event"),
    SubstitutionRuleId("substitution"),
    SubstitutionProfileId("substitution-profile"),
    PrincipalId("principal"),
    NoteId("note");

    private final String namespaceExtension;

    private BPMIdType(String namespaceExtension) {
        this.namespaceExtension = namespaceExtension;
    }

    /**
     * Returns BPM Namespace Extension which corresponds to the current ID type.
     * 
     * @return the BPM Namespace Extension
     */
    public String getNamespaceExtension() {
        return namespaceExtension;
    }
}
