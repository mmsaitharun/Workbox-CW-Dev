/**
 * 
 */
package com.sap.bpm.analytics.task.api;

import java.net.URI;
import java.util.Date;

import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.tm.api.Status;
import com.sap.bpm.tm.api.TaskModel;

/**
 * Represents the status statistics for a task model during a time interval.
 */
public interface TaskStatusStatistics {

    /**
     * Returns the lower task instance creation time limit used to collect the task instances for this statistic.
     * 
     * @return the lower task instance creation time limit.
     */
    Date getStartTime();

    /**
     * Returns the upper task instance creation time limit used to collect the task instances for this statistic.
     * 
     * @return the upper task instance creation time limit.
     */
    Date getEndTime();

    /**
     * Returns the name of the task model for which these statistics are computed.
     * 
     * @return the task model name.
     */
    String getModelName();

    /**
     * Returns the identifier of the task model for which this statistic is computed.
     * 
     * @see TaskModel#getId()
     * 
     * @return the {@link URI} identifying the task model.
     */
    URI getModelId();

    /**
     * Returns the number of task instances collected for this statistic having the given status.
     * 
     * @param status
     *            a task instance status.
     * @return the number of collected task instances with the given status.
     * @throws BPMIllegalArgumentException
     *             if the given {@link Status} is not supported by the statistic.
     */
    int getInstanceCount(Status status) throws BPMIllegalArgumentException;

}
