package com.sap.bpm.tm.api;

/**
 * Custom action triggered for a {@link TaskAbstract}. <br>
 * <br>
 * 
 * @sap.ApiForReference
 */
public class CustomAction {

    private String name;

    public CustomAction(final String name) {
        this.name = name;
    }

    /**
     * Returns the name of the custom action triggered.
     * 
     * @return the name of the custom action
     */
    public String getName() {
        return this.name;
    }

    /**
     * Sets the custom action's name.
     * 
     * @param name
     *            The name of the custom action
     */
    public void setName(final String name) {
        this.name = name;
    }
}
