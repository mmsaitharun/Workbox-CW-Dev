package com.sap.bpm.message.api;

import javax.ejb.Local;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMIllegalOperationException;

import commonj.sdo.DataObject;

/**
 * <p>
 * Responsible for sending a message to BPM system. The message sent may be consumed by those relevant events which are awaiting a message
 * and has matching correlation condition. The APIs make use of the event triggers which are created for the start and intermediate events
 * while modelling the process; An event trigger abstracts or represents the service interface and the operation which gets triggered.
 * Note: Sending message to only event trigger which represents an asynchronous operation is supported.
 * </p>
 * <p>
 * Example usage: For sending a message to BPM which can be consumed by any process instance with matching correlation condition, the code
 * would look similar to
 * </p>
 * 
 * <pre>
 * MessageManager messageManager = BPMFactory.getMessageManager();
 * EventTrigger eventTrigger = messageManager.getEventTrigger(&quot;sap.com&quot;, &quot;tc&tilde;test&tilde;dc&quot;, &quot;triggerIME&quot;); //&quot;triggerIME&quot; is the event trigger name for an IME
 * DataObject dataObject = messageManager.createDataObjectForEventTrigger(eventTrigger);
 * //populate the above empty dataObject with the data before calling sendMessage
 * messageManager.sendMessage(eventTrigger, dataObject); // This call submits the message to BPM. It will be consumed by all the process(es) which are waiting at the above mentioned IME with a matching correlation condition
 * </pre>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * </p>
 */
@Local
public interface MessageManager {

    /**
     * ; Returns the {@link EventTrigger} for the given vendor name, development component name, event trigger name.
     * 
     * @param vendor
     *            the development component vendor of the event trigger to be returned (e.g. "company.com").
     * @param dcName
     *            the development component name of the event trigger to be returned (e.g. "tc~test~dc").
     * @param eventTriggerName
     *            the technical name of the event trigger to be returned (Refer the process model in design time to identify this).
     * @return an instance of {@link EventTrigger}.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid or if no {@link EventTrigger} for the given combination of vendor, dcName and eventTriggerName
     *             exists.
     * @throws BPMIllegalAccessException
     *             if the user is unauthorized to perform the operation
     */
    public EventTrigger getEventTrigger(String vendor, String dcName, String eventTriggerName) throws BPMException;

    /**
     * Returns an empty{@link DataObject} for the given event trigger; This needs to be populated with the the necessary payload before
     * calling the API to send message.
     * 
     * @param eventTrigger
     *            the event trigger for which the data object should be created.
     * @return an instance of {@link DataObject}
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is unauthorized to perform the operation
     */
    public DataObject createDataObjectForEventTrigger(EventTrigger eventTrigger) throws BPMException;

    /**
     * Sends a message to BPM system for the given {@link EventTrigger} with the data passed as input. Note: The responsibility of the
     * API is to only submit the message. It doesn't guarantee the delivery of the message to any particular process instance; The message
     * can be consumed by any process instance which matches the correlation condition. Sending message to synchronous operation is
     * not allowed via this API and will result in a {@link BPMIllegalOperationException}.
     * 
     * @param eventTrigger
     *            the event trigger which should be used to send the message.
     * @param input
     *            the actual message or payload which will be sent to BPM.<br>
     *            It must be of a supported implementation (SAP) and matching type, otherwise the method will throw a
     *            {@link BPMIllegalArgumentException}.<br>
     *            Use {@link MessageManager#createDataObjectForEventTrigger(EventTrigger)} to get a valid data object.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is unauthorized to perform the operation
     * @throws BPMIllegalOperationException
     *             if the caller wants to send a message to an event trigger which represents a synchronous operation
     */
    public void sendMessage(EventTrigger eventTrigger, DataObject input) throws BPMException;

}
