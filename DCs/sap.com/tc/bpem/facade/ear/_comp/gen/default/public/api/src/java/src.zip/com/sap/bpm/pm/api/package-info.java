package com.sap.bpm.pm.api;

/**
 * Provides classes for getting and manipulating processes.<br>
 * <br>
 * Central access point for getting and manipulating process definitions is the {@link ProcessDefinitionManager}.<br>
 * Central access point for starting process definitions is the {@link ProcessStartManager}.<br>
 * Central access point for getting and manipulating started instances is the {@link ProcessInstanceManager}.
 */

