package com.sap.bpm.jms.api;

import java.util.Date;

import javax.jms.MapMessage;
import javax.jms.Message;

import com.sap.bpm.exception.api.BPMException;

/**
 * Basic common interface for all BPM event messages. An instance of this interface can be retrieved by passing a JMS {@link Message} to
 * {@link BPMJmsManager#mapJmsMessageToBPMEventMessage(javax.jms.Message)}<br>
 * 
 * @see BPMTaskEventMessage
 * @see BPMProcessEventMessage
 * @sap.ApiForReference
 */
public interface BPMEventMessage {

    /**
     * Returns the originally received message
     * 
     * @return The originally received {@link MapMessage}
     * @throws BPMException
     *             In case of any error
     */
    public MapMessage getJmsMessage() throws BPMException;

    /**
     * Returns the type of the event
     * 
     * @return The {@link BPMEventType} of the event
     * @throws BPMException
     *             In case of any error
     */
    public BPMEventType getBPMEventType() throws BPMException;

    /**
     * Returns the timestamp of the BPMEvent
     * 
     * @return The {@link Date} of the point in time when the event occurred
     * @throws BPMException
     *             In case of any error
     */
    public Date getEventTimestamp() throws BPMException;
}
