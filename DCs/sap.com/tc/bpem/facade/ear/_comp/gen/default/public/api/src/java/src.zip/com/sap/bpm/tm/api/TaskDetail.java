package com.sap.bpm.tm.api;

import java.util.Map;
import java.util.Set;

import com.sap.security.api.IPrincipal;
import com.sap.security.api.IUser;
import commonj.sdo.DataObject;

/**
 * A detailed representation of a task instance suitable to operate upon.
 * 
 * <br>
 * <br>
 * <p><b>NOTE</b>:  As this interface can be extended, this interface can be freely used, but must not be implemented.
 */
public interface TaskDetail extends TaskAbstract {

    /**
     * 
     * @return task stakeholders
     */
    public Set<? extends IPrincipal> getTaskStakeholders();

    /**
     * 
     * @return potential owners
     */
    public Set<? extends IPrincipal> getPotentialOwners();

    /**
     * 
     * @return business administrators
     */
    public Set<? extends IPrincipal> getBusinessAdministrators();

    /**
     * 
     * @return actual owner or null if the task does not have an actual owner
     */
    public IUser getActualOwner();

    /**
     * 
     * @return notification recipients
     */
    public Set<? extends IPrincipal> getNotificationRecipients();

    /**
     * 
     * @return has potential owners
     */
    public boolean hasPotentialOwners();

    /**
     * 
     * @return a copy of the input data of the task
     */
    public DataObject getInputDataObject();

    /**
     * 
     * @return a copy of the output data of the task
     */
    public DataObject getOutputDataObject();

    /**
     * 
     * @return the faults of the task
     */
    public Map<String, Fault> getFaults();

}
