package com.sap.bpem.facade.api;

import java.io.Serializable;

public class LicenseAuditObject implements Serializable {

	private static final long serialVersionUID = 2789068900208739252L;
	
	// Fields
	private String applic;		// Comment GLAS: Wird vom GLAS vergeben 
	private String unit;		// Comment GLAS: Wird vom GLAS vergeben 
	private String per_start;	// Comment GLAS: Startdatum der Vermessung - yyyyMMdd
	private String per_end;		// Comment GLAS: Enddatum der Vermessung - yyyyMMdd
	private int obj_count;		// Comment GLAS: Anzahl von Objekten
	
	//No-Arg Constructor
	public LicenseAuditObject() {
		
	}

	// Getter
	
	public String getApplic() {
		return applic;
	}

	public String getUnit() {
		return unit;
	}

	public String getPer_start() {
		return per_start;
	}

	public String getPer_end() {
		return per_end;
	}

	public int getObj_count() {
		return obj_count;
	}

	// Setter
	
	public void setApplic(String applic) {
		this.applic = applic;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public void setPer_start(String per_start) {
		this.per_start = per_start;
	}

	public void setPer_end(String per_end) {
		this.per_end = per_end;
	}

	public void setObj_count(int obj_count) {
		this.obj_count = obj_count;
	}

}
