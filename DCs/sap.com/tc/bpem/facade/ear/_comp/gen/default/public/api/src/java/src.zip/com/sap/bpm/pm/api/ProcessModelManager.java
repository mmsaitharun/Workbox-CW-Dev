package com.sap.bpm.pm.api;

import java.net.URI;

import javax.ejb.Local;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * Central access point for getting and handling {@code ProcessModel} objects.
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
@Local
public interface ProcessModelManager {

    /**
     * Returns the process model for the given identifier.
     * 
     * @param processModelId
     *            the process model identifier
     * @return the requested {@code ProcessModel} object or {@code null} if no process model was found in the system for the given
     *         identifier.
     * @throws BPMIllegalArgumentException
     *             if the given URI is not a valid process model identifier.
     * @throws BPMIllegalAccessException
     *             if the user is not permitted to access the requested process model.
     * @throws BPMException
     *             if an error occurred and prevented to return the requested process model.
     */
    public ProcessModel getProcessModel(URI processModelId) throws BPMException;

    /**
     * Returns the {@code ProcessModel} object for the process model named {@code processName} and located in the given development
     * component.
     * <p>
     * If the process model is renamed in the design time, the method will continue to return the same {@code ProcessModel} object. The
     * process model with the given name must however have been deployed at least once in the system. If the process model is deleted in the
     * design time and a new process model is created with the same name, the method will return the {@code ProcessModel} object associated
     * to the active version named {@code processName}. If no active version could be found, it will return the {@code ProcessModel} object
     * associated to the last deployed version.
     * 
     * @param dcVendor
     *            a development component's provider (e.g. <code>sap.com</code>).
     * @param dcName
     *            a development component's name (e.g. <code>hr/leave/bpm</code> or <code>hr~leave~bpm</code>).
     * @param processName
     *            the process name defined in the design time.
     * @return the {@code ProcessModel} object or {@code null} if no process model could be found in the system.
     * @throws BPMIllegalArgumentException
     *             if one of the parameter is {@code null}.
     * @throws BPMIllegalAccessException
     *             if the user is not permitted to access the requested process model.
     * @throws BPMException
     *             if an error occurred and prevented to return the requested process model.
     */
    public ProcessModel getProcessModel(String dcVendor, String dcName, String processName) throws BPMException;
}
