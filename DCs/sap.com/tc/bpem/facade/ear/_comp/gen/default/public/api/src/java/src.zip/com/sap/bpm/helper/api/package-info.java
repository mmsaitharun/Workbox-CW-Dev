package com.sap.bpm.helper.api;

/**
 * <p>
 * The classes of this package provide helper functionality in usage of this API.
 * </p>
 * <p>
 * The {@link BPMIdHelper} provides a conversion between the URI representation and string representation, and vice versa.
 * </p>
 */

