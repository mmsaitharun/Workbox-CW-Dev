package com.sap.bpm.tm.api;

import com.sap.bpm.exception.api.BPMException;

/**
 * Exception type used for wrapping Exception raised in Substitution Rules
 * management
 */
public class SubstitutionRuleException extends BPMException {
	private static final long serialVersionUID = 7049498467836119330L;

	public SubstitutionRuleException(String message, Throwable cause) {
		super(message, cause);
	}

	public SubstitutionRuleException(String message) {
		super(message);
	}

	public SubstitutionRuleException(Throwable cause) {
		super(cause);
	}

}
