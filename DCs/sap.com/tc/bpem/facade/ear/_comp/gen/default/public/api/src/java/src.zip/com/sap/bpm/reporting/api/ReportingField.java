package com.sap.bpm.reporting.api;

/**
 * Represents a reporting field defined in a reporting data source. Reporting fields are equal when they share the same name.
 */
public interface ReportingField extends Comparable<ReportingField> {

    /**
     * Returns the reporting field name as defined in the NetWeaver Developer Studio.
     * 
     * @return the reporting field name.
     */
    public String getName();

    /**
     * Returns the reporting field data type.
     * 
     * @return the reporting field data type.
     */
    public ReportingFieldDataType getType();

    /**
     * Indicates if the field can be used to search.
     * 
     * @see ReportingDataSourceManager#search(java.net.URI, String, String)
     * @see ReportingDataSourceManager#search(java.net.URI, String, String, int)
     * 
     * @return {@code true} if the field can be used to search and {@code false} otherwise.
     */
    public boolean isSearchable();

}
