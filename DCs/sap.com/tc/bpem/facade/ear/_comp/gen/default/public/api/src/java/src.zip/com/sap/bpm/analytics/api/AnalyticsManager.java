/**
 * 
 */
package com.sap.bpm.analytics.api;

import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.ejb.Local;

import com.sap.bpm.analytics.event.api.EventStatistics;
import com.sap.bpm.analytics.process.api.ProcessDurationStatistics;
import com.sap.bpm.analytics.process.api.ProcessStatusStatistics;
import com.sap.bpm.analytics.task.api.TaskDurationStatistics;
import com.sap.bpm.analytics.task.api.TaskStatusStatistics;
import com.sap.bpm.event.api.EventType;
import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.pm.api.ProcessInstance;
import com.sap.bpm.pm.api.ProcessStatus;
import com.sap.bpm.tm.api.Status;
import com.sap.bpm.tm.api.TaskAbstract;

/**
 * <P>
 * This is the central access point for obtaining analytics information for the roles business process administrators and business task
 * administrators and system administrators. Statistics pertaining to process, task and event can be obtained here.
 * </P>
 * <P>
 * Prerequisite : <BR>
 * Prerequisite for valid usage of this API is
 * </P>
 * <UL>
 * <LI>The current user must be a Business Process Administrator or/and a Business Task Administrator for any active instances on the
 * system.</LI>
 * <LI>The current user is a super user with DISPLAY_ALL permission.</LI>
 * </UL>
 * <P>
 * The statistics provided by this interface takes into account only the process instances where the logged in user is assigned as one of
 * the business process administrators and task instances where the logged in user is assigned as one of the business task administrators.
 * Or all active instances in case of super users with DISPLAY_ALL permission. <BR>
 * The interface provides a collective status of process models irrespective of the version. The archived instances are not accounted for.
 * </P>
 * <P>
 * Moreover the process related statistics are based only on the first level active instances. This means if a process is started as a
 * subprocess, it will not be take into account as part of the count. If the same process model is used to start a first level process and a
 * referenced subprocess, only the instances that are started as first level would be accounted for in the statistics.
 * </P>
 */
@Local
public interface AnalyticsManager {

    /**
     * <p>
     * Returns the count of all active process instances in error for the currently logged-in user is a business process administrator or
     * all process instances in error in case the user has DISPLAY_ALL permission.
     * </p>
     * <p>
     * Can be used to get count of all tasks without loading the complete process instance data. Performance optimized (not
     * Collection.size()). <br>
     * Calling it will execute a COUNT statement in DB layer.
     * 
     * @return count The count of {@link ProcessInstance}s in error
     * @throws BPMException
     *             if any technical error is encountered while retrieving data.
     * @throws BPMIllegalAccessException
     *             if the user does not have required authorisation
     */
    public int getCountOfProcessesInError() throws BPMException;

    /**
     * <p>
     * Returns count of all active task instances in escalated state where the currently logged-in user is a business task administrator for
     * or all instances in escalated state in case the user has DISPLAY_ALL permission.
     * </p>
     * <p>
     * Can be used to get count of all tasks without loading the complete task data. Performance optimized (not Collection.size()). <br>
     * Calling it will execute a COUNT statement in DB layer.
     * 
     * @return count The count of {@link TaskAbstract}s escalated
     * @throws BPMException
     *             if any technical error is encountered while retrieving data.
     * @throws BPMIllegalAccessException
     *             if the user does not have required authorisation
     */
    public int getCountOfTasksEscalated() throws BPMException;

    /**
     * <p>
     * Returns count of all active task instances in error where the currently logged-in user is a business task administrator for or all
     * instances in error in case the user has DISPLAY_ALL permission.
     * </p>
     * <p>
     * Can be used to get count of all tasks without loading the complete task data. Performance optimized (not Collection.size()). <br>
     * Calling it will execute a COUNT statement in DB layer.
     * 
     * @return count The count of {@link TaskAbstract}s in error
     * @throws BPMException
     *             if any technical error is encountered while retrieving data.
     * @throws BPMIllegalAccessException
     *             if the user does not have required authorisation
     */
    public int getCountOfTasksInError() throws BPMException;

    /**
     * <p>
     * Returns count of all active task instances without actual owner where the currently logged-in user is a business task administrator
     * for or all instances without actual owner in case the user has DISPLAY_ALL permission.
     * </p>
     * <p>
     * Can be used to get count of all tasks without loading the complete task data. Performance optimized (not Collection.size()). <br>
     * Calling it will execute a COUNT statement in DB layer.
     * 
     * @return count The count of {@link TaskAbstract}s without owner
     * @throws BPMException
     *             if any technical error is encountered while retrieving data.
     * @throws BPMIllegalAccessException
     *             if the user does not have required authorisation
     */
    public int getCountOfTasksWithoutOwner() throws BPMException;

    /**
     * <P>
     * Returns the {@link List} of {@link EventStatistics} providing the count of {@link EventType} occurred between startTime and endTime.
     * The number of {@link EventStatistics} objects returned is based on the equivalent intervals possible between the startTime and
     * endTime for the period specified by the parameter intervalInMilliSeconds.
     * </P>
     * <P>
     * The events that are accounted for are the process instances and task instances for which the currently logged-in user is a business
     * process administrator or a business task administrator depending on the {@link EventType}. Or all the active process instances or
     * task instances depending on the {@link EventType} in case the user has DISPLAY_ALL permission.
     * </P>
     * 
     * @param startTime
     *            The process instance creation start time that must be considered for the statistics.
     * @param endTime
     *            The process instance creation end time that must be considered for the statistics.
     * @param events
     *            The {@link Set} of {@link EventType} for which the {@link List} of {@link EventStatistics} is returned
     * @param intervalInMilliSeconds
     *            The time interval between each {@link EventStatistics} strting from the startTime till endTime. For e.g. suppose the
     *            startTime is 12am today, endTime 6pm today and interval is 3600000ms. the count of {@link EventStatistics} would be 6.
     * @return {@link List} of {@link EventStatistics} for specified {@link EventType}s
     * @throws BPMException
     *             if any technical error is encountered while retrieving data.
     * @throws BPMIllegalArgumentException
     *             if startTime or endTime is unspecified and arguments are invalid.
     * @throws BPMIllegalAccessException
     *             if the user does not have required authorisation
     */
    public List<EventStatistics> getEventStatistics(Date startTime, Date endTime, Set<EventType> events, long intervalInMilliSeconds)
            throws BPMException;

    /**
     * <P>
     * Returns a {@link List} of {@link ProcessDurationStatistics}s sorted by process models having maximum execution time currently in the
     * specified {@link ProcessStatus}s created between the startTime and endTime specified in descending order. The startTime and endTime
     * parameters are used to limit the query for instances by creation time.
     * </P>
     * <P>
     * If {@link Set}&lt;{@link ProcessStatus}&gt; statuses is specified, only data pertaining to those statuses shall be considered. The
     * resultant {@link ProcessDurationStatistics} object shall have statistics for the provided statuses and the unspecified ones shall
     * return 0. <BR>
     * {@link Set}&lt;{@link ProcessStatus}&gt; statuses if left unspecified, takes all valid statuses into account. <BR>
     * {@link ProcessStatus}s SUSPENDED and FAILED are not supported.
     * </P>
     * 
     * @param startTime
     *            The process instance creation start time that must be considered for the statistics.
     * @param endTime
     *            The process instance creation end time that must be considered for the statistics.
     * @param status
     *            {@link Set}&lt;{@link ProcessStatus}&gt; is the set of interested &lt;{@link ProcessStatus}&gt;s to be considered for
     *            statistics. The {@link ProcessStatusStatistics} object returns 0 for all other statuses.
     * @param noOfTopProcessModels
     *            The maximum number of top process models details to return. -1 returns all relevant process models with active instances.
     *            This variable does not restrict the process model queried or sorted. The restriction is only on the number of models
     *            returned.
     * @return List {@link List} of {@link ProcessDurationStatistics}s returns a collective execution time statistics of all models, sorted
     *         in descending order by maximum of execution time of process models.
     * @throws BPMException
     *             if any technical error is encountered while retrieving data.
     * @throws BPMIllegalArgumentException
     *             if startTime or endTime is unspecified and arguments are invalid.
     * @throws BPMIllegalAccessException
     *             if the user does not have required authorisation
     */
    public List<ProcessDurationStatistics> getProcessDurationStatistics(Date startTime, Date endTime, ProcessStatus status,
            int noOfTopProcessModels) throws BPMException;

    /**
     * <P>
     * Returns a {@link List} of {@link ProcessStatusStatistics}s sorted by process models having highest number of instances currently in
     * the specified {@link ProcessStatus}s, created between the startTime and endTime specified in descending order. The startTime and
     * endTime are used to limit the query for instances by creation time.
     * </P>
     * <P>
     * If {@link Set}&lt;{@link ProcessStatus}&gt; statuses is specified, only data pertaining to those statuses would be considered. The
     * resultant object would then have statistics for the provided statuses and unspecified ones return 0. <BR>
     * {@link Set}&lt;{@link ProcessStatus}&gt; statuses if left unspecified, takes all valid statuses into account. <BR>
     * ProcessStatus.SUSPENDED and ProcessStatus.FAILED are not supported.
     * </P>
     * 
     * @param startTime
     *            The process instance creation start time that must be considered for the statistics.
     * @param endTime
     *            The process instance creation end time that must be considered for the statistics.
     * @param statuses
     *            {@link Set}&lt;{@link ProcessStatus}&gt; is the set of interested &lt;{@link ProcessStatus}&gt;s to be considered for
     *            statistics. The {@link ProcessStatusStatistics} object returns 0 for all other statuses.
     * @param maxNoOfProcessModels
     *            The maximum number of top process models details to return. -1 returns all relevant process models with active instances.
     *            This variable does not restrict the process model queried or sorted. The restriction is only on the number of models
     *            returned.
     * @return {@link List} of {@link ProcessStatusStatistics}s returns a collective statistics of all models sorted in descending order of
     *         maximum number of process models.
     * @throws BPMException
     *             if any technical error is encountered while retrieving data.
     * @throws BPMIllegalArgumentException
     *             if startTime or endTime is unspecified and arguments are invalid.
     */
    public List<ProcessStatusStatistics> getProcessStatusStatistics(Date startTime, Date endTime, Set<ProcessStatus> statuses,
            int maxNoOfProcessModels) throws BPMException;

    /**
     * <P>
     * Returns a {@link List} of {@link TaskDurationStatistics}s sorted by task models having highest number of task instances currently in
     * the specified {@link Status}, created between the startTime and endTime specified in descending order. The startTime and endTime are
     * used to limit the query for instances by creation time.
     * </P>
     * <P>
     * If {@link Set}&lt;{@link Status}&gt; statuses is specified, only data pertaining to those statuses would be considered. The resultant
     * object would then have statistics for the provided statuses and unspecified ones return 0. <BR>
     * {@link Set}&lt;{@link Status}&gt; statuses if left unspecified, takes all valid statuses into account. <BR>
     * {@link Status}s SUSPENDED and RESERVED are not supported.
     * </P>
     * 
     * @param startTime
     *            The task instance creation from time that must be considered for the statistics.
     * @param endTime
     *            The task instance creation to end time that must be considered for the statistics.
     * @param status
     *            {@link Status} to be considered for statistics.
     * @param noOfTopTaskModels
     *            The maximum number of top task models details to return. -1 returns all relevant task models with active instances. This
     *            variable does not restrict the task model queried or sorted. The restriction is only on the number of models returned.
     * @return {@link List} of {@link TaskDurationStatistics}s returns a collective execution time statistics of all task models, sorted in
     *         descending order by maximum of execution time of task models.
     * @throws BPMException
     *             if any technical error is encountered while retrieving data.
     * @throws BPMIllegalArgumentException
     *             if startTime or endTime is unspecified and arguments are invalid.
     * @throws BPMIllegalAccessException
     *             if the user does not have required authorisation
     */
    public List<TaskDurationStatistics> getTaskDurationStatistics(Date startTime, Date endTime, Status status, int noOfTopTaskModels)
            throws BPMException;

    /**
     * <P>
     * Returns a {@link List} of {@link TaskStatusStatistics}s sorted by task models having highest number of task instances currently in
     * the specified {@link Status}s, created between the startTime and endTime specified in descending order. The startTime and endTime are
     * used to limit the query for instances by creation time.
     * </P>
     * <P>
     * If {@link Set}&lt;{@link Status}&gt; statuses is specified, only data pertaining to those statuses would be considered. The resultant
     * object would then have statistics for the provided statuses and unspecified ones return 0. <BR>
     * {@link Set}&lt;{@link Status}&gt; statuses if left unspecified, takes all valid statuses into account. <BR>
     * {@link Status}s SUSPENDED and RESERVED are not supported.
     * </P>
     * 
     * @param startTime
     *            The task instance creation from time that must be considered for the statistics.
     * @param endTime
     *            The task instance creation to end time that must be considered for the statistics.
     * @param statuses
     *            {@link Set}&lt;{@link Status}&gt; is the set of interested {@link Status}s to be considered for statistics. The
     *            {@link TaskStatusStatistics} object returns 0 for all other statuses.
     * @param noOfTopTaskModels
     *            The maximum number of top task models details to return. -1 returns all relevant task models with active instances. This
     *            variable does not restrict the task model queried or sorted. The restriction is only on the number of models returned.
     * @return {@link List} of {@link TaskStatusStatistics}s returns a collective statistics of all models sorted in descending order of
     *         maximum number of task models.
     * @throws BPMException
     *             if any technical error is encountered while retrieving data.
     * @throws BPMIllegalArgumentException
     *             if startTime or endTime is unspecified and arguments are invalid.
     * @throws BPMIllegalAccessException
     *             if the user does not have required authorisation
     */
    public List<TaskStatusStatistics> getTaskStatusStatistics(Date startTime, Date endTime, Set<Status> statuses, int noOfTopTaskModels)
            throws BPMException;

}
