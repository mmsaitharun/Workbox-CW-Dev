package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.List;

import javax.ejb.Local;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMIllegalStateException;

/**
 * Central access point for working with {@link SubstitutionProfile}s.
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
@Local
public interface SubstitutionProfileManager {

    /**
     * Creates an instance of {@link SubstitutionProfile} with the specified key and {@link TaskModel} identifiers. The method creates an
     * instance of {@link SubstitutionProfile} without storing it in the database. {@link #storeProfile(SubstitutionProfile)} method has to
     * be invoked afterwards to store the {@link SubstitutionProfile} to the database.
     * 
     * @param substitutionProfileKey
     *            - key with which an instance of {@link SubstitutionProfile} should be created. The following restrictions are applied for
     *            the key value:
     *            <ul>
     *            <li>The key must not be empty</li>
     *            <li>The key must not be longer than 12 characters</li>
     *            <li>The key must not contain trailing whitespaces</li>
     *            <li>The key must be case insensitively unique among the other {@link SubstitutionProfile}s</li>
     *            </ul>
     *            The created {@link SubstitutionProfile} will always have its key in upper case.
     * @param defaultName
     *            - The default name for the given profile. The following restrictions are applied for the value:
     *            <ul>
     *            <li>The name must not be empty</li>
     *            <li>The name must not be longer than 25 characters</li>
     *            </ul>
     * @param taskModelIds
     *            - an array of {@link TaskModel} identifiers which should be added to the created {@link SubstitutionProfile}.
     * @return an instance of {@link SubstitutionProfile} with the specified key and {@link TaskModel} identifiers.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if the specified profile key does not correspond to one of the aforementioned restrictions</li>
     *             <li>if one of the {@link TaskModel} identifiers is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it
     *             is a valid BPM URI but not a {@link TaskModel} URI)</li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to create a {@link SubstitutionProfile}.
     * @throws BPMException
     *             if a technical error occurred while creating the {@link SubstitutionProfile}.
     */
    public SubstitutionProfile createProfile(String substitutionProfileKey, String defaultName, URI... taskModelIds) throws BPMException;

    /**
     * Stores the given {@link SubstitutionProfile} to the database. If a {@link SubstitutionProfile} with the same URI identifier already
     * exists in the database it will be updated. The method persists the current state of the {@link SubstitutionProfile} to the database
     * including the current value of the profile key, the default and localized names and the list of {@link TaskModel} identifiers of the
     * profile.
     * 
     * @param profile
     *            - an instance of {@link SubstitutionProfile} which should be stored or updated in the database.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if the specified instance of {@link SubstitutionProfile} is <code>null</code></li>
     *             <li>if the profile key is not case insensitively unique among the other {@link SubstitutionProfile}s</li>
     *             <li>if one of the {@link TaskModel} identifiers of the profile is invalid (e.g. it is <code>null</code>, it is not a
     *             valid BPM URI, it is a valid BPM URI but not a {@link TaskModel} URI)</li>
     *             <li>if there is no {@link TaskModel} for one of the profile's {@link TaskModel} identifiers</li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to store a {@link SubstitutionProfile}.
     * @throws BPMException
     *             if a technical error occurred while storing the {@link SubstitutionProfile}.
     */
    public void storeProfile(SubstitutionProfile profile) throws BPMException;

    /**
     * Retrieves all the {@link SubstitutionProfile}s.
     * 
     * @return {@link List} containing all the {@link SubstitutionProfile}s.
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to read {@link SubstitutionProfile}s.
     * @throws BPMException
     *             if a technical error occurred while retrieving the {@link SubstitutionProfile}s.
     */
    public List<SubstitutionProfile> getAllProfiles() throws BPMException;

    /**
     * Returns the {@link SubstitutionProfile} with the given <code>substitutionProfileId</code>.
     * 
     * @param substitutionProfileId
     *            - identifier of the {@link SubstitutionProfile} which should be returned.
     * @return an instance of {@link SubstitutionProfile}.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if the specified <code>substitutionProfileId</code> is invalid (e.g. it is <code>null</code>, it is not a valid BPM
     *             URI, it is a valid BPM URI but not a {@link SubstitutionProfile} URI)</li>
     *             <li>if there is no {@link SubstitutionProfile} for the specified <code>substitutionProfileId</code></li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to read {@link SubstitutionProfile}s.
     * @throws BPMException
     *             if a technical error occurred while reading the {@link SubstitutionProfile}.
     */
    public SubstitutionProfile getProfileById(URI substitutionProfileId) throws BPMException;

    /**
     * Returns the {@link SubstitutionProfile} with the given <code>substitutionProfileKey</code>.
     * 
     * @param substitutionProfileKey
     *            - key of the {@link SubstitutionProfile} which should be returned.
     * @return an instance of {@link SubstitutionProfile}.
     * @throws BPMIllegalArgumentException
     *             if there is no {@link SubstitutionProfile} for the specified <code>substitutionProfileKey</code>
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to read {@link SubstitutionProfile}s.
     * @throws BPMException
     *             if a technical error occurred while reading the {@link SubstitutionProfile}.
     */
    public SubstitutionProfile getProfileByKey(String substitutionProfileKey) throws BPMException;

    /**
     * Deletes the {@link SubstitutionProfile} with the given <code>substitutionProfileId</code>.
     * 
     * @param substitutionProfileId
     *            - identifier of the {@link SubstitutionProfile} which should be deleted.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if the specified <code>substitutionProfileId</code> is invalid (e.g. it is <code>null</code>, it is not a valid BPM
     *             URI, it is a valid BPM URI but not a {@link SubstitutionProfile} URI)</li>
     *             <li>if there is no {@link SubstitutionProfile} for the specified <code>substitutionProfileId</code></li>
     *             </ul>
     * @throws BPMIllegalStateException
     *             if there is a {@link SubstitutionRule} by which the {@link SubstitutionProfile} is used.
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to delete {@link SubstitutionProfile}s.
     * @throws BPMException
     *             if a technical error occurred while deleting the {@link SubstitutionProfile}.
     */
    public void deleteProfile(URI substitutionProfileId) throws BPMException;
}
