package com.sap.bpm.message.impl;

import java.io.Serializable;
import java.net.URI;

import com.sap.bpm.message.api.EventTrigger;

public class EventTriggerImpl implements EventTrigger,Serializable{

    private final URI id;
    
    private final String operationName;

    public EventTriggerImpl(URI id, String operationName) {
        this.id = id;
        this.operationName = operationName;
    }

    @Override
    public URI getId() {
        return this.id;
    }
    
    
    public String getOperationName(){
        return this.operationName;
        
    }

}
