/**
 * Provides the exceptions that can be thrown by the SAP NetWeaver BPM Process and Task Management Facade.
 * 
 */
package com.sap.bpm.exception.api;

