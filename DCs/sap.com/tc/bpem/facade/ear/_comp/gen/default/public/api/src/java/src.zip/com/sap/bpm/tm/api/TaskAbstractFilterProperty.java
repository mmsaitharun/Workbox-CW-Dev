package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.Date;

import com.sap.security.api.IUser;

/**
 * A property to create {@link TaskAbstractFilterCriteria}. There is a predefined set of instances of this class for the TaskAbstract's
 * properties, which can be used to filter while querying using
 * {@link TaskInstanceManager#getTaskAbstracts(com.sap.bpm.api.QueryResultParameters, TaskAbstractFetchCriteria...)}.
 */
public final class TaskAbstractFilterProperty<T> {

    public static final TaskAbstractFilterProperty<Status> STATUS = new TaskAbstractFilterProperty<Status>(
            TaskAbstractFilterPropertyName.STATUS);

    public static final TaskAbstractFilterProperty<Priority> PRIORITY = new TaskAbstractFilterProperty<Priority>(
            TaskAbstractFilterPropertyName.PRIORITY);

    public static final TaskAbstractFilterProperty<IUser> INITIATOR = new TaskAbstractFilterProperty<IUser>(
            TaskAbstractFilterPropertyName.INITIATOR);

    public static final TaskAbstractFilterProperty<URI> MODEL_ID = new TaskAbstractFilterProperty<URI>(
            TaskAbstractFilterPropertyName.MODEL_ID);

    public static final TaskAbstractFilterProperty<Date> CREATED_FROM = new TaskAbstractFilterProperty<Date>(
            TaskAbstractFilterPropertyName.CREATED_FROM);

    public static final TaskAbstractFilterProperty<Date> CREATED_TO = new TaskAbstractFilterProperty<Date>(
            TaskAbstractFilterPropertyName.CREATED_TO);
    
    public static final TaskAbstractFilterProperty<Date> COMPLETED_FROM = new TaskAbstractFilterProperty<Date>(
            TaskAbstractFilterPropertyName.COMPLETED_FROM);

    public static final TaskAbstractFilterProperty<Date> COMPLETED_TO = new TaskAbstractFilterProperty<Date>(
            TaskAbstractFilterPropertyName.COMPLETED_TO);

    public static final TaskAbstractFilterProperty<Date> COMPLETION_DEADLINE_FROM = new TaskAbstractFilterProperty<Date>(
            TaskAbstractFilterPropertyName.COMPLETION_DEADLINE_FROM);

    public static final TaskAbstractFilterProperty<Date> COMPLETION_DEADLINE_TO = new TaskAbstractFilterProperty<Date>(
            TaskAbstractFilterPropertyName.COMPLETION_DEADLINE_TO);

    public static final TaskAbstractFilterProperty<URI> INSTANCE_ID_GREATER = new TaskAbstractFilterProperty<URI>(
            TaskAbstractFilterPropertyName.INSTANCE_ID_GREATER);

    private final TaskAbstractFilterPropertyName propertyName;

    private TaskAbstractFilterProperty(TaskAbstractFilterPropertyName propertyName) {
        this.propertyName = propertyName;
    }

    public final TaskAbstractFilterPropertyName getPropertyName() {
        return propertyName;
    }

}
