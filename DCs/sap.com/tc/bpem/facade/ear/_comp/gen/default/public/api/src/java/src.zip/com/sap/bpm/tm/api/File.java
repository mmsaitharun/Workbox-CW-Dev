package com.sap.bpm.tm.api;

import java.net.URI;

/**
 * Represents a {@link File}
 */
public interface File extends Attachment {

    /**
     * <p>
     * Returns the size of the content in bytes.
     * 
     * @return an integer representing the size of the content in bytes, never null.
     */
    public int getSize();

    /**
     * <p>
     * Returns the MIME type of the content.
     * 
     * @return the MIME type on the content
     */
    public String getMIMEType();

    /**
     * <p>
     * Returns the name of the file.
     * </p>
     * 
     * @return the name of the file
     */
    public String getFileName();

    /**
     * <p>
     * Returns a {@link FileContent} to get the content of the Attachment{@link URI}.
     * </p>
     * 
     * @return {@link FileContent}
     */
    public FileContent getFileContent();
}
