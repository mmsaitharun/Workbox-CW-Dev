package com.sap.bpm.pm.api;

import java.net.URI;
import java.util.Date;

import com.sap.security.api.IUser;

/**
 * Represents a {@link ProcessInstance} property which should be used to create {@link ProcessInstanceFilterCriteria}. There is a predefined
 * set of instances of this class for all the process instance properties which can be used to filter process instances while querying using
 * {@link ProcessInstanceManager}.
 */
public final class ProcessInstanceProperty<T> {

    /**
     * Represents Process Instance ID property.
     */
    public static final ProcessInstanceProperty<URI> ID = new ProcessInstanceProperty<URI>(ProcessInstancePropertyName.ID);

    /**
     * Represents Process Instance Start Date property.
     */
    public static final ProcessInstanceProperty<Date> START_DATE = new ProcessInstanceProperty<Date>(ProcessInstancePropertyName.START_DATE);

    /**
     * Represents Process Instance End Date property.
     */
    public static final ProcessInstanceProperty<Date> END_DATE = new ProcessInstanceProperty<Date>(ProcessInstancePropertyName.END_DATE);

    /**
     * Represents Process Instance Definition ID property.
     */
    public static final ProcessInstanceProperty<URI> DEFINITION_ID = new ProcessInstanceProperty<URI>(
            ProcessInstancePropertyName.DEFINITION_ID);

    /**
     * Represents Process Instance Status property.
     */
    public static final ProcessInstanceProperty<ProcessStatus> STATUS = new ProcessInstanceProperty<ProcessStatus>(
            ProcessInstancePropertyName.STATUS);

    /**
     * Represents Parent Process Instance ID property.
     */
    public static final ProcessInstanceProperty<URI> PARENT_PROCESS_INSTANCE_ID = new ProcessInstanceProperty<URI>(
            ProcessInstancePropertyName.PARENT_PROCESS_INSTANCE_ID);

    /**
     * Represents Root Process Instance ID property.
     */
    public static final ProcessInstanceProperty<URI> ROOT_PROCESS_INSTANCE_ID = new ProcessInstanceProperty<URI>(
            ProcessInstancePropertyName.ROOT_PROCESS_INSTANCE_ID);

    /**
     * Represents Process Instance Initiator property.
     */
    public static final ProcessInstanceProperty<IUser> PROCESS_INITIATOR = new ProcessInstanceProperty<IUser>(
            ProcessInstancePropertyName.PROCESS_INITIATOR);

    private final ProcessInstancePropertyName name;

    private ProcessInstanceProperty(ProcessInstancePropertyName name) {
        this.name = name;
    }

    /**
     * Returns name of the process instance property represented by this class.
     * @return the name of the property
     */
    public final ProcessInstancePropertyName getName() {
        return name;
    }
}
