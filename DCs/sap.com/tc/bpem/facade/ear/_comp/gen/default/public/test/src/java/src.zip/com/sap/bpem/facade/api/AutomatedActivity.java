package com.sap.bpem.facade.api;

import java.io.Serializable;

/**
 * <p>An AutomatedActivity contains detailed information about the service to be invoked when this step
 * is been executed in a BPM process running on the server.</p>
 * <p>Currently it comprises the service interface (incl. its namespace), the operation and the endpoint
 * information (either a service group or a logical destination).</p> 
 * 
 */
public class AutomatedActivity implements Serializable{

	/**
     * Generated serial version UID
     */
	private static final long serialVersionUID = 3135106156291846562L;
	
	public String activityName, serviceInterfaceNamespace, serviceInterfaceName, operation, serviceGroupName, logicalDestination;
	
    /**
     * <p>Empty default constructor. Needed for web services.</p> 
     */
	public AutomatedActivity() {}
	
	/**
	 * <p>Constructor</p>
	 * 
	 * @param activityName				the name of the automated activity, not null
	 * @param serviceInterfaceNamespace the namespace of the service interface, not null
	 * @param serviceInterfaceName		the name of the service interface, not null
	 * @param operation					the used operation of the service interface, not null
	 * @param serviceGroupName			the used service group, might be null if a logical destination is in use
	 * @param logicalDestination		the used logical destination, might be null if a service group is in use
	 */
	public AutomatedActivity(String activityName, String serviceInterfaceNamespace, String serviceInterfaceName, String operation, String serviceGroupName, String logicalDestination) {
		this.activityName = activityName;
		this.serviceInterfaceNamespace = serviceInterfaceNamespace;
		this.serviceInterfaceName = serviceInterfaceName;
		this.operation = operation;
		this.serviceGroupName = serviceGroupName;
		this.logicalDestination = logicalDestination;
	}
}
