package com.sap.bpm.jms.api;

import javax.ejb.Local;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMIllegalStateException;

/**
 * This manager enables custom implementations to access the BPMEventTopic directly through JMS API as one of two different options as
 * described in the package description.
 * <p>
 * Consuming the BPMEventTopic requires special permissions. Please refer to the Security Guide.
 * </p>
 * <h3>Example</h3>
 * <p>
 * The following example shows the usage of JMS API and {@link BPMJmsManager} to consume BPM events from the BPMEventTopic.
 * </p>
 * <p>
 * In the first step, the BPM-related {@link TopicConnectionFactory} is acquired utilizing the BPMJmsManager. With that, a
 * {@link TopicConnection} is created and based on this, a {@link TopicSession} is instantiated:
 * </p>
 * 
 * <pre>
 * BPMJmsManager bpmJmsManager = BPMFactory.getBPMJmsManager();
 * 
 * TopicConnectionFactory jmsTopicConnectionFactory = bpmJmsManager.getBPMJmsConnectionFactory();
 * TopicConnection jmsConnection = jmsTopicConnectionFactory.createTopicConnection();
 * TopicSession jmsSession = jmsConnection.createTopicSession(false, Session.AUTO_ACKNOWLEDGE);
 * </pre>
 * <p>
 * In the next step, with help of the {@link BPMJmsManager}, the BPM-related {@link Topic} is acquired. Based on this, a subscriber is
 * created on the session. Then, with having started the connection, all configured events occurring in BPM are collected from now on:
 * </p>
 * 
 * <pre>
 * Topic jmsTopic = bpmJmsManager.getBPMJmsTopic();
 * TopicSubscriber subscriber = jmsSession.createSubscriber(jmsTopic);
 * jmsConnection.start();
 * </pre>
 * <p>
 * In the remaining step, on each call of {@link TopicSubscriber#receive(long)} one further message is fetched from the collected ones. The
 * method {@link BPMJmsManager#mapJmsMessageToBPMEventMessage(Message)} enables a convenient consumption of the message through
 * {@link BPMEventMessage}, {@link BPMTaskEventMessage} or {@link BPMProcessEventMessage} respectively.
 * </p>
 * 
 * <pre>
 * Message message = subscriber.receive(TIMEOUT);
 * BPMEventMessage bpmEventMessage = bpmJmsManager.getBPMEventMessage(message);
 * BPMTaskEventMessage bpmTaskEventMessage = null;
 * BPMProcessEventMessage bpmProcessEventMessage = null;
 * if (bpmEventMessage.getBPMEventType().isTaskEventType()) {
 *     bpmTaskEventMessage = (BPMTaskEventMessage) bpmEventMessage;
 * } else if (bpmEventMessage.getBPMEventType().isProcessEventType()) {
 *     bpmProcessEventMessage = (BPMProcessEventMessage) bpmEventMessage;
 * }
 * // ... consume bpmProcessEventMessage
 * </pre>
 * 
 * @sap.ApiForReference
 */
@Local
public interface BPMJmsManager {

    /**
     * The unique name of the specific JMS topic connection factory.
     */
    public final static String JMS_TOPIC_CONNECTION_FACTORY_NAME = "jmsfactory/SAPBPMLocal/BPMEventConnectionFactory";

    /**
     * The unique name of the specific JMS topic.
     */
    public final static String JMS_TOPIC_NAME = "jmstopics/SAPBPMLocal/BPMEventTopic";

    /**
     * Provides an instance of {@link TopicConnectionFactory} which in its turn is able to get access to the BPMEventTopic provided by
     * {@link #getBPMJmsTopic()}.
     * 
     * @return Instance of {@link TopicConnectionFactory}
     * @throws BPMException
     *             In case of any errors
     */
    public TopicConnectionFactory getBPMJmsConnectionFactory() throws BPMException;

    /**
     * Provides an instance of {@link Topic} related to the BPMEventTopic. Consumers of this topic will receive messages for configured BPM
     * Events. Use method {@link #mapJmsMessageToBPMEventMessage(Message)} for a convenient consumption of the message.
     * <p>
     * Using the BPMEventTopic requires special permissions. Please refer to the Security Guide.
     * </p>
     * 
     * @return Instance of {@link Topic}
     * @throws BPMException
     *             In case of any errors
     */
    public Topic getBPMJmsTopic() throws BPMException;

    /**
     * This method maps a {@link Message} retrieved from JMS APIs to a semantic {@link BPMEventMessage}. Depending on the type of the
     * incoming {@link BPMEventType} (provided by {@link BPMEventMessage#getBPMEventType()}) the resulting {@link BPMEventMessage} can be
     * cast to one of the even further specialized subtypes {@link BPMTaskEventMessage} or {@link BPMProcessEventMessage} respectively."
     * 
     * @param message
     *            An instance of {@link MapMessage} implementing the {@link Message} interface.
     * @return Instance of {@link BPMEventMessage} or {@code null} if {@code null} was provided for parameter {@code message}.
     * @throws BPMIllegalArgumentException
     *             In case the parameter {@code message} is not an instance of {@link MapMessage}
     * @throws BPMIllegalStateException
     *             In case the access to the properties of the provided {@link Message} cannot be retrieved
     * @throws BPMException
     *             In any other cases of errors
     */
    public BPMEventMessage mapJmsMessageToBPMEventMessage(final Message message) throws BPMException;

}
