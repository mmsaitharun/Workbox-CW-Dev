package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.List;
import java.util.Locale;

import javax.ejb.Local;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * Central access point for getting {@link TaskDefinition} objects. <br>
 * <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
@Local
public interface TaskDefinitionManager {

    /**
     * Returns the {@link TaskDefinition} for the given task definition id based on logged in user's {@link Locale}.
     * 
     * @param taskDefinitionId
     *            the id of the task definition.
     * @return an instance of {@link TaskDefinition}.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public TaskDefinition getTaskDefinition(URI taskDefinitionId) throws BPMException;

    /**
     * Returns the {@link TaskDefinition} for the given task definition id based on specified language.
     * 
     * @param taskDefinitionId
     *            the id of the task definition.
     * @param language
     *            parameter of type {@link String} specifying the locale of the fetched results.
     * @return an instance of {@link TaskDefinition}.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public TaskDefinition getTaskDefinition(URI taskDefinitionId, String language) throws BPMException;

    /**
     * Returns the active {@link TaskDefinition} for the given task model id based on logged in user's {@link Locale}.
     * 
     * @param taskModelId
     *            the id of the task model.
     * @return an instance of {@link TaskDefinition}. Returns <code>null</code> if the {@link TaskDefinition} for the given {@link URI} does
     *         not exist or none is active for this {@link URI} model id.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public TaskDefinition getActiveTaskDefinition(URI taskModelId) throws BPMException;

    /**
     * Returns the active {@link TaskDefinition} for the given task model id based on specified language.
     * 
     * @param taskModelId
     *            the id of the task model.
     * @param language
     *            parameter of type {@link String} specifying the locale of the fetched results.
     * @return an instance of {@link TaskDefinition}. Returns <code>null</code> if the {@link TaskDefinition} for the given {@link URI} does
     *         not exist or none is active for this {@link URI} model id.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public TaskDefinition getActiveTaskDefinition(URI taskModelId, String language) throws BPMException;

    /**
     * Returns all deployed {@link TaskDefinition} for the given task model id based on logged in user's {@link Locale}.
     * 
     * @param taskModelId
     *            the id of the task model.
     * @return a {@link List} of {@link TaskDefinition}.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public List<TaskDefinition> getTaskDefinitions(URI taskModelId) throws BPMException;

    /**
     * Returns all deployed {@link TaskDefinition} for the given task model id based on specified language.
     * 
     * @param taskModelId
     *            the id of the task model.
     * @param language
     *            parameter of type {@link String} specifying the locale of the fetched results.
     * @return a {@link List} of {@link TaskDefinition}.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public List<TaskDefinition> getTaskDefinitions(URI taskModelId, String language) throws BPMException;

}
