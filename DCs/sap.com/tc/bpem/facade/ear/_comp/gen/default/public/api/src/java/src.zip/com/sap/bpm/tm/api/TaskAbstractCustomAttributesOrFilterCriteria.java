package com.sap.bpm.tm.api;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * Descriptor to specify the 'OR' condition for custom attribute filter criteria related to different custom attribute names. Without
 * wrapping them with this wrapper class, different custom attribute filter criteria for different custom attribute names are connected with
 * 'AND' logic.
 * <p>
 * Using the constructor, (only) one instance of this class might be instantiated by specifying different instances of
 * {@link TaskAbstractCustomAttributesValueFilterCriteria} and/or {@link TaskAbstractCustomAttributesRangeFilterCriteria}. The instance can
 * be passed as a filter argument to the method
 * {@link TaskInstanceManager#getTaskAbstracts(com.sap.bpm.api.QueryResultParameters, TaskAbstractFetchCriteria...)}. All criteria on custom
 * attributes wrapped within an instance of this class are handled with 'OR' logic.
 * </p>
 * <p>
 * The following example queries for {@link TaskAbstract}s owned by the logged on user, filtered by the following logical condition: (status
 * == READY or status == RESERVED) and (orderId == "4711" or customerId == "0815")
 * </p>
 * 
 * <pre>
 * TaskAbstractFetchCriteria statusCriteria = new TaskAbstractFilterCriteria(TaskAbstractFilterProperty.STATUS, Status.READY, Status.RESERVED);
 * TaskAbstractFetchCriteria customAttributeCriteriaOrderId = new TaskAbstractCustomAttributesValueFilterCriteria(&quot;orderId&quot;, &quot;4711&quot;);
 * TaskAbstractFetchCriteria customAttributeCriteriaCustomerId = new TaskAbstractCustomAttributesValueFilterCriteria(&quot;customerId&quot;, &quot;0815&quot;);
 * TaskAbstractFetchCriteria customAttributeOrGroup = new TaskAbstractCustomAttributesOrFilterCriteria(customAttributeCriteriaOrderId,
 *         customAttributeCriteriaCustomerId);
 * List&lt;TaskAbstract&gt; taskAbstracts = taskInstanceManager.getTaskAbstracts(null, taskAbstractOwnerCriteria, statusCriteria,
 *         customAttributeOrGroup);
 * </pre>
 * 
 * @sap.ApiForReference
 */
public class TaskAbstractCustomAttributesOrFilterCriteria implements TaskAbstractFetchCriteria {

    private final TaskAbstractCustomAttributesFilterCriteria[] orCriteria;

    /**
     * @param taskAbstractCustomAttributesFilterCriteria
     *            One or more filter criteria to be connected with 'OR' logic
     * @throws BPMIllegalArgumentException
     *             If the argument is null
     */
    public TaskAbstractCustomAttributesOrFilterCriteria(
            final TaskAbstractCustomAttributesFilterCriteria... taskAbstractCustomAttributesFilterCriteria) throws BPMException {
        this.orCriteria = taskAbstractCustomAttributesFilterCriteria;
    }

    /**
     * Returns the criteria to be connected with 'OR' logic
     * 
     * @return the criteria to be connected with 'OR' logic
     * @throws BPMException
     *             In case of any errors
     */
    public TaskAbstractCustomAttributesFilterCriteria[] getTaskAbstractOrCriteria() throws BPMException {
        return this.orCriteria;
    }

}
