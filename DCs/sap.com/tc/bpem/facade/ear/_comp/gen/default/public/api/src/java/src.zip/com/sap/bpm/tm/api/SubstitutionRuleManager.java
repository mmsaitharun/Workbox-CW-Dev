package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.ejb.Local;

import com.sap.bpm.api.BPMFactory;
import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMIllegalStateException;
import com.sap.security.api.IUser;

/**
 * Service to define create, delete and query {@link SubstitutionRule}s.
 * <p>
 * Terminology:
 * </p>
 * <ul>
 * <li>enabled: When a rule is not enabled it is just ignored and not taken into account.</li>
 * <li>active: A rule is active when it is enabled and when the current date is between start and end date of the rule</li>
 * <li>inactive: A rule is inactive when it is disabled or when the current date is not between start and end date of the rule</li>
 * <li>substitute/substituting user: The user who is taking over</li>
 * <li>substituted user: The user whose tasks are taken over by another user</li>
 * </ul>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 * @see BPMFactory#getSubstitutionRuleManager()
 * @see TaskInstanceManager#getTaskAbstractsForAllMySubstitutedUsers(Set)
 */
@Local
public interface SubstitutionRuleManager {

    /**
     * Creates a new {@link SubstitutionRule}, but does not persist it. {@link #storeRule(SubstitutionRule)} method has to be invoked
     * afterwards to persist the {@link SubstitutionRule}.
     * 
     * @param substitutingUser
     *            must not be <code>null</code>
     * @param substitutedUser
     *            must not be <code>null</code>
     * @param mode
     *            must not be <code>null</code>
     * @param startDate
     *            must not be <code>null</code>
     * @param endDate
     *            may be <code>null</code>
     * @param enabled
     *            indicates whether the created {@link SubstitutionRule} should be enabled
     * @return the newly created {@link SubstitutionRule}
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if one of the noted as not <code>null</code> parameters is <code>null</code></li>
     *             <li>if the end date is "before" the start date</li>
     *             <li>if the substituted user and the substitute are the same person</li>
     *             </ul>
     * @throws SubstitutionRuleException
     *             if there is a problem while resolving the users
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public SubstitutionRule createRule(IUser substitutingUser, IUser substitutedUser, SubstitutionMode mode, Date startDate, Date endDate,
            boolean enabled) throws BPMException;

    /**
     * Creates a new {@link SubstitutionRule} with the {@link SubstitutionProfile} that is identified by the
     * <code>substitutionProfileId</code> parameter. Only the tasks which belong to the task models of the {@link SubstitutionProfile} will
     * be visible to the substituting user. Calling this method with <code>null</code> value for the <code>substitutionProfileId</code>
     * parameter is the same as calling {@link #createRule(IUser, IUser, SubstitutionMode, Date, Date, boolean)} method. The created
     * {@link SubstitutionRule} will not be persisted to the database. {@link #storeRule(SubstitutionRule)} method has to be invoked
     * afterwards to persist the {@link SubstitutionRule}.
     * 
     * @param substitutingUser
     *            must not be <code>null</code>
     * @param substitutedUser
     *            must not be <code>null</code>
     * @param mode
     *            must not be <code>null</code>
     * @param startDate
     *            must not be <code>null</code>
     * @param endDate
     *            may be <code>null</code>
     * @param enabled
     *            indicates whether the created {@link SubstitutionRule} should be enabled
     * @param substitutionProfileId
     *            identifier of the {@link SubstitutionProfile} which should be assigned to the created {@link SubstitutionRule}.
     *            <code>null</code> value can be specified for the parameter meaning that no profile should be assigned to the
     *            {@link SubstitutionRule}.
     * @return the newly created {@link SubstitutionRule}
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if one of the noted as not <code>null</code> parameters is <code>null</code></li>
     *             <li>if the end date is "before" the start date</li>
     *             <li>if the substituted user and the substitute are the same person</li>
     *             <li>if the specified <code>substitutionProfileId</code> is invalid (e.g. it is not a valid BPM URI, it is a valid BPM URI
     *             but not a {@link SubstitutionProfile} URI)</li>
     *             <li>if there is no {@link SubstitutionProfile} for the specified <code>substitutionProfileId</code></li>
     *             </ul>
     * @throws SubstitutionRuleException
     *             if there is a problem while resolving the users
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public SubstitutionRule createRule(IUser substitutingUser, IUser substitutedUser, SubstitutionMode mode, Date startDate, Date endDate,
            boolean enabled, URI substitutionProfileId) throws BPMException;

    /**
     * Persists the given {@link SubstitutionRule}. If the given rule already exists in the database the record will be updated.
     * 
     * @param rule
     *            must not be <code>null</code>
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     * @throws BPMIllegalStateException
     *             if the {@link SubstitutionProfile} which is used by the rule has been deleted
     * @throws BPMException
     *             if a technical error occurred while storing the {@link SubstitutionRule}.
     */
    public void storeRule(SubstitutionRule rule) throws BPMException;

    /**
     * Deletes the given {@link SubstitutionRule} from the database.
     * 
     * @param rule
     *            must not be <code>null</code>
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     * @throws BPMException
     *             if a technical error occurred while deleting the {@link SubstitutionRule}.
     */
    public void deleteRule(SubstitutionRule rule) throws BPMException;

    /**
     * Retrieves all active rules for which the given user is the substituted user.
     * 
     * @param substitutedUser
     *            must not be <code>null</code>
     * @return An array with the substitution rules. May return an empty array.
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving the rules
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public SubstitutionRule[] getActiveRulesBySubstitutedUser(IUser substitutedUser) throws BPMException;

    /**
     * Retrieves all inactive rules for which the given user is the substituted user.
     * 
     * @param substitutedUser
     *            must not be <code>null</code>
     * @return An array with the substitution rules. May return an empty array.
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving the rules
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public SubstitutionRule[] getInactiveRulesBySubstitutedUser(IUser substitutedUser) throws BPMException;

    /**
     * Retrieves all active rules for which the given user is the substituting user and the calling user is part of the rule or has proper
     * permissions.
     * 
     * @param substitutingUser
     *            must not be <code>null</code>
     * @return An array with the substitution rules. May return an empty array.
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving the rules
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public SubstitutionRule[] getActiveRulesBySubstitute(IUser substitutingUser) throws BPMException;

    /**
     * Retrieves all inactive rules for which the given user is the substituting user and the calling user is part of the rule or has proper
     * permissions.
     * 
     * @param substitutingUser
     *            must not be <code>null</code>
     * @return An array with the substitution rules. May return an empty array.
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving the rules
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public SubstitutionRule[] getInactiveRulesBySubstitute(IUser substitutingUser) throws BPMException;

    /**
     * Retrieves all rules for which the given user is the substituted user
     * 
     * @param substitutedUser
     *            must not be <code>null</code>
     * @return An array with the substitution rules. May return an empty array.
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving the rules
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public SubstitutionRule[] getRulesBySubstitutedUser(IUser substitutedUser) throws BPMException;

    /**
     * Retrieves all rules for which the given user is the substituting user and the calling user is part of the rule or has proper
     * permissions.
     * 
     * @param substitutingUser
     *            must not be <code>null</code>
     * @return An array with the substitution rules. May return an empty array.
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving the rules
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public SubstitutionRule[] getRulesBySubstitute(IUser substitutingUser) throws BPMException;

    /**
     * Retrieves all the users who the given substitute is substituting. Checks only active rules.
     * 
     * @param substitutingUser
     *            must not be <code>null</code>
     * @return An array with the substituted users. May return an empty array if no users are substituted by the given user.
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving the users
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public IUser[] getSubstitutedUsers(IUser substitutingUser) throws BPMException;

    /**
     * Retrieves all the users who are substituting the given substituted user. Checks only active rules.
     * 
     * @param substitutedUser
     *            must not be <code>null</code>
     * @return An array with the substituting users. May return an empty array if no users are substituting the given user.
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving the users
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public IUser[] getSubstituteUsers(IUser substitutedUser) throws BPMException;

    /**
     * Retrieves all the Ids of the users who the given substitute is substituting according to an active substitution rule.
     * 
     * @param substitutingUser
     *            must be not <code>null</code>
     * @return An array with the substituted users' ids. May return an empty array if no users are substituted by the given user.
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving the ids
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public URI[] getSubstitutedUsersIds(IUser substitutingUser) throws BPMException;

    /**
     * Retrieves all {@link SubstitutionRule}s that match the given parameters. Each parameter may be <code>null</code> - in that case these
     * parameters will be ignored in the search query. This method only returns rules the calling user is part of or has proper permissions
     * to read.
     * 
     * @param substitutingUser
     *            the substituting user
     * @param substitutedUser
     *            the substituted user
     * @param substitutionMode
     *            the substitution mode
     * @param startDate
     *            will match all substitutions <em>not ending before</em> the given date
     * @param endDate
     *            will match all substitutions <em>not starting after</em> the given date
     * @return Return an array of substitution rules that have the given parameters. May return an empty array.
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving rules
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public SubstitutionRule[] getRules(IUser substitutingUser, IUser substitutedUser, SubstitutionMode substitutionMode, Date startDate,
            Date endDate) throws BPMException;

    /**
     * Maps the given users to a matching set of users currently in charge as defined via {@link SubstitutionRule}s. The returned set
     * contains the substituting user for a given user, or if there is none, the given user itself. In detail, takes the given set of users
     * and checks for each of them for active {@link SubstitutionRule}s where they are substituted users. If such rule(s) exist, puts in the
     * output Set of users all the users that are substituting the user(s). The substituted users are not present in the output Set. If a
     * user is not being substituted, he/she will just be added in the resulting Set of users.
     * 
     * <pre>
     * Example: Input list of users: A, B, C, D, E
     * 
     * A -&gt; substituted by Z; A -&gt; substituted by F; C -&gt; substituted by D; E -&gt; substituted by F
     * 
     * Output list of users: B, D, F, Z
     * </pre>
     * 
     * @param users
     *            {@link Collection} of {link IUser}s representing the substituted users
     * @return Returns the set of all the users that are substituting the user(s).
     * @throws BPMIllegalArgumentException
     *             if one of the noted as not <code>null</code> parameters is <code>null</code>
     * @throws SubstitutionRuleException
     *             if a problem occurs while retrieving users
     * @throws BPMIllegalAccessException
     *             if the currently logged in user is not authorized to perform this action
     */
    public Set<IUser> getUsersByActiveRules(Collection<IUser> users) throws BPMException;

    /**
     * Retrieves all the {@link SubstitutionRule}s which use the {@link SubstitutionProfile} with the specified
     * <code>substitutionProfileId</code>.
     * 
     * @param substitutionProfileId
     *            identifier of the {@link SubstitutionProfile} for which {@link SubstitutionRule}s should be retrieved.
     * @return {@link List} of {@link SubstitutionRule}s.
     * @throws BPMIllegalArgumentException
     *             if the specified <code>substitutionProfileId</code> is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI,
     *             it is a valid BPM URI but not a {@link SubstitutionProfile} URI)
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to read {@link SubstitutionRule}s
     * @throws BPMException
     *             if a technical error occurred while reading the {@link SubstitutionRule}s
     */
    public List<SubstitutionRule> getRulesBySubstitutionProfile(URI substitutionProfileId) throws BPMException;
}
