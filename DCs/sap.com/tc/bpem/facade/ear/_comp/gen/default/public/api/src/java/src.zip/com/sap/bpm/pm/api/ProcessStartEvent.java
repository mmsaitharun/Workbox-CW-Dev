package com.sap.bpm.pm.api;

import java.net.URI;

/**
 * Represents a start point of a process.
 * 
 * <br>
 * <br>
 * <p><b>NOTE</b>:  As this interface can be extended, this interface can be freely used, but must not be implemented.
 */
public interface ProcessStartEvent {

    /**
     * Returns a unique identifier for the start event.
     * 
     * @return an instance of {@link URI}
     */
    public URI getId();

}
