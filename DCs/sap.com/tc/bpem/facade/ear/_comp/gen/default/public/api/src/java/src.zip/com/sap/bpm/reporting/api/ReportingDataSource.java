package com.sap.bpm.reporting.api;

import java.net.URI;
import java.util.List;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * Represents a specific reporting data source version deployed in the system or a reporting data source based on all reporting data source
 * versions deployed in the system and derived from the same reporting definition, when only compatible changes were applied between the
 * versions. The nature of the <code>ReportingDataSource</code> object can be determined with the identifier returned by {@link #getId()}.
 * The identifier for a reporting data source version looks like:
 * 
 * <pre>
 * bpm://bpm.sap.com/reporting-datasource/<i>&lt;Name of the reporting data source version&gt;</i>
 * </pre>
 * 
 * whereas the identifier of a reporting data source representing all reporting data source versions derived from the same definition looks
 * like:
 * 
 * <pre>
 * bpm://bpm.sap.com/reporting-datasource/<i>&lt;DC vendor&gt;</i>/<i>&lt;DC name&gt;</i>/<i>&lt;Name of the reporting data source&gt;</i>
 * </pre>
 * 
 * The reporting fields of a reporting data source result from the aggregation of the reporting fields defined in all reporting data source
 * versions. When the data type of a reporting field has been changed between two versions, the most compatible data type becomes the data
 * type of the reporting field. For example, if the data type of the field {@code quantity} is changed from {@code SHORT} to {@code LONG},
 * then the data type of this field in the reporting data source will be {@code LONG}. When a reporting field is added between two versions,
 * the field is also added to the reporting data source. When a field is removed between two versions, the field remains defined in the
 * reporting data source.
 */
public interface ReportingDataSource {

    /**
     * Returns the unique identifier of the reporting data source.
     * 
     * @return the unique identifier of the reporting data source.
     */
    public URI getId();

    /**
     * Returns the name of the reporting data source.
     * 
     * @return the name of the reporting data source.
     */
    public String getName();

    /**
     * Returns the vendor of the development component the reporting data source has been deployed with.
     * 
     * @return the vendor of the development component.
     */
    public String getDevelopmentComponentVendor();

    /**
     * Returns the name of the development component the reporting data source has been deployed with.
     * 
     * @return the name of the development component.
     */
    public String getDevelopmentComponentName();

    /**
     * Returns the reporting field names defined in the reporting data source.
     * 
     * @return the reporting field names.
     */
    public List<String> getFieldNames();

    /**
     * Returns the reporting fields defined in the reporting data source.
     * 
     * @return the reporting fields.
     */
    public List<ReportingField> getFields();

    /**
     * Returns the reporting field identified by the given name. As reporting field names do not support spaces, the given name will be
     * trimmed before to search for the reporting field matching the name.
     * 
     * @param name
     *            the name of the reporting field to return.
     * @return the requested reporting field.
     * @throws ReportingFieldNotFoundException
     *             if the reporting data source does not contain any reporting field matching the given name.
     * @throws BPMIllegalArgumentException
     *             if the given name is {@code null} or an empty string.
     */
    public ReportingField getField(String name) throws BPMException;
}
