package com.sap.bpm.tm.api;

import java.net.URI;

public interface URL extends Attachment {

    /**
     * <p>
     * Returns a {@link URLContent} to get the content of the Attachment{@link URI}
     * </p>
     * 
     * @return {@link URLContent}
     */
    public URLContent getContent();

}
