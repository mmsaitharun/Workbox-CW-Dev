package com.sap.bpm.analytics.event.api;

import java.util.Date;

import com.sap.bpm.event.api.EventType;

/**
 * Represents the statistic for a type of events during a time interval.
 */
public interface EventStatistics {

    /**
     * Returns the event occurrence lower limit applied to collect the events for this statistic.
     * 
     * @return the event occurrence lower limit.
     */
    Date getStartTime();

    /**
     * Returns the event occurrence upper limit applied to collect the events for this statistic.
     * 
     * @return the event occurrence upper limit.
     */
    Date getEndTime();

    /**
     * Returns the type of the events being collected for this statistic.
     * 
     * @return the type of the events collected for this statistic.
     */
    EventType getEventType();

    /**
     * Returns the number of collected events.
     * 
     * @return the number of collected events.
     */
    int getEventCount();

}
