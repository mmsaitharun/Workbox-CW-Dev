/**
 * 
 */
package com.sap.bpm.event.api;

/**
 * Types of events which can be raised by SAP NetWeaver BPM.
 */
public enum EventType {

    /**
     * Type of event raised when a new process instance is created.
     */
    PROCESS_CREATED,

    /**
     * Type of event raised when a process instance is completed.
     */
    PROCESS_COMPLETED,

    /**
     * Type of event raised when a new task instance is created.
     */
    TASK_CREATED,

    /**
     *Type of event raised when a task instance is completed.
     */
    TASK_COMPLETED
}
