package com.sap.bpm.helper.api;

import java.net.URI;

import javax.ejb.Local;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.tm.api.TaskDetail;

/**
 * <p>
 * Provides a conversion between the URI representation and string representation of BPM resource identifiers, and vice versa. Supported BPM
 * identifier types are stored in {@link BPMIdType} enumeration.
 * </p>
 * <h3>URI Representation</h3>
 * <p>
 * Method signatures of the interfaces provided by the BPM API requires and provides identifiers always as URI Java object.
 * </p>
 * <h3>String Representation</h3>
 * <p>
 * There are two variants of a string representation.
 * </p>
 * <h4>Hexadecimal String Representation</h4>
 * <p>
 * The hexadecimal string representation is usually shown in user interfaces, such as SAP NetWeaver Administrator (NWA) or task execution
 * user interfaces. The hexadecimal string representation does not provide the type of the identified resource, such as task instance,
 * process instance. Therefore, the conversion of this representation explicitly requires the type of the resource.
 * </p>
 * <p>
 * Example:
 * </p>
 * 
 * <pre>
 * d81fe974703611e0803800000156fd47
 * </pre>
 * 
 * <h4>URI String Representation</h4>
 * <p>
 * There might be situations where a string representation of the URI is provided.
 * </p>
 * <p>
 * Example:
 * </p>
 * 
 * <pre>
 * bpm://bpm.sap.com/task-instance/d81fe974703611e0803800000156fd47
 * </pre>
 * 
 * <h3>Normalization</h3>
 * <p>
 * The helper normalizes BPM resource identifiers during the conversion performing the following actions:
 * </p>
 * <ul>
 * <li>Removal of all the space characters</li>
 * <li>Removal of all the dashes</li>
 * <li>Conversion to lower case</li>
 * </ul>
 * <h3>Exemplary Usage</h3>
 * <p>
 * The given simplified example implementation shows to use a task instance identifier in string representation to retrieve
 * {@link TaskDetail} using BPM API. The example method should get invoked with an identifier either in hexadecimal representation (for
 * example <code>getTaskDetail("d81fe974703611e0803800000156fd47")</code>) retrieved from an SAP NetWeaver Administrator user interface or
 * in URI string representation (for example <code>getTaskDetail("bpm://bpm.sap.com/task-instance/d81fe974703611e0803800000156fd47")</code>
 * ).
 * </p>
 * 
 * <pre>
 * 
 * 
 * private static final TaskDetail getTaskDetail(final String taskInstanceIdStringRepresentation) {
 *     final TaskInstanceManager taskInstanceManager = BPMFactory.getTaskInstanceManager(); // might get cached
 *     final BPMIdHelper bpmIdHelper = BPMFactory.getBPMIdHelper(); // might get cached
 * 
 *     final URI convertedIdentifier = bpmIdHelper.convertToUri(taskInstanceIdStringRepresentation, BPMIdType.TaskInstanceId);
 *     return taskInstanceManager.getTaskDetail(convertedIdentifier);
 * }
 * </pre>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
@Local
public interface BPMIdHelper {

    /**
     * Converts an identifier in URI representation into hexadecimal string representation.
     * 
     * @param uri
     *            The identifier in URI representation
     * @return The identifier in hexadecimal representation
     * @throws BPMException
     *             In case of conversion errors, for example invalid identifiers
     */
    public String convertToHexString(final URI uri) throws BPMException;

    /**
     * Converts an identifier in string representation into URI representation.
     * 
     * @param identifierString
     *            The identifier in either hexadecimal string or URI string representation
     * @param bpmIdType
     *            The type of the identified resource as it cannot get derived from the string representation
     * @return The identifier in URI representation
     * @throws BPMException
     *             In case of conversion errors, for example invalid identifiers
     */
    public URI convertToUri(final String identifierString, final BPMIdType bpmIdType) throws BPMException;

}
