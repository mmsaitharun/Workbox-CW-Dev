package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.Date;

import com.sap.security.api.IUser;

/**
 * Represents all {@link Note}s
 */
public interface Note {

    /**
     * Returns a unique identifier of the {@link Note}.
     * 
     * @return URI
     */
    public URI getId();

    /**
     * Returns the creator of the {@link Note} as {@link IUser}
     * 
     * @return the details of the creator of the {@link Note}
     */
    public IUser getCreatedBy();

    /**
     * Returns the creation date of the {@link Note}.
     * 
     * @return The creation date of the {@link Note}
     */
    public Date getCreatedOn();

    /**
     * Returns the content of the {@link Note} as {@link String}
     * 
     * @return The content of the {@link Note} as {@link String}
     */
    public String getContent();

}
