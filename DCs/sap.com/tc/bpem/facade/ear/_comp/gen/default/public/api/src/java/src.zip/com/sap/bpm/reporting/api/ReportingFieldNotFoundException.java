package com.sap.bpm.reporting.api;

import static java.lang.String.format;

import java.net.URI;

import com.sap.bpm.exception.api.BPMException;

/**
 * Thrown if the requested reporting field does not exist.
 */
public class ReportingFieldNotFoundException extends BPMException {
    private static final long serialVersionUID = 4710053006387937160L;

    /**
     * Constructs a new {@code ReportingFieldNotFoundException} object.
     * 
     * @param reportingDataSourceId
     *            the identifier of the reporting data source the reporting field should be retrieved from.
     * @param reportingFieldName
     *            the name of the requested field.
     */
    public ReportingFieldNotFoundException(final URI reportingDataSourceId, final String reportingFieldName) {
        super(format("Can't find the field %1$s in the reporting data source %2$s.", reportingFieldName, reportingDataSourceId));
    }

}
