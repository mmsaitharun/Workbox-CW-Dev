package com.sap.bpm.reporting.api;

import static java.lang.String.format;

import com.sap.bpm.exception.api.BPMException;

/**
 * Thrown to indicate the search in a reporting data source could not complete because of the error returned by {@link #getCause()}.
 */
public class ReportingDataSourceSearchException extends BPMException {
    private static final long serialVersionUID = 5294741011438862776L;

    /**
     * Construct a new {@code ReportingDataSourceSearchException} object when the search on all reporting fields of a reporting data source
     * failed.
     * 
     * @param reportingDataSource
     *            the reporting data source where the search was performed
     * @param term
     *            the searched term.
     * @param cause
     *            the error which causes the search to fail.
     */
    public ReportingDataSourceSearchException(final ReportingDataSource reportingDataSource, final String term, final Throwable cause) {
        super(format("An error occurred while searching for the term %1$s in the reporting data source %2$s.", term, reportingDataSource
                .getName()), cause);
    }

    /**
     * Construct a new {@code ReportingDataSourceSearchException} object when the search on a reporting field failed.
     * 
     * @param reportingDataSource
     *            the reporting data source where the search was performed
     * @param reportingField
     *            the reporting field on which the search was performed.
     * @param term
     *            the searched term.
     * @param cause
     *            the error which causes the search to fail.
     */
    public ReportingDataSourceSearchException(final ReportingDataSource reportingDataSource, final ReportingField reportingField,
            final String term, final Throwable cause) {
        super(format("An error occurred while searching for the term %1$s in field %2$s of the reporting data source %3$s.", term,
                reportingField.getName(), reportingDataSource.getName()), cause);
    }

}
