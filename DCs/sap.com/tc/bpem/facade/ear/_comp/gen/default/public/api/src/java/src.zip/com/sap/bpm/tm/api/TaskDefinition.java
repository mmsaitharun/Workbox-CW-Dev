package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.List;

/**
 * A basic representation of a task definition.
 * 
 * <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
public interface TaskDefinition {

    /**
     * Returns a unique identifier for the {@link TaskDefinition}.
     * 
     * @return an instance of {@link URI}
     */
    public URI getId();

    /**
     * Returns the name of the {@link TaskDefinition}.
     * 
     * @return {@link String}
     */
    public String getName();

    /**
     * Returns the list of task custom attribute definitions for the {@link TaskDefinition}.
     *  
     * @return List of {@link CustomAttributeDefinition}
     */
    public List<CustomAttributeDefinition> getCustomAttributeDefinitions();
    
    /**
     * Returns the list of task custom action definitions for the {@link TaskDefinition}.
     * 
     * @return List of {@link CustomActionDefinition} ordered as defined
     */
    public List<CustomActionDefinition> getCustomActionDefinitions();

}
