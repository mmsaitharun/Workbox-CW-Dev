package com.sap.bpm.pm.api;

/**
 * Descriptor to specify query criteria for getting {@link ProcessInstance}(s) while querying using {@link ProcessInstanceManager}.
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 * @see ProcessInstanceFilterCriteria
 */
public interface ProcessInstanceQueryCriteria {

}
