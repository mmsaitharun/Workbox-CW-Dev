package com.sap.bpm.tm.api;

import java.math.BigDecimal;
import java.util.Date;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.tm.api.TaskAbstractCustomAttributesValueFilterCriteria.TaskAbstractCustomAttributeDateFilterType;

/**
 * Descriptor to specify the custom attribute filter criteria matching value ranges for task abstract queries.
 * <p>
 * One or more instances of this class might be instantiated with different custom attributes and their values to apply them as filter
 * arguments to the method {@link TaskInstanceManager#getTaskAbstracts(com.sap.bpm.api.QueryResultParameters, TaskAbstractFetchCriteria...)}
 * .
 * </p>
 * <p>
 * In case the same custom attribute is specified in filters multiple times in combination with this descriptor, an
 * {@link BPMIllegalArgumentException} is thrown. Different custom attributes are connected with 'AND' logic. Filters related to custom
 * attributes are combined with 'AND' logic in regards to filters related to properties of a task using {@link TaskAbstractFilterCriteria}.
 * </p>
 * <p>
 * Several constructors are provided which can be utilized for a modeled custom attribute depending on its type:
 * </p>
 * <table border="1" summary="Custom attributes' datatype and related Java datatypes">
 * <tr>
 * <th>Modeled Data Type</th>
 * <th>Java Data Type</th>
 * <th>Specific Date Type based on {@link TaskAbstractCustomAttributeDateFilterType}</th>
 * </tr>
 * <tr>
 * <td>date</td>
 * <td>{@link Date}</td>
 * <td>{@link TaskAbstractCustomAttributeDateFilterType#DATE}</td>
 * </tr>
 * <tr>
 * <td>dateTime</td>
 * <td>{@link Date}</td>
 * <td>{@link TaskAbstractCustomAttributeDateFilterType#DATE_TIME}</td>
 * </tr>
 * <tr>
 * <td>decimal</td>
 * <td>{@link BigDecimal}</td>
 * <td>&nbsp;</td>
 * </tr>
 * <tr>
 * <td>float</td>
 * <td>{@link Float}</td>
 * <td>&nbsp;</td>
 * </tr>
 * <tr>
 * <td>integer</td>
 * <td>{@link Integer}</td>
 * <td>&nbsp;</td>
 * </tr>
 * <tr>
 * <td>time</td>
 * <td>{@link Date}</td>
 * <td>{@link TaskAbstractCustomAttributeDateFilterType#TIME}</td>
 * </tr>
 * </table>
 * <p>
 * The following example queries for {@link TaskAbstract}s owned by the logged on user, filtered by the following logical condition: (status
 * == READY or status == RESERVED) and (productId &gt;= 42 and productId &lt;= 4711) and (price &gt;= 99)
 * </p>
 * 
 * <pre>
 * TaskAbstractFetchCriteria statusCriteria = new TaskAbstractFilterCriteria(TaskAbstractFilterProperty.STATUS, Status.READY, Status.RESERVED);
 * TaskAbstractFetchCriteria customAttributeCriteria1 = new TaskAbstractCustomAttributesRangeFilterCriteria(&quot;productId&quot;, 42, 4711);
 * TaskAbstractFetchCriteria customAttributeCriteria2 = new TaskAbstractCustomAttributesRangeFilterCriteria(&quot;price&quot;, 99, null);
 * List&lt;TaskAbstract&gt; taskAbstracts = taskInstanceManager.getTaskAbstracts(null, taskAbstractOwnerCriteria, statusCriteria,
 *         customAttributeCriteria1, customAttributeCriteria2);
 * </pre>
 * <p>
 * The provided constructors are performing checks on the provided parameter values. If one of the following conditions for the provided
 * parameter values are not fulfilled, a {@link BPMIllegalArgumentException} is thrown:
 * </p>
 * <ul>
 * <li>customAttributeName must not be null</li>
 * <li>Filtering for a given custom attribute name is only supported once at a time, i.e. it is not allowed to use the same custom attribute
 * name in any further instance of {@link TaskAbstractCustomAttributesFilterCriteria}</li>
 * <li>Only one of the parameters fromValue and toValue must be null</li>
 * </ul>
 * 
 * @sap.ApiForReference
 */
public final class TaskAbstractCustomAttributesRangeFilterCriteria extends TaskAbstractCustomAttributesFilterCriteria {

    private final Integer filterFromValuesInteger;
    private final Integer filterToValuesInteger;

    private final BigDecimal filterFromValuesDecimal;
    private final BigDecimal filterToValuesDecimal;

    private final Float filterFromValuesFloat;
    private final Float filterToValuesFloat;

    private final Long filterFromValuesLong;
    private final Long filterToValuesLong;

    private final Date filterFromValuesDate;
    private final Date filterToValuesDate;

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link Integer} for range values
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesRangeFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param fromValue
     *            Greater equals value of type {@link Integer}; may be null
     * @param toValue
     *            Lower equals value of type {@link Integer}; may be null
     * @throws BPMIllegalArgumentException
     *             If both provided values are null or in any other case of illegal arguments as described in class documentation
     *             {@link TaskAbstractCustomAttributesRangeFilterCriteria}
     */
    public TaskAbstractCustomAttributesRangeFilterCriteria(final String customAttributeName, final Integer fromValue, final Integer toValue)
            throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.INTEGER);
        validateInputParameters(customAttributeName, fromValue, toValue);

        this.filterFromValuesInteger = fromValue;
        this.filterToValuesInteger = toValue;

        this.filterFromValuesDecimal = null;
        this.filterToValuesDecimal = null;

        this.filterFromValuesFloat = null;
        this.filterToValuesFloat = null;

        this.filterFromValuesLong = null;
        this.filterToValuesLong = null;

        this.filterFromValuesDate = null;
        this.filterToValuesDate = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link BigDecimal} for range values
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesRangeFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param fromValue
     *            Greater equals value of type {@link BigDecimal}; may be null
     * @param toValue
     *            Lower equals value of type {@link BigDecimal}; may be null
     * @throws BPMIllegalArgumentException
     *             If both provided values are null or in any other case of illegal arguments as described in class documentation
     *             {@link TaskAbstractCustomAttributesRangeFilterCriteria}
     */
    public TaskAbstractCustomAttributesRangeFilterCriteria(final String customAttributeName, final BigDecimal fromValue,
            final BigDecimal toValue) throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.DECIMAL);
        validateInputParameters(customAttributeName, fromValue, toValue);

        this.filterFromValuesInteger = null;
        this.filterToValuesInteger = null;

        this.filterFromValuesDecimal = fromValue;
        this.filterToValuesDecimal = toValue;

        this.filterFromValuesFloat = null;
        this.filterToValuesFloat = null;

        this.filterFromValuesLong = null;
        this.filterToValuesLong = null;

        this.filterFromValuesDate = null;
        this.filterToValuesDate = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link Float} for range values
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesRangeFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param fromValue
     *            Greater equals value of type {@link Float}; may be null
     * @param toValue
     *            Lower equals value of type {@link Float}; may be null
     * @throws BPMIllegalArgumentException
     *             If both provided values are null or in any other case of illegal arguments as described in class documentation
     *             {@link TaskAbstractCustomAttributesRangeFilterCriteria}
     */
    public TaskAbstractCustomAttributesRangeFilterCriteria(final String customAttributeName, final Float fromValue, final Float toValue)
            throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.FLOAT);
        validateInputParameters(customAttributeName, fromValue, toValue);

        this.filterFromValuesInteger = null;
        this.filterToValuesInteger = null;

        this.filterFromValuesDecimal = null;
        this.filterToValuesDecimal = null;

        this.filterFromValuesFloat = fromValue;
        this.filterToValuesFloat = toValue;

        this.filterFromValuesLong = null;
        this.filterToValuesLong = null;

        this.filterFromValuesDate = null;
        this.filterToValuesDate = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link Long} for range values
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesRangeFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param fromValue
     *            Greater equals value of type {@link Long}; may be null
     * @param toValue
     *            Lower equals value of type {@link Long}; may be null
     * @throws BPMIllegalArgumentException
     *             If both provided values are null or in any other case of illegal arguments as described in class documentation
     *             {@link TaskAbstractCustomAttributesRangeFilterCriteria}
     */
    public TaskAbstractCustomAttributesRangeFilterCriteria(final String customAttributeName, final Long fromValue, final Long toValue)
            throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.LONG);
        validateInputParameters(customAttributeName, fromValue, toValue);

        this.filterFromValuesInteger = null;
        this.filterToValuesInteger = null;

        this.filterFromValuesDecimal = null;
        this.filterToValuesDecimal = null;

        this.filterFromValuesFloat = null;
        this.filterToValuesFloat = null;

        this.filterFromValuesLong = fromValue;
        this.filterToValuesLong = toValue;

        this.filterFromValuesDate = null;
        this.filterToValuesDate = null;
    }

    /**
     * Constructor for filtering {@link TaskAbstract}s on custom attribute based on type {@link Date} for range values
     * <p>
     * For details refer to class documentation {@link TaskAbstractCustomAttributesRangeFilterCriteria}.
     * </p>
     * 
     * @param customAttributeName
     *            The name of the custom attribute
     * @param dateFilterType
     *            Is required to specify the exact type of the date as modelled. Must not be null
     * @param fromValue
     *            Greater equals value of type {@link Date}; may be null
     * @param toValue
     *            Lower equals value of type {@link Date}; may be null
     * @throws BPMIllegalArgumentException
     *             If both provided values are null or in any other case of illegal arguments as described in class documentation
     *             {@link TaskAbstractCustomAttributesRangeFilterCriteria}
     */
    public TaskAbstractCustomAttributesRangeFilterCriteria(final String customAttributeName,
            final TaskAbstractCustomAttributeDateFilterType dateFilterType, final Date fromValue, final Date toValue) throws BPMException {
        super(customAttributeName, CustomAttributeTypeEnum.convertDateFilterType(dateFilterType));
        validateInputParameters(customAttributeName, fromValue, toValue);

        this.filterFromValuesInteger = null;
        this.filterToValuesInteger = null;

        this.filterFromValuesDecimal = null;
        this.filterToValuesDecimal = null;

        this.filterFromValuesFloat = null;
        this.filterToValuesFloat = null;

        this.filterFromValuesLong = null;
        this.filterToValuesLong = null;

        this.filterFromValuesDate = fromValue;
        this.filterToValuesDate = toValue;
    }

    private void validateInputParameters(final String customAttributeName, final Object fromValue, final Object toValue) {
        if (customAttributeName == null) {
            throw new BPMIllegalArgumentException("Custom attribute name must not be null");
        }
        if (fromValue == null && toValue == null) {
            throw new BPMIllegalArgumentException("fromValue and toValue must not be null at the same time");
        }
    }

    /**
     * Returns the lower boundary filter values of the custom attribute
     * 
     * @return the lower boundary filter values of the custom attribute
     * @throws BPMException
     *             In case of any error
     */
    public Object getCustomAttributeFromFilterValue() throws BPMException {
        if (filterFromValuesDecimal != null) {
            return filterFromValuesDecimal;
        }

        if (filterFromValuesFloat != null) {
            return filterFromValuesFloat;
        }

        if (filterFromValuesLong != null) {
            return filterFromValuesLong;
        }

        if (filterFromValuesDate != null) {
            return filterFromValuesDate;
        }

        if (filterFromValuesInteger != null) {
            return filterFromValuesInteger;
        }
        return null;
    }

    /**
     * Returns the upper boundary filter values of the custom attribute
     * 
     * @return the upper boundary filter values of the custom attribute
     * @throws BPMException
     *             In case of any error
     */
    public Object getCustomAttributeToFilterValue() throws BPMException {
        if (filterToValuesDecimal != null) {
            return filterToValuesDecimal;
        }

        if (filterToValuesFloat != null) {
            return filterToValuesFloat;
        }

        if (filterToValuesLong != null) {
            return filterToValuesLong;
        }

        if (filterToValuesDate != null) {
            return filterToValuesDate;
        }

        if (filterToValuesInteger != null) {
            return filterToValuesInteger;
        }
        return null;
    }
}
