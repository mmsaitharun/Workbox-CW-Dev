package com.sap.bpm.jms.api;

import com.sap.bpm.exception.api.BPMException;

/**
 * Enum providing a list of event types. A given BPMEventType identifies the type of the event provided through
 * {@link BPMEventMessage#getBPMEventType()}.
 */
public enum BPMEventType {

    /**
     * A {@link BPMEventMessage} of this type is sent when a process instance is started through a Start Event.
     */
    PROCESS_STARTED(1, true, false),
    /**
     * A {@link BPMEventMessage} of this type is sent when a process flow reaches an End Event.
     */
    PROCESS_COMPLETED(2, true, false),
    /**
     * A {@link BPMEventMessage} of this type is sent when a process instance is canceled.
     */
    PROCESS_CANCELED(3, true, false),
    /**
     * A {@link BPMEventMessage} of this type is sent when a process instance is suspended.
     */
    PROCESS_SUSPENDED(4, true, false),

    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is created.
     */
    USERTASK_CREATED(101, false, true),
    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is completed.
     */
    USERTASK_COMPLETED(102, false, true),
    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is claimed.
     */
    USERTASK_CLAIMED(103, false, true),
    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is canceled.
     */
    USERTASK_CANCELED(104, false, true),
    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is nominated.
     */
    USERTASK_NOMINATED(106, false, true),
    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is escalated.
     */
    USERTASK_ESCALATED(107, false, true),
    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is released.
     */
    USERTASK_RELEASED(108, false, true),
    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is activated.
     */
    USERTASK_ACTIVATED(109, false, true),

    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is suspended.
     */
    USERTASK_SUSPENDED(110, false, true),
    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is error.
     */
    USERTASK_IN_ERROR(111, false, true),
    
    /**
     * A {@link BPMEventMessage} of this type is sent when a Human Task is delegated.
     */
    USERTASK_DELEGATED(112, false, true),
    
    /**
     * A {@link BPMEventMessage} of this type is sent when a process flow reaches an Automated Activity.
     */
    SERVICETASK_STARTED(201, true, false),
    /**
     * A {@link BPMEventMessage} of this type is sent when a process flow completes an Automated Activity.
     */
    SERVICETASK_COMPLETED(202, true, false),

    /**
     * A {@link BPMEventMessage} of this type is sent when a process flow reaches an Intermediate Message Event.
     */
    INTERMEDIATE_MESSAGE_TRIGGERED(301, true, false),

    /**
     * A {@link BPMEventMessage} of this type is sent when a process flow reaches a Referenced Sub-Process Activity.
     */
    CALLACTIVITY_STARTED(401, true, false),
    /**
     * A {@link BPMEventMessage} of this type is sent when a process flow completes a Referenced Sub-Process Activity.
     */
    CALLACTIVITY_COMPLETED(402, true, false);

    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#PROCESS_STARTED}
     */
    public final static String SELECT_EVENT_PROCESS_STARTED = "EVENT_TYPE_ID = 1";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#PROCESS_COMPLETED}
     */
    public final static String SELECT_EVENT_PROCESS_COMPLETED = "EVENT_TYPE_ID = 2";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#PROCESS_CANCELED}
     */
    public final static String SELECT_EVENT_PROCESS_CANCELED = "EVENT_TYPE_ID = 3";

    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#PROCESS_SUSPENDED}
     */
    public final static String SELECT_EVENT_PROCESS_SUSPENDED = "EVENT_TYPE_ID = 4";
    
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_CREATED}
     */
    public final static String SELECT_EVENT_USERTASK_CREATED = "EVENT_TYPE_ID = 101";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_COMPLETED}
     */
    public final static String SELECT_EVENT_USERTASK_COMPLETED = "EVENT_TYPE_ID = 102";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_CLAIMED}
     */
    public final static String SELECT_EVENT_USERTASK_CLAIMED = "EVENT_TYPE_ID = 103";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_CANCELED}
     */
    public final static String SELECT_EVENT_USERTASK_CANCELED = "EVENT_TYPE_ID = 104";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_NOMINATED}
     */
    public final static String SELECT_EVENT_USERTASK_NOMINATED = "EVENT_TYPE_ID = 106";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_ESCALATED}
     */
    public final static String SELECT_EVENT_USERTASK_ESCALATED = "EVENT_TYPE_ID = 107";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_SUSPENDED}
     */
    public final static String SELECT_EVENT_USERTASK_SUSPENDED = "EVENT_TYPE_ID = 110";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_IN_ERROR}
     */
    public final static String SELECT_EVENT_USERTASK_IN_ERROR = "EVENT_TYPE_ID = 111";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_ACTIVATED}
     */
    public final static String SELECT_EVENT_USERTASK_ACTIVATED = "EVENT_TYPE_ID = 109";

    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_DELEGATED}
     */
    public final static String SELECT_EVENT_USERTASK_DELEGATED = "EVENT_TYPE_ID = 112";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#USERTASK_RELEASED}
     */
    public final static String SELECT_EVENT_USERTASK_RELEASED = "EVENT_TYPE_ID = 108";
    
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#SERVICETASK_STARTED}
     */
    public final static String SELECT_EVENT_SERVICETASK_STARTED = "EVENT_TYPE_ID = 201";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#SERVICETASK_COMPLETED}
     */
    public final static String SELECT_EVENT_SERVICETASK_COMPLETED = "EVENT_TYPE_ID = 202";

    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#INTERMEDIATE_MESSAGE_TRIGGERED}
     */
    public final static String SELECT_EVENT_INTERMEDIATE_MESSAGE_TRIGGERED = "EVENT_TYPE_ID = 301";

    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#CALLACTIVITY_STARTED}
     */
    public final static String SELECT_EVENT_CALLACTIVITY_STARTED = "EVENT_TYPE_ID = 401";
    /**
     * Constant providing a JMS selector argument for filtering on events of type {@link BPMEventType#CALLACTIVITY_COMPLETED}
     */
    public final static String SELECT_EVENT_CALLACTIVITY_COMPLETED = "EVENT_TYPE_ID = 402";

    private final int id;
    private final boolean isProcessEventType;
    private final boolean isTaskEventType;

    BPMEventType(final int id, final boolean isProcessEventType, final boolean isTaskEventType) {
        this.id = id;
        this.isProcessEventType = isProcessEventType;
        this.isTaskEventType = isTaskEventType;
    }

    /**
     * Retrieves an instance of {@link BPMEventType} for the requested id
     * 
     * @param eventTypeId
     *            for which an instance of {@link BPMEventType} is requested
     * @return an instance of {@link BPMEventType}
     * @throws BPMException
     *             In case of any error
     */
    public static final BPMEventType getEventTypeByEventTypeId(final int eventTypeId) throws BPMException {
        for (final BPMEventType eventType : BPMEventType.values()) {
            if (eventType.id == eventTypeId) {
                return eventType;
            }
        }
        return null;
    }

    /**
     * Determines whether the BPMEventType is related to process events.
     * 
     * @return true in case an given BPMEventType is related to process events.
     * @throws BPMException
     *             In case of any error
     */
    public final boolean isProcessEventType() throws BPMException {
        return isProcessEventType;
    }

    /**
     * Determines whether the BPMEventType is related to task events.
     * 
     * @return true in case the given BPMEventType is related to task events.
     * @throws BPMException
     *             In case of any error
     */
    public final boolean isTaskEventType() throws BPMException {
        return isTaskEventType;
    }
}
