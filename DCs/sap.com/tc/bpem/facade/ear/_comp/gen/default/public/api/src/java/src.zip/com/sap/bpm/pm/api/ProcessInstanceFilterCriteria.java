package com.sap.bpm.pm.api;

import com.sap.bpm.api.QueryResultParameters;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMNotSupportedException;

/**
 * Represents a filtering criteria for getting {@link ProcessInstance}(s) while querying using
 * {@link ProcessInstanceManager#getProcessInstances(QueryResultParameters,ProcessInstanceQueryCriteria...)} method. The filtering criteria
 * is defined for a Process Instance property ({@link ProcessInstanceProperty}) to specify value(s) which it should have for a Process
 * Instance to be returned by the {@link ProcessInstanceManager}. To specify equality condition {@link ProcessInstanceFilterOperator} is
 * used. In case multiple values are specified for a filtering criteria the corresponding property of the Process Instance should match one
 * of them if {@link ProcessInstanceFilterOperator#EQUALS} operator is specified or none of them for
 * {@link ProcessInstanceFilterOperator#NOT_EQUALS} operator for the Process Instance to be returned.
 * <p>
 * The following restrictions are applied during creation of ProcessInstanceFilterCriteria:
 * </p>
 * <ul>
 * <li>The filtering criteria can be created only for the Process Instance properties for which {@link ProcessInstanceProperty} instances
 * exist.</li>
 * <li>Java data type of the filtering value should be the same as the type of the corresponding property in {@link ProcessInstance} class.
 * For example: if the filtering criteria should be created to filter Process Instances by status {@link ProcessInstanceProperty#STATUS}
 * should be specified as filtering property and one of the values of the {@link ProcessStatus} enum should be specified as the filtering
 * value because the enum is used to store status in {@link ProcessInstance} class.</li>
 * <li>In case {@link ProcessInstanceFilterOperator#FROM} or {@link ProcessInstanceFilterOperator#TO} operator is specified the filtering
 * criteria should be created only for one filtering value. In case multiple values are specified only the first one will be considered.</li>
 * </ul>
 * <p>
 * The following table indicates which {@link ProcessInstanceFilterOperator} is supported depending on the used
 * {@link ProcessInstanceProperty}:
 * </p>
 * <table summary="Filter operators depending on the used properties">
 * <tr>
 * <th>Property / Operator</th>
 * <th>EQUALS</th>
 * <th>NOT_EQUALS</th>
 * <th>FROM</th>
 * <th>TO</th>
 * </tr>
 * <tr>
 * <td><b>ID</b></td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * <td></td>
 * <td></td>
 * </tr>
 * <tr>
 * <td><b>START_DATE</b></td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * </tr>
 * <tr>
 * <td><b>END_DATE</b></td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * </tr>
 * <tr>
 * <td><b>DEFINITION_ID</b></td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * <td></td>
 * <td></td>
 * </tr>
 * <tr>
 * <td><b>STATUS</b></td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * <td></td>
 * <td></td>
 * </tr>
 * <tr>
 * <td><b>PARENT_PROCESS_INSTANCE_ID</b></td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * <td></td>
 * <td></td>
 * </tr>
 * <tr>
 * <td><b>ROOT_PROCESS_INSTANCE_ID</b></td>
 * <td align="center">x</td>
 * <td></td>
 * <td></td>
 * <td></td>
 * </tr>
 * <tr>
 * <td><b>PROCESS_INITIATOR</b></td>
 * <td align="center">x</td>
 * <td align="center">x</td>
 * <td></td>
 * <td></td>
 * </tr>
 * </table>
 * In case an unsupported operator is specified for a property {@link BPMNotSupportedException} will be thrown.
 * <p>
 * <b>Example:</b>
 * </p>
 * <p>
 * In order to get Process Instances which are in IN_PROGRESS status the filtering criteria should be created in the following way:
 * </p>
 * 
 * <pre>
 * ProcessInstanceFilterCriteria filterCriteria = new ProcessInstanceFilterCriteria(ProcessInstanceProperty.STATUS,
 *         ProcessInstanceFilterOperator.EQUALS, ProcessStatus.IN_PROGRESS);
 * </pre>
 * 
 * <b>Example:</b>
 * <p>
 * In order to get Process Instances which are either in IN_PROGRESS or in SUSPENDED status the filtering criteria should be created in the
 * following way:
 * </p>
 * 
 * <pre>
 * ProcessInstanceFilterCriteria filterCriteria = new ProcessInstanceFilterCriteria(ProcessInstanceProperty.STATUS,
 *         ProcessInstanceFilterOperator.EQUALS, ProcessStatus.IN_PROGRESS, ProcessStatus.SUSPENDED);
 * </pre>
 * 
 * <b>Example:</b>
 * <p>
 * In order to get all the Process Instances except of the ones which have been cancelled the following filtering criteria should be
 * created:
 * </p>
 * 
 * <pre>
 * ProcessInstanceFilterCriteria filterCriteria = new ProcessInstanceFilterCriteria(ProcessInstanceProperty.STATUS,
 *         ProcessInstanceFilterOperator.NOT_EQUALS, ProcessStatus.CANCELLED);
 * </pre>
 * 
 * <b>Example:</b>
 * <p>
 * In order to get Process Instances which have been started from the particular date the following filter criteria should be created:
 * </p>
 * 
 * <pre>
 * ProcessInstanceFilterCriteria filterCriteria = new ProcessInstanceFilterCriteria(ProcessInstanceProperty.START_DATE,
 *         ProcessInstanceFilterOperator.FROM, startDate);
 * </pre>
 * 
 * In the example, <code>startDate</code> is an instance of {@link java.util.Date}.
 */
public final class ProcessInstanceFilterCriteria implements ProcessInstanceQueryCriteria {

    private static final String INVALID_INIT_PARAMS_ERROR_MSG = "Process Instance property, filtering operator and filtering value(s) should be specified to create ProcessInstanceFilterCriteria.";

    private final ProcessInstanceProperty<?> property;
    private final ProcessInstanceFilterOperator operator;
    private final Object[] values;

    public <T> ProcessInstanceFilterCriteria(ProcessInstanceProperty<T> property, ProcessInstanceFilterOperator operator, T... values) {
        if (property == null || operator == null || values == null || values.length == 0) {
            throw new BPMIllegalArgumentException(INVALID_INIT_PARAMS_ERROR_MSG);
        }

        this.property = property;
        this.operator = operator;
        this.values = values;
    }

    /**
     * Returns the filtering property.
     * 
     * @return the property of the filter criteria
     */
    public final ProcessInstanceProperty<?> getProperty() {
        return property;
    }

    /**
     * Returns the filtering operator.
     * 
     * @return the operator of the filter criteria
     */
    public final ProcessInstanceFilterOperator getOperator() {
        return operator;
    }

    /**
     * Returns the filtering values.
     * 
     * @return the values of the filter criteria
     */
    public final Object[] getValues() {
        return values;
    }
}
