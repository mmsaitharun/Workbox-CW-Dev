/**
 * The package provides the class to access the definition of the reporting data sources deployed on the system and to search in their content.
 */
package com.sap.bpm.reporting.api;