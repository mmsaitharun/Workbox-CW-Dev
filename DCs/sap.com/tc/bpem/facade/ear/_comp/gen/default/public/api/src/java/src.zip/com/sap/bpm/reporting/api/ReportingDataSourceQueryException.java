package com.sap.bpm.reporting.api;

import static java.lang.String.format;

import java.net.URI;

import com.sap.bpm.exception.api.BPMException;

/**
 * Thrown to indicate the query on a reporting data source could not complete because of the error returned by {@link #getCause()}.
 */
public class ReportingDataSourceQueryException extends BPMException {
    private static final long serialVersionUID = -6059966790400388495L;

    /**
     * Constructs a new {@code ReportingDataSourceQueryException} object when a reporting data source cannot be queried successfully.
     * 
     * @param reportingDataSourceId
     *            the identifier of the queried reporting data source.
     * @param cause
     *            the error which caused the query to fail.
     */
    public ReportingDataSourceQueryException(final URI reportingDataSourceId, final Throwable cause) {
        super(format("An error occurred while querying the reporting data source %1$s", reportingDataSourceId), cause);
    }

    /**
     * Constructs a new {@code ReportingDataSourceQueryException} object with a message when the queried data cannot be retrieved
     * successfully.
     * 
     * @param message
     *            the error message.
     */
    public ReportingDataSourceQueryException(final String message) {
        super(message);
    }

    /**
     * Constructs a new {@code ReportingDataSourceQueryException} object with a message when the queried data cannot be retrieved
     * successfully because of an error.
     * 
     * @param message
     *            the error message.
     * @param cause
     *            the error preventing to retrieve the queried data.
     */
    public ReportingDataSourceQueryException(final String message, final Throwable cause) {
        super(message);
    }

}
