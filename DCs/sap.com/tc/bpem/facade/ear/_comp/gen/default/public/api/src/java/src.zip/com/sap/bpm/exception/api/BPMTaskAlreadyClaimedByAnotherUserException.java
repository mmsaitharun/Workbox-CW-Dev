package com.sap.bpm.exception.api;

/**
 * This exception indicates that the task requested to get claimed is already claimed by another user.
 */
public class BPMTaskAlreadyClaimedByAnotherUserException extends BPMIllegalArgumentException {

    private static final long serialVersionUID = -2895183483393217992L;

    public BPMTaskAlreadyClaimedByAnotherUserException(String message, Throwable cause) {
        super(message, cause);
    }

    public BPMTaskAlreadyClaimedByAnotherUserException(String message) {
        super(message);
    }

    public BPMTaskAlreadyClaimedByAnotherUserException(Throwable cause) {
        super(cause);
    }

}
