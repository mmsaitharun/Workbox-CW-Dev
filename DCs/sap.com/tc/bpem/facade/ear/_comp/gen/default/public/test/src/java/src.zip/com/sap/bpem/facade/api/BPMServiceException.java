package com.sap.bpem.facade.api;

/**
 * <p>The BPMServiceException is the default exception in cases problems occur
 * from which the upper layer cannot recover (e.g. Galaxy components are missing).</p>
 * 
 * @author Martin Moeller
 */
public class BPMServiceException extends RuntimeException {

    private static final long serialVersionUID = -1580399312988402582L;

    /**
     * 
     */
    public BPMServiceException() {
        super();
    }

    /**
     * @param message
     * @param cause
     */
    public BPMServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param message
     */
    public BPMServiceException(String message) {
        super(message);
    }

    /**
     * @param cause
     */
    public BPMServiceException(Throwable cause) {
        super(cause);
    }

    
    
}
