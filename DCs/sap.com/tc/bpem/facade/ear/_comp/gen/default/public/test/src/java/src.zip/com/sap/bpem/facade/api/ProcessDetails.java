package com.sap.bpem.facade.api;

import java.io.Serializable;
import java.util.List;

/**
 * <p>ProcessDetails contains additional information about a deployed BPM process definition. Currently
 * it only comprises the set of automated acitivites which are used in the process model. Thereby
 * one could easily find out which enterprise services are invoked by the BPM process definition.</p>
 */
public class ProcessDetails implements Serializable {

	/**
     * Generated serial version UID
     */
	private static final long serialVersionUID = -2924281739532697895L;
	
	public String activeVersionId, name, description;
	public List<AutomatedActivity> automatedActivities;
	
    /**
     * <p>Constructor.</p> 
     */
	public ProcessDetails() {}  
	
}
