package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.Date;
import java.util.Map;

import com.sap.security.api.IUser;

/**
 * A basic representation of a task instance suitable to populate a task list.<br>
 * Texts are resolved in the language of the authenticated user if available, otherwise in the default language. <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
public interface TaskAbstract {

    /**
     * The task instance id
     * 
     * @return id, must be set
     */
    public URI getId();

    /**
     * The task definition id.
     * 
     * @deprecated Use {@link #getDefinitionId()} to get the task definition id of this {@link TaskAbstract} instance.
     * @return id, must be set
     */
    @Deprecated
    public URI getDefintionId();

    /**
     * The task definition id of this {@link TaskAbstract} instance.
     * 
     * @return id, the definition id of this {@link TaskAbstract} instance
     */
    public URI getDefinitionId();

    /**
     * The task model id of this {@link TaskAbstract} instance.
     * 
     * @return id, the model id of this {@link TaskAbstract} instance
     */
    public URI getModelId();

    /**
     * @return task type, must be set
     */
    public String getTaskType();

    /**
     * @return name, must be set
     */
    public String getName();

    /**
     * @return subject, may return null
     */
    public String getSubject();

    /**
     * @return description, may return null
     */
    public String getDescription();

    /**
     * @return status, must be set
     */
    public Status getStatus();

    /**
     * @return priority
     */
    public Priority getPriority();

    /**
     * Creation time (UTC)
     * 
     * @return creation time, must be set
     */
    public Date getCreatedTime();

    /**
     * Activation time (UTC)
     * 
     * @return activation time, may return null
     */
    public Date getActivationTime();

    /**
     * Expiration time (UTC)
     * 
     * @return expiration time, may return null
     */
    public Date getExpirationTime();

    /**
     * Returns the time when the task was completed.
     * 
     * @return Completed time if the task is completed<br>
     *         Null if the task is not completed.
     */
    public Date getCompletedTime();

    /**
     * Completion deadline (UTC)
     * 
     * @return complete by time, may return null
     */
    public Date getCompleteByTime();

    /**
     * Start deadline (UTC)
     * 
     * @return start by time, may return null
     */
    public Date getStartByTime();

    /**
     * @return start by time exists
     */
    public boolean startByTimeExists();

    /**
     * @return complete by time exists
     */
    public boolean completeByTimeExists();

    /**
     * @deprecated This method has been replaced by {@link #getSubject()}.
     * @return presentation name
     */
    @Deprecated
    public String getPresentationName();

    /**
     * @deprecated This method has been replaced by {@link #getDescription()}.
     * @return presentation subject
     */
    @Deprecated
    public String getPresentationSubject();

    /**
     * @return is escalated
     */
    public boolean isEscalated();

    /**
     * Gets the task custom attribute values
     * 
     * @return the map of task custom attributes with key(s) as the name of the attribute defined.
     */
    public Map<String, Object> getCustomAttributeValues();

    /**
     * @return task initiator as {@link IUser}
     */
    public IUser getTaskInitiator();

    /**
     * Returns the number of attachments for the task instance.
     * 
     * @return Returns the number of attachments for the task instance
     */
    public int getAttachmentCount();

}
