package com.sap.bpm.exception.api;

/**
 * This exception indicates that the given object is in an invalid state for this operation.
 */
public class BPMIllegalStateException extends BPMException {

    private static final long serialVersionUID = 32202L;

    public BPMIllegalStateException(String message, Throwable cause) {
        super(message, cause);
    }

    public BPMIllegalStateException(String message) {
        super(message);
    }

    public BPMIllegalStateException(Throwable cause) {
        super(cause);
    }

}
