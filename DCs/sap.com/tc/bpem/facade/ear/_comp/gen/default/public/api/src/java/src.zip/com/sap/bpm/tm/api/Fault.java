package com.sap.bpm.tm.api;

import commonj.sdo.DataObject;

/**
 * Represents the cause for a failure of a task.
 * 
 * <br>
 * <br>
 * <p><b>NOTE</b>:  As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @see TaskInstanceManager#fail(java.net.URI, Fault)
 */
public interface Fault {

    /**
     * Returns the fault name
     * 
     * @return The fault name
     */
    public String getName();

    /**
     * Returns the fault data object
     * 
     * @return The fault data object
     */
    public DataObject getFaultData();

}
