package com.sap.bpm.tm.api;

import java.net.URI;
import java.net.URL ;


/**
 * Represents a {@link URLContent} for a {@link URL} attachment
 */
public interface URLContent {

    /**
     * Returns a unique identifier of the attachment.
     * 
     * @return URI
     */
    public URI getId();

    /**
     * Returns The content of the {@link Attachment} as
     * 
     * @return The content of the {@link Attachment} as java.net.URL
     */
    public URL getContent();
}