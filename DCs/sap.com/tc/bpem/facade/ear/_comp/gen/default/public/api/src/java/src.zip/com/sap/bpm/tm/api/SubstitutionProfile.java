package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * A representation of a substitution profile. The substitution profile is represented by a key, which is used as a technical name of the
 * profile, and by a list of {@link TaskModel}s. The profile can be assigned to a {@link SubstitutionRule} to restrict which type of tasks
 * should be visible to the substituting user in scope of the substitution. As a result, only the tasks which belong to the
 * {@link TaskModel}s of the substitution profile will be visible to the substituting user. Substitution profiles also contain localizable
 * names, with a default name as a fallback for unsupported languages.
 * <p>
 * All fields of a substitution profile (except the internal ID) can be modified. To store the modified version of the profile in the
 * database, the {@link SubstitutionProfileManager#storeProfile(SubstitutionProfile)} method should be called.
 * </p>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, it can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
public interface SubstitutionProfile extends SubstitutionProfileInfo {

    /**
     * Sets a new value for the key of the substitution profile. The following restrictions are applied for the key value:
     * <ul>
     * <li>The key must not be empty</li>
     * <li>The key must not be longer than 12 characters</li>
     * <li>The key must not contain trailing whitespaces</li>
     * <li>The key must be case insensitively unique among the other substitution profiles</li>
     * </ul>
     * The specified key value will be converted to upper case.
     * 
     * @param key
     *            key which should be set to the substitution profile.
     * @throws BPMIllegalArgumentException
     *             if the specified profile key does not correspond to one of the aforementioned restrictions.
     */
    public void setKey(String key);

    /**
     * Sets a new value for the default name of the substitution profile. The following restrictions are applied for the value:
     * <ul>
     * <li>The name must be neither null nor empty</li>
     * <li>The name must not be longer than 25 characters</li>
     * </ul>
     * To store the modified version of the profile name in the database, the
     * {@link SubstitutionProfileManager#storeProfile(SubstitutionProfile)} method should be called.
     * 
     * @param defaultName
     *            name which should be set to the substitution profile.
     * @throws BPMIllegalArgumentException
     *             If the provided parameter does not correspond to one of the aforementioned restrictions.
     */
    public void setDefaultName(String defaultName) throws BPMException;

    /**
     * Returns the default name of the substitution profile. The name of the substitution profile represents the human-readable name of the
     * profile. The default name is used as a fallback for unsupported languages.
     * 
     * @return The default name of the substitution profile.
     */
    public String getDefaultName();

    /**
     * Sets the provided Map with {@link Locale}s/names for the substitution profile. The following restrictions are applied for the map and
     * its map values:
     * <ul>
     * <li>The name map must not be null</li>
     * <li>The name text must not be longer than 25 characters</li>
     * </ul>
     * To store the modified version of the profile name in the database the
     * {@link SubstitutionProfileManager#storeProfile(SubstitutionProfile)} method should be called.
     * 
     * @param localizedNames
     *            The Map with locale/name pairs which should be set to the substitution profile.
     * @throws BPMIllegalArgumentException
     *             If the provided parameter does not correspond to one of the aforementioned restrictions.
     */
    public void setLocalizedNames(Map<Locale, String> localizedNames) throws BPMException;

    /**
     * Returns the Map of localized names containing locale/name entries. This list may be modified and provided back with the
     * {@link #setLocalizedNames(Map)} method.
     * @return Map of localized names containing locale/name entries
     */
    public Map<Locale, String> getLocalizedNames();

    /**
     * Returns identifiers of the {@link TaskModel}s of the substitution profile. The returned {@link List} can be modified by adding or
     * removing {@link TaskModel} identifiers.
     * 
     * @return {@link List} of {@link TaskModel} identifiers.
     */
    public List<URI> getTaskModelIds();

    /**
     * Sets the specified {@link List} of <code>taskModelIds</code> to the substitution profile.
     * 
     * @param taskModelIds
     *            - {@link TaskModel} identifiers which should be set to the substitution profile.
     */
    public void setTaskModelIds(List<URI> taskModelIds);

    /**
     * Returns {@link TaskModel}s of the substitution profile. The returned list contains {@link TaskModel}s which correspond to the
     * {@link TaskModel} identifiers returned by the {@link #getTaskModelIds()} method. The returned list is immutable.
     * 
     * @return {@link List} of {@link TaskModel}s.
     */
    public List<TaskModel> getTaskModels();
}
