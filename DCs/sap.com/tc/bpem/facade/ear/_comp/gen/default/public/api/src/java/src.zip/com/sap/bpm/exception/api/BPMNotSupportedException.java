package com.sap.bpm.exception.api;

/**
 * This exception indicates that the requested operation or feature is not supported in the current version of the API.
 */
public class BPMNotSupportedException extends BPMException {

    private static final long serialVersionUID = -3601590430990512686L;

    public BPMNotSupportedException(String message, Throwable cause) {
        super(message, cause);
    }

    public BPMNotSupportedException(String message) {
        super(message);
    }

    public BPMNotSupportedException(Throwable cause) {
        super(cause);
    }
}
