package com.sap.bpm.message.api;

import java.net.URI;

/**
 * Holds the unique identifier of an event trigger which is created for a start event or intermediate event while modelling the process
 */
public interface EventTrigger {

    /**
     * Returns a unique identifier for an event trigger
     * 
     * @return an instance of {@link URI}
     */
    public URI getId();

}
