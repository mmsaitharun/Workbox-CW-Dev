package com.sap.bpem.facade.api;

import java.io.Serializable;

/**
 * <p>A ProcessInfo contains a very basic set of information related to a
 * process definition deployed on a BPM server.</p>
 * 
 * <p>It contains the DC vendor, name and a technical process name to identify it
 * on uniquely identify it on different systems. Furthermore it also contains the
 * display name and the ID of the active version (for visualization purposes) and
 * a boolean indicating if a description is available which could be used for lazy
 * loading.</p>
 */
public class ProcessInfo implements Serializable {

    /**
     * Generated serial version UID
     */
    private static final long serialVersionUID = 3874436733291339390L;
    
    public String displayName, dcVendor, dcName, process, activeVersionId;
    public boolean hasDescription;
    
    /**
     * <p>Empty default constructor. Needed for web services.</p> 
     */
    public ProcessInfo() {
        dcVendor = "";
        dcName = "";
        process = "";
        displayName = "";
        activeVersionId = "";
        
        hasDescription = false;
    }

    /**
     * <p>Constructor</p>
     * 
     * @param dcVendor			the vendor of the DC which contains the process, not null, not empty.
     * @param dcName			the name of the DC which contains the process, not null, not empty.
     * @param process			the technical name of the process, not null, not empty.
     * @param displayName   	the display name of the process, not null, not empty.
     * @param hasDescription	a Boolean indicating whether the process has a description or not. Important for lazy loading.
     * @param activeVersionId	a valid String representation of the (version) ID of the process, not null, not empty.
     * 
     * @throws IllegalArgumentException Thrown in case one of the parameters is not set properly.
     */
    public ProcessInfo(String dcVendor, String dcName, String process, String displayName, boolean hasDescription, String activeVersionId) {
    	checkInput("dcVendor", dcVendor);
    	checkInput("dcName", dcName);
    	checkInput("process", process);
    	checkInput("displayName", displayName);
    	checkInput("activeVersionId", activeVersionId);

    	this.dcVendor = dcVendor;
    	this.dcName = dcName;
    	this.process = process;
    	this.displayName = displayName;
        this.hasDescription = hasDescription;
        this.activeVersionId = activeVersionId;        
    }
    
    private void checkInput(String name, String content) {
    	if (content == null || content.trim().length() == 0) {
    		throw new IllegalArgumentException(name + " must neither be null nor empty.");
    	}
    }
}
