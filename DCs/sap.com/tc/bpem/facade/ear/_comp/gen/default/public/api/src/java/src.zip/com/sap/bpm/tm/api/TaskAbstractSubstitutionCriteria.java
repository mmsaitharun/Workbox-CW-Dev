package com.sap.bpm.tm.api;

import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.security.api.IUser;

/**
 * Descriptor to specify the substitution criteria for task abstract queries.
 * 
 * @sap.ApiForReference
 */
public final class TaskAbstractSubstitutionCriteria implements TaskAbstractFetchCriteria {

    private final IUser[] substitutedUsers;

    /**
     * @param substitutedUsers
     *            If the variable argument list is empty, then all currently substituted users are applied automatically, otherwise only the
     *            provided substituted users are applied.
     */
    public TaskAbstractSubstitutionCriteria(IUser... substitutedUsers) {
        if (substitutedUsers == null)
            throw new BPMIllegalArgumentException("Var-arg parameter may not be a null array");
        this.substitutedUsers = substitutedUsers;
    }

    public final IUser[] getSubstitutedUsers() {
        return substitutedUsers;
    }
}
