package com.sap.bpm.tm.api;

public enum TaskAbstractFilterPropertyName {

    STATUS,

    PRIORITY,

    INITIATOR,

    MODEL_ID,

    CREATED_FROM,

    CREATED_TO,
    
    COMPLETED_FROM,

    COMPLETED_TO,

    COMPLETION_DEADLINE_FROM,

    COMPLETION_DEADLINE_TO,
    
    INSTANCE_ID_GREATER;
}
