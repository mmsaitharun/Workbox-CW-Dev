package com.sap.bpm.tm.api;


/**
 * Definition of the different substitution modes of a {@link SubstitutionRule}
 * @see SubstitutionRule
 */
public enum SubstitutionMode {
	
	/**
	 *  Assign a user to receive tasks for another user. The rule will be used immediately.
	 */
	RECEIVE_TASKS, 
	
	/**
	 * Assign a nominee to receive tasks for another user. The rule needs to be taken over by the nominee to be used.
	 */
	TAKE_OVER;
}
