package com.sap.bpm.reporting.api;

import static java.lang.String.format;

import java.net.URI;

import com.sap.bpm.exception.api.BPMException;

/**
 * Thrown if accessing a reporting data source where incompatible changes have been made to a reporting field.
 */
public class ReportingFieldIncompatibilityException extends BPMException {
    private static final long serialVersionUID = 3188722180248141460L;

    /**
     * Constructs a new {@code ReportingFieldIncompatibilityException} object.
     * 
     * @param reportingFieldName
     *            the name of the reporting field the data type has not been compatibly changed.
     * @param reportingDataSourceId
     *            the identifier of the reporting data source where the reporting field was introduced.
     * @param reportingFieldDataType
     *            the original reporting field data type.
     * @param incompatibleReportingDataSourceId
     *            the identifier of the reporting data source where the incompatibility has been introduced.
     * @param incompatibleReportingFieldDataType
     *            the incompatible reporting field data type.
     */
    public ReportingFieldIncompatibilityException(final String reportingFieldName, final URI reportingDataSourceId, final String reportingFieldDataType,
            final URI incompatibleReportingDataSourceId, final String incompatibleReportingFieldDataType) {
        super(format("The field %1$s has been defined in the reporting data source %2$s with the data type %3$s "
                + "but it was changed in the reporting data source %4$s to %5$s which is not a compatible change.", reportingFieldName,
                reportingDataSourceId, reportingFieldDataType, incompatibleReportingDataSourceId, incompatibleReportingFieldDataType));
    }
}
