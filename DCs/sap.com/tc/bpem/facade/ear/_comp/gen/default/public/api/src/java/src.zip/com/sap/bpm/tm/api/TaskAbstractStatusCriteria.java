package com.sap.bpm.tm.api;

/**
 * Descriptor to specify the status for task abstract queries
 */

public class TaskAbstractStatusCriteria implements TaskAbstractQueryCriteria {

    private Status status;

    public TaskAbstractStatusCriteria(Status status) {
        this.status = status;
    }

    public Status getStatus() {
        return status;
    }

}
