package com.sap.bpm.tm.api;

import java.util.Locale;

/**
 * Custom action defined for a {@link TaskDefinition}.
 * <br>
 * <br>
 * <p><b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
public interface CustomActionDefinition {

    /**
     * Returns the name of the custom action defined.
     * 
     * @return the name
     */
    public String getName();

    /**
     * Returns the label of the custom action defined which is translated based on logged in user's {@link Locale}.
     * 
     * @return the label
     */
    public String getLabel();

    /**
     * Returns the description of the custom action defined which is translated based on logged in user's {@link Locale}.
     * 
     * @return the description
     */
    public String getDescription();

}
