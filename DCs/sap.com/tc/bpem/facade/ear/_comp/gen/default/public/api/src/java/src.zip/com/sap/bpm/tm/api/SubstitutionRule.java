package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.Date;

import com.sap.security.api.IUser;

/**
 * Substitution rules allow users to act as substitutes of other users.
 * <p>
 * Substitution rules are in general defined for a certain period of time, see {@link #getStartDate()} and {@link #getEndDate()}. The rules
 * are not "active" (not taken into account) outside of this time period. It is also possible to define rules without a certain time box (by
 * specifying no start and/or end date). Such rules will be active until they are either {@link SubstitutionRule#setEnabled(boolean)
 * disabled} or {@link SubstitutionRuleManager#deleteRule(SubstitutionRule) deleted}.
 * </p>
 * <p>
 * There are two different {@link SubstitutionMode substitution modes}:
 * </p>
 * <ul>
 * <li> {@link SubstitutionMode#RECEIVE_TASKS}: Assign a user to receive tasks for another user. The rule will be enabled immediately.</li>
 * <li> {@link SubstitutionMode#TAKE_OVER}: Assign a nominee to receive tasks for another user. The rule needs to be taken over by the
 * nominee to be enabled.</li>
 * </ul>
 * <p>
 * In order to define what tasks should be visible to the substituting user a {@link SubstitutionProfile} can be assigned to the
 * substitution rule.
 * </p>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 * @see SubstitutionRuleManager
 * @see SubstitutionMode
 * @see SubstitutionProfile
 */
public interface SubstitutionRule {

    /**
     * The id of the rule uniquely identifies it
     * 
     * @return the id of the rule
     */
    public URI getSubstitutionRuleId();

    /**
     * The end date of the rule defines the date when the rule will stop being available for usage
     * 
     * @return the end Date of the substitution (could be null)
     */
    public Date getEndDate();

    /**
     * If the substitution rule is enabled, it can be used, i.e. it is switched on.
     * 
     * @return true if the {@link SubstitutionRule} is switched on. Return false otherwise.
     */
    public boolean isEnabled();

    /**
     * Updates the enabled state of the rule.
     * 
     * @param isEnabled
     *            to specify the desired status of 'enabled'
     */
    public void setEnabled(boolean isEnabled);

    /**
     * Returns the {@link SubstitutionMode} which is either {@link SubstitutionMode#RECEIVE_TASKS} or {@link SubstitutionMode#TAKE_OVER}
     * 
     * @return the {@link SubstitutionMode}
     */
    public SubstitutionMode getMode();

    /**
     * The start date is the date when the rule becomes available for usage
     * 
     * @return the start Date of the substitution
     */
    public Date getStartDate();

    /**
     * The substituted {@link IUser} is the one, whose tasks are/could be taken by the substitute user
     * 
     * @return the substituted user defined for this rule
     * @throws SubstitutionRuleException
     *             if a problem occurs while resolving the user
     */
    public IUser getSubstitutedUser() throws SubstitutionRuleException;

    /**
     * The substituted user is the one, whose tasks are/could be taken by the substitute user
     * 
     * @return the id of the substituted user defined for this rule
     */
    public URI getSubstitutedUserId();

    /**
     * The substitute {@link IUser} is the one, who takes/could take tasks that are available for execution by the substituted user
     * 
     * @return the substitute user defined for this rule
     * @throws SubstitutionRuleException
     *             if a problem occurs while resolving the user
     */
    public IUser getSubstituteUser() throws SubstitutionRuleException;

    /**
     * The substitute user is the one, who takes/could take tasks that are available for execution by the substituted user
     * 
     * @return the substitute user id defined for this rule
     */
    public URI getSubstituteUserId();

    /**
     * This property is dynamically calculated
     * 
     * @return true if the rule is enabled, is taken over (if the rule is of type take over) and the time of invocation of this method is
     *         between the start and end dates of the rule. Returns false otherwise.
     */
    public boolean isActive();

    /**
     * Property used for {@link SubstitutionMode#TAKE_OVER}. Specifies whether the nominated user has chosen to take over the tasks. Has no
     * effect for other {@link SubstitutionMode}s.
     * 
     * @return true if the rule is taken over by the substitute. Returns false otherwise
     */
    public boolean isTakenOver();

    /**
     * Updates the {@link SubstitutionMode#TAKE_OVER} status of the rule. This property has meaning if the rule is of type
     * {@link SubstitutionMode#TAKE_OVER}.
     * 
     * @param isTakenOver
     *            to specify the desired status of 'takenOver'
     */
    public void setTakenOver(boolean isTakenOver);

    /**
     * Returns information about the substitution profile which is assigned to the substitution rule.
     * 
     * @return an instance of {@link SubstitutionProfileInfo} or <code>null</code> if no profile is assigned to the rule.
     */
    public SubstitutionProfileInfo getSubstitutionProfile();
}
