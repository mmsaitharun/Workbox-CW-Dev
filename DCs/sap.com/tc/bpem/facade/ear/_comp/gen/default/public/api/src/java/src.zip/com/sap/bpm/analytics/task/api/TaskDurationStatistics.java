/**
 * 
 */
package com.sap.bpm.analytics.task.api;

import java.net.URI;
import java.util.Date;

import com.sap.bpm.tm.api.Status;
import com.sap.bpm.tm.api.TaskModel;

/**
 * Represents the execution time statistics for a task model during a time interval and for a specific task instance status. The execution
 * time designates the time elapsed between the task instance creation and its termination or now if the task is not finished. It includes
 * thus the activation time, the waiting time (the time elapsed between the activation and the first claim) and the processing time.
 */
public interface TaskDurationStatistics {

    /**
     * Returns the lower task instance creation time limit used to select the task instances for the statistics computation.
     * 
     * @return the lower task instance creation time limit.
     */
    Date getStartTime();

    /**
     * Returns the upper task instance creation time limit used to select the task instances for the statistics computation.
     * 
     * @return the upper task instance creation time limit.
     */
    Date getEndTime();

    /**
     * Returns the name of the task model for which these statistics are computed.
     * 
     * @return the task model name.
     */
    public String getModelName();

    /**
     * Returns the identifier of the task model for which these statistics are computed.
     * 
     * @see TaskModel#getId()
     * 
     * @return the {@link URI} identifying the task model.
     */
    public URI getModelId();

    /**
     * Returns the status of the task instances selected to compute these statistics.
     * 
     * @return the status of the task instances selected to compute these statistics.
     */
    Status getStatus();

    /**
     * Returns the smallest execution time observed among the task instances selected for the statistics computation.
     * 
     * @return the minimum execution time in milliseconds.
     */
    long getMinExecutionTime();

    /**
     * Returns the average execution time of the task instances selected for the statistics computation.
     * 
     * @return the average execution time in milliseconds.
     */
    long getAvgExecutionTime();

    /**
     * Returns the longest execution time observed among the task instances selected for the statistics computation.
     * 
     * @return the maximum execution time in milliseconds.
     */
    long getMaxExecutionTime();

}
