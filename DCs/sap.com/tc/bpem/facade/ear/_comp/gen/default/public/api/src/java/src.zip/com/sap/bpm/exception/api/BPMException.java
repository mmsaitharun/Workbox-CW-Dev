package com.sap.bpm.exception.api;

/**
 * This is the base exception for all BPM related exceptions.
 */
public class BPMException extends RuntimeException {

    private static final long serialVersionUID = 32202L;

    public BPMException(final String message) {
        super(message);
    }

    public BPMException(final Throwable cause) {
        super(cause);
    }

    public BPMException(final String message, final Throwable cause) {
        super(message, cause);
    }

}
