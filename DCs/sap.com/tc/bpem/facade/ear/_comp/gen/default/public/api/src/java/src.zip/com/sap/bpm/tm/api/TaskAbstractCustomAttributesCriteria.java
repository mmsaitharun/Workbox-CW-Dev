package com.sap.bpm.tm.api;

/**
 * Marker interface to get custom attribute(s) value of {@link TaskAbstract} while querying using {@link TaskInstanceManager}.
 * 
 * @sap.ApiForReference
 */
public final class TaskAbstractCustomAttributesCriteria implements TaskAbstractQueryCriteria, TaskAbstractFetchCriteria {

    public TaskAbstractCustomAttributesCriteria() {}

}
