package com.sap.bpm.tm.api;

/**
 * Represents a task status.<br>
 * The statuses map to the following BPM meaning:<br>
 * CREATED: task is created but not yet activated<br>
 * READY: task is activated but no actual owner is assigned<br>
 * RESERVED: task is activated and has one actual owner assigned<br>
 * IN_PROGRESS: task is being executed by the actual owner<br>
 * COMPLETED: task has been completed by the actual owner<br>
 * SUSPENDED: task has been suspended<br>
 * FAILED: task execution has been finished with a fault response<br>
 * 
 * The available statuses are subject to be extended in later releases.
 */
public enum Status {

    /**
     * task is created but not yet activated
     */
    CREATED,
    /**
     * task is activated but no actual owner is assigned
     */
    READY,
    /**
     * task is activated and has one actual owner assigned
     */
    RESERVED,
    /**
     * task is being executed by the actual owner
     */
    IN_PROGRESS,
    /**
     * task has been completed by the actual owner
     */
    COMPLETED,
    /**
     * task has been suspended
     */
    SUSPENDED,
    /**
     * task execution has been finished with a fault response
     */
    FAILED


}
