package com.sap.bpm.tm.api;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.tm.api.TaskAbstractCustomAttributesValueFilterCriteria.TaskAbstractCustomAttributeDateFilterType;

/**
 * The abstract superclass to:
 * <ul>
 * <li>{@link TaskAbstractCustomAttributesValueFilterCriteria}</li>
 * <li>{@link TaskAbstractCustomAttributesRangeFilterCriteria}</li>
 * </ul>
 * Instances of the subclasses can be used also in conjunction with each others to specify filter criteria based on custom attribute values.
 * Refer to the detailed class description, respectively.
 * 
 * @sap.ApiForReference
 */
public abstract class TaskAbstractCustomAttributesFilterCriteria implements TaskAbstractFetchCriteria {

    /**
     * Enum containing the custom attribute types
     */
    public enum CustomAttributeTypeEnum {
        BOOLEAN,
        DATE,
        DATE_TIME,
        DECIMAL,
        FLOAT,
        INTEGER,
        LONG,
        STRING,
        TIME;

        /**
         * Converts the {@link TaskAbstractCustomAttributeDateFilterType} as provided by the caller of the API to the internal enum
         * representation.
         * 
         * @param dateFilterType
         *            value to be converted
         * @return the converted value
         */
        public static final CustomAttributeTypeEnum convertDateFilterType(TaskAbstractCustomAttributeDateFilterType dateFilterType) {
            if (dateFilterType == null) {
                throw new BPMIllegalArgumentException("Value for dateFilterType must not be null");
            }
            switch (dateFilterType) {
                case DATE_TIME:
                    return CustomAttributeTypeEnum.DATE_TIME;
                case DATE:
                    return CustomAttributeTypeEnum.DATE;
                case TIME:
                    return CustomAttributeTypeEnum.TIME;
                default:
                    throw new BPMIllegalArgumentException(String.format("filterType %s unknown", dateFilterType));
            }
        }
    }

    private final String customAttributeName;
    private final CustomAttributeTypeEnum customAttributeType;

    public TaskAbstractCustomAttributesFilterCriteria(final String customAttributeName, final CustomAttributeTypeEnum customAttributeType) {
        this.customAttributeName = customAttributeName;
        this.customAttributeType = customAttributeType;
    }

    /**
     * Returns the custom attribute name
     * 
     * @return custom attribute name
     * @throws BPMException
     *             In case of any error
     */
    public String getCustomAttributeName() throws BPMException {
        return customAttributeName;
    }

    /**
     * Returns the consolidated type of the custom attribute.
     * 
     * @return the consolidated type of the custom attribute
     */
    public CustomAttributeTypeEnum getCustomAttributeType() {
        return this.customAttributeType;
    }
}
