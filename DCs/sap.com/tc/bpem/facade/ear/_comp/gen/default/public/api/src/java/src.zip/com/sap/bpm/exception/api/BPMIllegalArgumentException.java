package com.sap.bpm.exception.api;

/**
 * This exception indicates that the method has been called with an invalid parameter.
 */
public class BPMIllegalArgumentException extends BPMException {

    private static final long serialVersionUID = 32202L;

    public BPMIllegalArgumentException(String message, Throwable cause) {
        super(message, cause);
    }

    public BPMIllegalArgumentException(String message) {
        super(message);
    }

    public BPMIllegalArgumentException(Throwable cause) {
        super(cause);
    }

}
