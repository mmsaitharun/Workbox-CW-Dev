package com.sap.bpm.api;

/**
 * Provides the central access point for the SAP NetWeaver BPM Process and Task Management Facade.
 * <br> 
 * The {@link BPMFactory} can be used to obtain the classes relevant for accessing and modifying Process and Tasks.
 */

