package com.sap.bpm.exception.api;

/**
 * This exception indicates that the operation is not applicable to the given object.
 */
public class BPMIllegalOperationException extends BPMException {

    private static final long serialVersionUID = 32202L;

    public BPMIllegalOperationException(String message, Throwable cause) {
        super(message, cause);
    }

    public BPMIllegalOperationException(String message) {
        super(message);
    }

    public BPMIllegalOperationException(Throwable cause) {
        super(cause);
    }

}
