package com.sap.bpm.pm.api;

import java.net.URI;
import java.util.Set;

import javax.ejb.Local;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMIllegalOperationException;
import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;

/**
 * Central access point for starting processes.
 * 
 * <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 */
@Local
public interface ProcessStartManager {

    /**
     * Returns a set of {@link ProcessStartEvent} for the given process definition ID.
     * 
     * @param processDefinitionId
     *            the ID of the process definition to be started.
     * @return a {@link Set} of {@link ProcessStartEvent}
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public Set<ProcessStartEvent> getProcessStartEvents(URI processDefinitionId) throws BPMException;

    /**
     * Creates a {@link DataObject} for the start event which can be used to pass input data.
     * 
     * @param event
     *            the start event for which the data object should be created.
     * @return an instance of {@link DataObject}
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public DataObject createDataObjectForStartEvent(ProcessStartEvent event) throws BPMException;

    /**
     * Returns the {@link HelperContext} for the given start event.<br>
     * Defining additional types in this HelperContext is not allowed.
     * 
     * @param event
     *            the start event for which a helper context should be returned.
     * @return an instance of {@link HelperContext}
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public HelperContext getHelperContextForStartEvent(ProcessStartEvent event) throws BPMException;

    /**
     * Starts the process for the given {@link ProcessStartEvent} with the data passed as input.
     * 
     * Note: Starting 'conditional start' processes (cf. SAP note 1706625) is not allowed via this API and will result in a
     * {@link BPMIllegalOperationException}.
     * 
     * @param event
     *            the start event which should be used to start the process.
     * @param input
     *            the input data which will be used to start the process.<br>
     *            It must be of a supported implementation (SAP) and matching type, otherwise the method will throw a
     *            {@link BPMIllegalArgumentException}.<br>
     *            Use {@link ProcessStartManager#createDataObjectForStartEvent(ProcessStartEvent)} to get a valid data object.
     * @return an instance of {@link URI}
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalOperationException
     *             if the caller wants to start a conditional start process
     */
    public URI startProcess(ProcessStartEvent event, DataObject input) throws BPMException;

}
