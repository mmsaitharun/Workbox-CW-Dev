package com.sap.bpm.analytics.process.api;

import java.net.URI;
import java.util.Date;

import com.sap.bpm.pm.api.ProcessStatus;

/**
 * Represents the execution time statistics for a process model during a time interval and for a specific process instance status. The
 * execution time designates the time elapsed between the process instance creation and its termination or now if the process instance is
 * still running.
 */
public interface ProcessDurationStatistics {

    /**
     * Returns the lower process instance creation time limit used to select the process instances for the statistics computation.
     * 
     * @return the lower process instance creation time limit.
     */
    Date getStartTime();

    /**
     * Returns the upper process instance creation time limit used to select the process instances for the statistics computation.
     * 
     * @return the upper process instance creation time limit.
     */
    Date getEndTime();

    /**
     * Returns the name of the process model for which these statistics are computed.
     * 
     * @return the process model name.
     */
    String getModelName();

    /**
     * Returns the identifier of the process model for which these statistics are computed.
     * 
     * @return the {@link URI} identifying the process model.
     */
    URI getModelId();

    /**
     * Returns the status of the process instances selected to compute these statistics.
     * 
     * @return the status of the process instances selected to compute these statistics.
     */
    ProcessStatus getStatus();

    /**
     * Returns the smallest execution time observed among the process instances selected for the statistics computation.
     * 
     * @return the minimum execution time in milliseconds.
     */
    long getMinExecutionTime();

    /**
     * Returns the average execution time of the process instances selected for the statistics computation.
     * 
     * @return the average execution time in milliseconds.
     */
    long getAvgExecutionTime();

    /**
     * Returns the longest execution time observed among the process instances selected for the statistics computation.
     * 
     * @return the maximum execution time in milliseconds.
     */
    long getMaxExecutionTime();

}
