package com.sap.bpm.tm.api;

/**
 * Provides classes for getting and manipulating tasks.<br>
 * <br>
 * Central access point for getting and manipulating task instances is the {@link TaskInstanceManager}.
 */

