package com.sap.bpm.tm.api;

import java.util.Locale;

/**
 * Custom attribute defined for a {@link TaskDefinition}. <br>
 * <br>
 * <br>
 * <p><b>NOTE</b>:  As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
public interface CustomAttributeDefinition {
	
	/**
	 * Returns the name of the custom attribute defined.
	 * 
	 * @return the name
	 */
	public String getName();
	
	/**
	 * Returns the type of the custom attribute defined.
	 * 
	 * @return the type
	 */
	public Class<?> getType();

	/**
	 * Returns the label of the custom attribute defined which is translated based on logged in user's {@link Locale}.
	 *  
	 * @return the label
	 */
	public String getLabel();

}
