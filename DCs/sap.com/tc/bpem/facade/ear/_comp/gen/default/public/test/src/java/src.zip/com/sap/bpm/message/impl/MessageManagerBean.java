package com.sap.bpm.message.impl;

import java.net.URI;

import javax.ejb.Stateless;

import com.sap.bpem.base.exception.IllegalAccessException;
import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMIllegalOperationException;
import com.sap.bpm.message.api.EventTrigger;
import com.sap.bpm.message.api.MessageManager;
import com.sap.glx.adapter.app.ucon.manager.UnifiedConnectivityManager;
import com.sap.tc.logging.Location;
import commonj.sdo.DataObject;

@Stateless(name = "MessageManager")
public class MessageManagerBean implements MessageManager {

    private static final Location LOCATION = Location.getLocation(MessageManagerBean.class);

    @Override
    public EventTrigger getEventTrigger(final String vendor, final String dcName, final String eventTriggerName) throws BPMException {
        final String SIGNATURE = "getEventTrigger(String, String , String )";
        if (LOCATION.beDebug()) {
            LOCATION.entering(SIGNATURE, new Object[] { vendor, dcName, eventTriggerName });
        }

        try {
            checkNull(vendor, "vendor");
            checkNull(vendor, "dcName");
            checkNull(vendor, "eventTriggerName");
            String serviceID = constructServiceID(vendor, dcName, eventTriggerName);
            
            if (LOCATION.beDebug()) {
                LOCATION.debugT(SIGNATURE, "Service ID:{0}", new Object[] { serviceID });
            }
            String operationName = UnifiedConnectivityManager.getOperationName(serviceID);
            if (LOCATION.beDebug()) {
                LOCATION.debugT(SIGNATURE, "Operation Name:{0}", new Object[] { operationName });
            }

            if (operationName == null || operationName.trim().isEmpty()) {
                throw new IllegalArgumentException(String.format(
                        "No event trigger found for the given inputs - Vendor name:%s, DC name:%s, Event trigger name:%s ", vendor, dcName,
                        eventTriggerName));
            }

            URI serviceIDURI = new URI(serviceID);
            EventTrigger eventTrigger = new EventTriggerImpl(serviceIDURI, operationName);
            return eventTrigger;
        } catch (final IllegalAccessException e) {
            throw new BPMIllegalAccessException(e);
        } catch (final IllegalArgumentException e) {
            throw new BPMIllegalArgumentException(e);
        } catch (final Exception e) {
            throw new BPMException(e);
        } finally {
            if (LOCATION.beDebug()) {
                LOCATION.exiting(SIGNATURE);
            }
        }
    }

    @Override
    public DataObject createDataObjectForEventTrigger(final EventTrigger eventTrigger) throws BPMException {
        final String SIGNATURE = "createDataObjectForEventTrigger(EventTrigger)";
        if (LOCATION.beDebug()) {
            LOCATION.entering(SIGNATURE, new Object[] { eventTrigger != null ? eventTrigger.getId() : eventTrigger });
        }

        try {
            checkNull(eventTrigger, "eventTrigger");

            EventTriggerImpl eventTriggerImpl = (EventTriggerImpl) eventTrigger;
            String serviceID = eventTrigger.getId().toString();
            String operationName = eventTriggerImpl.getOperationName();

            if (LOCATION.beDebug()) {
                LOCATION.debugT(SIGNATURE, "Service ID:{0}", new Object[] { serviceID });
                LOCATION.debugT(SIGNATURE, "Operation Name:{0}", new Object[] { operationName });
            }
            
            DataObject emptyDataObject = UnifiedConnectivityManager.createDataObject(serviceID, operationName);
            if (LOCATION.beDebug()) {
                LOCATION.debugT(SIGNATURE, "DataObject: {0}", new Object[] { emptyDataObject });
            }
            return emptyDataObject;
        } catch (final IllegalAccessException e) {
            throw new BPMIllegalAccessException(e);
        } catch (final IllegalArgumentException e) {
            throw new BPMIllegalArgumentException(e);
        } catch (final Exception e) {
            throw new BPMException(e);
        } finally {
            if (LOCATION.beDebug()) {
                LOCATION.exiting(SIGNATURE);
            }
        }
    }

    @Override
    public void sendMessage(EventTrigger eventTrigger, DataObject input) throws BPMException {
        final String SIGNATURE = "sendMessage(EventTrigger, DataObject )";
        if (LOCATION.beDebug()) {
            LOCATION.entering(SIGNATURE, new Object[] { eventTrigger != null ? eventTrigger.getId() : eventTrigger, input });
        }

        try {
            checkNull(eventTrigger, "eventTrigger");
            checkNull(input, "input");

            EventTriggerImpl eventTriggerImpl = (EventTriggerImpl) eventTrigger;
            String serviceID = eventTrigger.getId().toString();
            String operationName = eventTriggerImpl.getOperationName();
            if (LOCATION.beDebug()) {
                LOCATION.debugT(SIGNATURE, "Service ID:{0}", new Object[] { serviceID });
                LOCATION.debugT(SIGNATURE, "Operation Name:{0}", new Object[] { operationName });
            }
            UnifiedConnectivityManager.sendMessage(serviceID, operationName, input);

        } catch (final IllegalAccessException e) {
            throw new BPMIllegalAccessException(e);
        } catch (final IllegalArgumentException e) {
            throw new BPMIllegalArgumentException(e);
        } catch (final UnsupportedOperationException e) {
            throw new BPMIllegalOperationException(e);
        } catch (final Exception e) {
            throw new BPMException(e);
        } finally {
            if (LOCATION.beDebug()) {
                LOCATION.exiting(SIGNATURE);
            }
        }

    }

    private String constructServiceID(final String vendor, final String dcName, final String eventTriggerName) {
        String replacedDCName = dcName.replace('~', '/');
    	String serviceID = vendor + "/" + replacedDCName + "/" + eventTriggerName;
        return serviceID;
    }

    private void checkNull(final Object object, final String name) throws IllegalArgumentException {
        if (object == null) {
            throw new IllegalArgumentException("Parameter " + name + " must not be null.");
        }
    }
}
