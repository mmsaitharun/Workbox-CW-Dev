package com.sap.bpm.tm.api;

/**
 * Descriptor to specify the owner criteria for task abstract queries.
 * 
 * @sap.ApiForReference
 */
public final class TaskAbstractOwnerCriteria implements TaskAbstractFetchCriteria {

}
