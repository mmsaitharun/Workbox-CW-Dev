package com.sap.bpm.tm.api;

import java.net.URI;
import java.util.Date;

import com.sap.bpm.pm.api.ProcessInstance;
import com.sap.security.api.IUser;

/**
 * Represents all {@link Attachment}s
 */
public interface Attachment {

    /**
     * Returns a unique identifier of the attachment.
     * 
     * @return URI
     */
    public URI getId();

    /**
     * Returns an IUser object for the creator of the attachment.
     * 
     * @return IUser identifying the creator of the attachment
     */
    public IUser getCreatedBy();

    /**
     * Returns the creation date of the attachment.
     * 
     * @return The creation date of the attachment
     */
    public Date getCreatedOn();

    /**
     * Returns the scope defined for the {@link Attachment} as only visible for {@link TaskAbstract} or to the parent
     * {@link ProcessInstance}
     * 
     * @return the visibility of the {@link Attachment}
     */
    public boolean isLocal();

    /**
     * <p>
     * Returns the display name of the attachment the provided by the user.
     * </p>
     * 
     * @return the user provided display name
     */
    public String getDisplayName();

}
