package com.sap.bpm.reporting.api;

import static java.lang.String.format;

import java.net.URI;

import com.sap.bpm.exception.api.BPMException;

/**
 * Thrown when the requested reporting data source does not exist in the system.
 */
public class ReportingDataSourceNotFoundException extends BPMException {
    private static final long serialVersionUID = -468446944339323398L;

    /**
     * Constructs a new {@code ReportingDataSourceNotFoundException} object when the requested reporting data source does not exist in the
     * system.
     * 
     * @param reportingDataSourceId
     *            the identifier of the requested reporting data source.
     */
    public ReportingDataSourceNotFoundException(final URI reportingDataSourceId) {
        super(format("Can't find any reporting data source identified by %1$s in the system.", reportingDataSourceId));
    }

    /**
     * Constructs a new {@code ReportingDataSourceNotFoundException} object when a error caused the requested reporting data source not to
     * be found.
     * 
     * @param reportingDataSourceId
     *            the identifier of the requested reporting data source.
     * @param cause
     *            the error that causes the reporting data source not to be found.
     */
    public ReportingDataSourceNotFoundException(final URI reportingDataSourceId, final Throwable cause) {
        super(format("Can't find the reporting data source identified by %1$s in the system: %2$s.", reportingDataSourceId, cause
                .getMessage()), cause);
    }
}
