package com.sap.bpm.pm.api;

import java.net.URI;
import java.net.URL;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import javax.ejb.Local;

import com.sap.bpm.api.QueryResultParameters;
import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMIllegalStateException;
import com.sap.bpm.exception.api.BPMNotSupportedException;

/**
 * Central access point for getting and handling process instances. <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
@Local
public interface ProcessInstanceManager {

    /**
     * Returns the {@link ProcessDefinition} of the {@link ProcessInstance} specified by the given id.
     * 
     * @deprecated Use {@link #getProcessDefinition(URI)} to retrieve the {@code ProcessDefinition} of a the specified process instance.
     * @param processInstanceId
     *            a process instance identifier.
     * @return an instance of {@link ProcessDefinition}
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    @Deprecated
    public ProcessDefinition getProcessDefintion(URI processInstanceId) throws BPMException;

    /**
     * Returns the {@link ProcessDefinition} of the {@link ProcessInstance} specified by the given identifier.
     * 
     * @param processInstanceId
     *            a process instance identifier.
     * @return the {@link ProcessDefinition} object representing the version of the given process instance.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if <code>processInstanceId</code> URI is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it is a
     *             valid BPM URI but not a process instance URI)</li>
     *             <li>if there is no process instance for the specified <code>processInstanceId</code></li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation.
     * @throws BPMException
     *             if an error occurred while retrieving the process definition information of the given process instance.
     */
    public ProcessDefinition getProcessDefinition(URI processInstanceId) throws BPMException;

    /**
     * Returns the {@link ProcessInstance} for the given process instance ID.
     * 
     * @param processInstanceId
     *            the ID of the process instance to be returned.
     * @return an instance of {@link ProcessInstance}.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if <code>processInstanceId</code> URI is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it is a
     *             valid BPM URI but not a process instance URI)</li>
     *             <li>if there is no process instance for the specified <code>processInstanceId</code></li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public ProcessInstance getProcessInstance(URI processInstanceId) throws BPMException;
    
    /**
     * Returns the {@link java.util.Collection} of all {@link commonj.sdo.DataObject} from the process context for the given process instance ID.
     * 
     * @param processInstanceId
     *            the ID of the process instance.
     * @return a collection of all {@link commonj.sdo.DataObject} from the process instance context.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if <code>processInstanceId</code> URI is invalid (e.g. it is <code>null</code>, it is not valid BPM URI, it is
     *             valid BPM URI but not a process instance URI)</li>
     *             <li>if there is no process instance for the specified <code>processInstanceId</code></li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public Collection<commonj.sdo.DataObject> getProcessInstanceContextData(URI processInstanceId) throws BPMException;
    
    /**
     * Returns a specific {@link commonj.sdo.DataObject} with a specified name from the process context for the given process instance ID.
     * 
     * @param processInstanceId
     *            the ID of the process instance.
     * @param dataObjectName
     *            the name of the data object to be returned.         
     * @return an instance of {@link commonj.sdo.DataObject}.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if <code>processInstanceId</code> URI is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it is a
     *             valid BPM URI but not a process instance URI)</li>
     *             <li>if there is no process instance for the specified <code>processInstanceId</code></li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public commonj.sdo.DataObject getProcessInstanceContextDataObject(URI processInstanceId, String dataObjectName) throws BPMException;

    /**
     * Returns a Set of the running {@link ProcessInstance}s of the given {@link ProcessDefinition}
     * 
     * @param processDefinition
     *            the process definition of which the process instances should be returned
     * @return a {@link Set} of {@link ProcessInstance}s.
     * @throws BPMIllegalArgumentException
     *             if <code>processDefinition</code> URI is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it is a valid
     *             BPM URI but not a process definition URI)
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public Set<ProcessInstance> getRunningProcessInstances(URI processDefinition) throws BPMException;

    /**
     * Returns the parent process instance for the given task instance ID.
     * 
     * @param taskInstanceId
     *            ID of task instance, for which the parent process instance should be retrieved
     * @return an instance of {@link ProcessInstance}
     * @throws BPMIllegalArgumentException
     *             if <code>taskInstanceId</code> URI is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it is a valid BPM
     *             URI but not a task instance URI)
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public ProcessInstance getProcessInstanceForTaskInstanceId(URI taskInstanceId) throws BPMException;

    /**
     * Returns an absolute URL to the Process Visualization for the given process instance ID. Can be used to embed it into custom UI or to
     * display the hyperlink. The application property 'http.baseurl' (tc~bpem~base~ear) will be used to determine the target server and
     * port address.
     * 
     * @param processInstanceId
     *            a process instance identifier.
     * @return an {@link URL} to the Process Visualization
     * @throws BPMIllegalArgumentException
     *             if <code>processInstanceId</code> URI is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it is a valid
     *             BPM URI but not a process instance URI)
     */
    public URL generateProcessInstanceVisualizationURL(URI processInstanceId) throws BPMException;

    /**
     * Cancels the process instance identified by parameter processInstanceId. On successful call of this API, the status of the specified
     * process instance changes to {@link ProcessStatus#CANCELLED}. {@link ProcessStatus#CANCELLED} is one of the final states for a process
     * instance. Once a process is cancelled, its status can not be changed later to any other statuses.
     * 
     * @param processInstanceId
     *            process instance that has to be cancelled.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if <code>processInstanceId</code> URI is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it is a
     *             valid BPM URI but not a process instance URI)</li>
     *             <li>if there is no process instance for the specified <code>processInstanceId</code></li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             <ul>
     *             <li>if the user is not authorised to access the process instance</li>
     *             <li>if the user is not authorised to cancel the process instance</li>
     *             </ul>
     * @throws BPMIllegalStateException
     *             if the process is not in state from where it can be cancelled e.g if the process is already completed or cancelled.
     * @throws BPMException
     *             if a technical error occurred while cancelling the process instance.
     */
    public void cancel(URI processInstanceId) throws BPMException;

    /**
     * Suspends the process instance identified by parameter <code>processInstanceId</code>. On successful call, the status of the specified
     * process instance changes to {@link ProcessStatus#SUSPENDED}. In case status of the specified process instance is
     * {@link ProcessStatus#SUSPENDED} it will not be changed. The suspended process instance can be resumed via {@link #resume(URI)} method
     * call.
     * 
     * @param processInstanceId
     *            process instance that has to be suspended.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if <code>processInstanceId</code> URI is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it is a
     *             valid BPM URI but not a process instance URI)</li>
     *             <li>if there is no process instance for the specified <code>processInstanceId</code></li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             <ul>
     *             <li>if the user is not authorised to access the process instance</li>
     *             <li>if the user is not authorised to suspend the process instance</li>
     *             </ul>
     * @throws BPMIllegalStateException
     *             if the process is not in state from where it can be suspended, e.g if the process is completed or cancelled.
     * @throws BPMException
     *             if a technical error occurred while suspending the process instance.
     */
    public void suspend(URI processInstanceId) throws BPMException;

    /**
     * Resumes the suspended process instance identified by parameter <code>processInstanceId</code>. On successful call, the status of the
     * specified process instance changes to {@link ProcessStatus#IN_PROGRESS}. In case status of the specified process instance is
     * {@link ProcessStatus#IN_PROGRESS} it will not be changed.
     * 
     * @param processInstanceId
     *            process instance that has to be resumed.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if <code>processInstanceId</code> URI is invalid (e.g. it is <code>null</code>, it is not a valid BPM URI, it is a
     *             valid BPM URI but not a process instance URI)</li>
     *             <li>if there is no process instance for the specified <code>processInstanceId</code></li>
     *             </ul>
     * @throws BPMIllegalAccessException
     *             <ul>
     *             <li>if the user is not authorised to access the process instance</li>
     *             <li>if the user is not authorised to resume the process instance</li>
     *             </ul>
     * @throws BPMIllegalStateException
     *             if the process is not in state from where it can be resumed, e.g if the process is completed or cancelled.
     * @throws BPMException
     *             if a technical error occurred while resuming the process instance.
     */
    public void resume(URI processInstanceId) throws BPMException;

    /**
     * Returns a {@link List} of {@link ProcessInstance}s matching the given <code>queryCriteria</code>.
     * 
     * @param resultParameters
     *            - instance of {@link QueryResultParameters} allowing to specify how many process instances should be skipped from the
     *            beginning of the returned list and the maximum number of the instances to be returned. In case <code>null</code> is
     *            specified as the parameter value no process instances will be skipped and the maximum number of the returned instances
     *            will be equal to the value of pm.processinstances.maxresults property specified for com.sap.glx.process.ear application.
     * @param queryCriteria
     *            - instance(s) of {@link ProcessInstanceFilterCriteria} representing how the returned process instances should be filtered.
     *            Using the <code>queryCriteria</code> parameter it is possible to define fitering expressions connected with AND or OR
     *            operators. In case a {@link ProcessInstanceFilterCriteria} is defined with multiple filtering values it will be treated as
     *            a number of criterias for each of the filtering values connected with OR operator. The same can be achieved by providing
     *            multiple {@link ProcessInstanceFilterCriteria}s with the same filtering property and the filtering operator but for the
     *            different filtering values. In case multiple {@link ProcessInstanceFilterCriteria}s are provided for the different process
     *            instance properties or for the same property but using different filtering operators they will be connected with AND
     *            operator. In this case for a process instance to be returned it should satisfy all the specified
     *            {@link ProcessInstanceFilterCriteria}s.
     *            <p>
     *            <b>Exemplary Usage</b>
     *            <p>
     *            The given example shows how to get suspended or completed process instances for a particular process definition:
     * 
     *            <pre>
     * URI processDefinitionId = new URI(&quot;bpm://bpm.sap.com/process-definition/0cf1244ae444825d2f1d8d0823ccb6f7&quot;);
     * ProcessInstanceManager processInstanceManager = BPMFactory.getProcessInstanceManager();
     * 
     * List&lt;ProcessInstance&gt; processInstances = processInstanceManager
     *         .getProcessInstances(new ProcessInstanceFilterCriteria(ProcessInstanceProperty.STATUS, ProcessInstanceFilterOperator.EQUALS,
     *                 ProcessStatus.SUSPENDED, ProcessStatus.COMPLETED), new ProcessInstanceFilterCriteria(ProcessInstanceProperty.DEFINITION_ID,
     *                 ProcessInstanceFilterOperator.EQUALS, processDefinitionId));
     * </pre>
     *            <p>
     *            The example below shows how to get all the process instances which have been started in a particular period of time:
     * 
     *            <pre>
     * ProcessInstanceManager processInstanceManager = BPMFactory.getProcessInstanceManager();
     * List&lt;ProcessInstance&gt; processInstances = processInstanceManager.getProcessInstances(new ProcessInstanceFilterCriteria(
     *         ProcessInstanceProperty.START_DATE, ProcessInstanceFilterOperator.FROM, fromDate), new ProcessInstanceFilterCriteria(
     *         ProcessInstanceProperty.START_DATE, ProcessInstanceFilterOperator.TO, toDate));
     * </pre>
     *            <P>
     *            In the example, both <code>fromDate</code> and <code>toDate</code> are instances of {@link java.util.Date}.
     *            </p>
     *            <p>
     *            This parameter is required.
     *            </p>
     * @return {@link List} of {@link ProcessInstance}s matching the given <code>queryCriteria</code>. The returned list is additionally
     *         filtered according to the permissions of the current user to read the returned process instances.
     * @throws BPMIllegalArgumentException
     *             <ul>
     *             <li>if <code>queryCriteria</code> parameter is not specified</li>
     *             <li>if <code>null</code> value is specified for <code>
     *             queryCriteria</code> parameter</li>
     *             <li>if <code>queryCriteria</code> parameter contains an invalid value for a {@link ProcessInstanceProperty}. For example
     *             if Process Definition ID is specified as an invalid BPM URI.</li>
     *             </ul>
     * @throws BPMNotSupportedException
     *             if <code>queryCriteria</code> is defined using an unsupported {@link ProcessInstanceFilterOperator} for a
     *             {@link ProcessInstanceProperty}.
     * @throws BPMException
     *             if a technical error occurred while getting the process instances.
     */
    public List<ProcessInstance> getProcessInstances(QueryResultParameters resultParameters, ProcessInstanceQueryCriteria... queryCriteria)
            throws BPMException;
}
