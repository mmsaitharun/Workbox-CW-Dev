package com.sap.bpm.analytics.process.api;

import java.net.URI;
import java.util.Date;

import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.pm.api.ProcessStatus;

/**
 * Represents the status statistics for a process model during a time interval.
 */
public interface ProcessStatusStatistics {

    /**
     * Returns the lower process instance creation time limit used to collect the process instances for this statistic.
     * 
     * @return the lower process instance creation time limit.
     */
    Date getStartTime();

    /**
     * Returns the upper process instance creation time limit used to collect the process instances for this statistic.
     * 
     * @return the upper process instance creation time limit.
     */
    Date getEndTime();

    /**
     * Returns the number of process instances collected for this statistic having the given status.
     * 
     * @param status
     *            a process instance status.
     * @return the number of collected process instances with the given status.
     * @throws BPMIllegalArgumentException
     *             if the given {@link ProcessStatus} is not supported by the statistic.
     */
    int getInstanceCount(ProcessStatus status) throws BPMIllegalArgumentException;

    /**
     * Returns the identifier of the process model for which this statistic is computed.
     * 
     * @return the {@link URI} identifying the process model.
     */
    URI getModelId();

    /**
     * Returns the name of the process model for which this statistic is computed.
     * 
     * @return the process model name.
     */
    String getModelName();

}
