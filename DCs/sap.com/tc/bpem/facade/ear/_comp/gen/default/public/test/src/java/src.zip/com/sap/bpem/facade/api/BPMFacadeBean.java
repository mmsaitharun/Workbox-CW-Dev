package com.sap.bpem.facade.api;
import java.util.List;

import javax.ejb.Local;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 * <p>The BPMService currently provides functionality to query for active processes and their description.</p>
 */
@Local
@WebService()
public interface BPMFacadeBean {

    /**
     * <p>Returns all active processes from the BPM server.</p><p>'Active' in that context
     * means that it is possible to create process instances based on those definitions.
     * The result is a (possibly empty) list of process info objects containing basically the name of 
     * the process definition and several important identifiers. That is the reason that the operation
     * requires the <b>locale</b> to be set, so that the name is resolved in the correct language.</p>
     * 
     * @param locale a valid String representation of a {@link java.util.Locale} or null in case the VM's default should be used.
     * 
     * @return A list of processes which are active on the server. May be empty, but never null.
     *  
     * @throws IllegalArgumentException Thrown in case one of the parameters is not set properly.
     * @throws BPMServiceException Thrown in case of internal errors from which one could not recover easily or if the requesting user is not authorized.
     */
    @WebMethod
    public List<ProcessInfo> getActiveProcesses(@WebParam(name="locale") String locale);
    
    /**
     * <p>Retrieves the description of one particular process.</p>
     * 
     * @param activeVersionId	a valid String representation of the (version) ID of the process, not null.
     * @param locale			a valid String representation of a {@link java.util.Locale} or null in case the VM's default should be used.
     * 
     * @return The description of the process. May be empty if process was not found or description was not set, but never null.
     * 
     * @throws IllegalArgumentException Thrown in case one of the parameters is not set properly.
     * @throws BPMServiceException Thrown in case of internal errors from which one could not recover easily or if the requesting user is not authorized.     
     */
    @WebMethod
    public String getProcessDescription(@WebParam(name="activeVersionId") String activeVersionId, @WebParam(name="locale") String locale);

    /**
     * <p>Retrieves detailed information of one particular process.</p>
     * 
     * @param activeVersionId	a valid String representation of the (version) ID of the process, not null.
     * @param locale 			a valid String representation of a {@link java.util.Locale} or null in case the VM's default should be used.
     * 
     * @return The details of the process. May be null if process was not found
     * 
     * @throws IllegalArgumentException Thrown in case one of the parameters is not set properly.
     * @throws BPMServiceException Thrown in case of internal errors from which one could not recover easily or if the requesting user is not authorized.   
     */
    @WebMethod
    public ProcessDetails getProcessDetails(@WebParam(name="activeVersionId") String activeVersionId, @WebParam(name="locale") String locale);
    
    /**
     * <p>This operation checks if the BPM solution has been used / is used at all.</p>
     * 
     * @return A Boolean indicating the usage of the BPM solution.
     * 
     * @throws BPMServiceException Thrown in case of internal errors from which one could not recover easily or if the requesting user is not authorized.
     */
    @WebMethod
    public boolean isBPMSInUse();
    
    /**
     * <p>This operation returns the license audit information between <i>per_start</i> and <i>per_end</i>.</p>
     * 
     * @param per_start The point in time the audit period starts, not null, format needs to be 'yyyyMMdd'
     * @param per_end The point in time the audit period ends, not null, format needs to be 'yyyyMMdd'
     * 
     * @return An array of audit objects. Currently there are 2 metrics:
     * 			(0) Deployed process definitions (snapshot)
     * 			(1) Process instances (started or completed in the interval or started before and still running or completed after the interval)
     * 
     * @throws BPMServiceException Thrown in case of internal errors from which one could not recover easily or if the requesting user is not authorized.
     */
    @WebMethod
    public LicenseAuditObject[] retrieveLicenseAuditObjects(@WebParam(name="per_start") String per_start, @WebParam(name="per_end") String per_end);
    
}
