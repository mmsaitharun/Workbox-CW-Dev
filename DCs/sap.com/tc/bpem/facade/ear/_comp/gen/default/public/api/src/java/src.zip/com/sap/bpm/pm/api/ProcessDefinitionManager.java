package com.sap.bpm.pm.api;

import java.net.URI;
import java.util.Locale;
import java.util.Set;

import javax.ejb.Local;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * Central access point for getting {@link ProcessDefinition} objects. <br>
 * For starting a process associated with a {@link ProcessDefinition} use the {@link ProcessStartManager}. <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 */
@Local
public interface ProcessDefinitionManager {

    /**
     * Returns the active {@link ProcessDefinition} for the given process definition ID in the specified {@link Locale}.
     * 
     * @param processDefinitionId
     *            the ID of the process definition to be returned.
     * @return an instance of {@link ProcessDefinition}.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid or if the {@link ProcessDefinition} for the given {@link URI} does not exist.
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public ProcessDefinition getProcessDefinition(URI processDefinitionId) throws BPMException;

    /**
     * Returns the active {@link ProcessDefinition} for the given vendor name, development component name, process technical name.
     * 
     * @param vendor
     *            the development component vendor of the process definition to be returned (e.g. "company.com").
     * @param dcName
     *            the development component name of the process definition to be returned (e.g. "tc~test~dc").
     * @param processTechnicalName
     *            the technical name of the process definition to be returned.
     * @return a set of {@link ProcessDefinition}.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid or if no {@link ProcessDefinition} for the given combination of vendor, dcName and
     *             processTechnicalName exists.
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public ProcessDefinition getActiveProcessDefinition(String vendor, String dcName, String processTechnicalName) throws BPMException;

    /**
     * Returns a {@link Set} of all active {@link ProcessDefinition} deployed on the server.
     * 
     * @return a {@link Set} of {@link ProcessDefinition}
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     */
    public Set<ProcessDefinition> getActiveProcessDefinitions() throws BPMException;

}
