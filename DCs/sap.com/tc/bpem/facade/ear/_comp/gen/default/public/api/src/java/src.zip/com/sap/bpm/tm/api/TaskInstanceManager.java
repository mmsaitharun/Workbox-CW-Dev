package com.sap.bpm.tm.api;

import java.net.URI;
import java.net.URL;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.Local;

import com.sap.bpm.api.QueryResultParameters;
import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.exception.api.BPMIllegalAccessException;
import com.sap.bpm.exception.api.BPMIllegalArgumentException;
import com.sap.bpm.exception.api.BPMIllegalOperationException;
import com.sap.bpm.exception.api.BPMIllegalStateException;
import com.sap.bpm.exception.api.BPMTaskAlreadyClaimedByAnotherUserException;
import com.sap.bpm.pm.api.ProcessInstance;
import com.sap.security.api.IUser;
import commonj.sdo.DataObject;

/**
 * Central access point for getting and manipulating task instances. <br>
 * <br>
 * <p>
 * <b>NOTE</b>: As this interface can be extended, this interface can be freely used, but must not be implemented.
 * 
 * @sap.ApiForReference
 */
@Local
public interface TaskInstanceManager {

    /**
     * Claim responsibility for the task, i.e. set the task to status <i>Reserved</i> and set the current user as the actual owner.
     * 
     * @param taskInstanceId
     *            task identifier
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalOperationException
     *             if the operation does not apply to the task type
     * @throws BPMTaskAlreadyClaimedByAnotherUserException
     *             if the task is already claimed by another user
     */
    public void claim(URI taskInstanceId) throws BPMException;

    /**
     * Start the execution of the task, i.e. set the task to status <i>InProgress</i>.
     * 
     * @param taskInstanceId
     *            task identifier
     * @throws BPMIllegalStateException
     *             if the state is invalid
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalOperationException
     *             if the operation does not apply to the task type
     */
    public void start(URI taskInstanceId) throws BPMException;

    /**
     * Stop the processing of the task. The task returns to the <i>Reserved</i> state.
     * 
     * @param taskInstanceId
     *            task identifier
     * @throws BPMIllegalStateException
     *             if the state is invalid
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalOperationException
     *             if the operation does not apply to the task type
     */
    public void stop(URI taskInstanceId) throws BPMException;

    /**
     * Complete the processing of the task, i.e. set the task to status <i>Completed</i>.
     * 
     * @param taskInstanceId
     *            task identifier
     * @param taskOutputData
     *            the output data that will be used to complete the task.<br>
     *            It must be of a supported implementation (SAP) and matching type, otherwise the method will throw a
     *            {@link BPMIllegalArgumentException}.<br>
     *            Use {@link TaskDetail#getOutputDataObject()} to get a valid data object.
     * @throws BPMIllegalStateException
     *             if the state is invalid
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalOperationException
     *             if the operation does not apply to the task type
     */
    public void complete(URI taskInstanceId, DataObject taskOutputData) throws BPMException;

    /**
     * Complete the processing of the task, i.e. set the task to status <i>Completed</i> with custom action.
     * 
     * @param taskInstanceId
     *            task identifier
     * @param taskOutputData
     *            the output data that will be used to complete the task.<br>
     *            It must be of a supported implementation (SAP) and matching type, otherwise the method will throw a
     *            {@link BPMIllegalArgumentException}.<br>
     *            Use {@link TaskDetail#getOutputDataObject()} to get a valid data object.
     * @param customAction
     *            Custom action chosen to complete the task.
     * @throws BPMIllegalStateException
     *             if the state is invalid
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalOperationException
     *             if the operation does not apply to the task type
     */
    public void complete(URI taskInstanceId, DataObject taskOutputData, CustomAction customAction) throws BPMException;

    /**
     * Claim responsibility for the task by setting the current user as the actual owner and then complete the processing of the task, i.e.
     * set the task to status <i>Completed</i> with custom action.
     * 
     * @param taskInstanceId
     *            task identifier
     * @param taskOutputData
     *            the output data that will be used to complete the task.<br>
     *            It must be of a supported implementation (SAP) and matching type, otherwise the method will throw a
     *            {@link BPMIllegalArgumentException}.<br>
     *            Use {@link TaskDetail#getOutputDataObject()} to get a valid data object.
     * @param customAction
     *            Custom action chosen to complete the task.
     * @throws BPMIllegalStateException
     *             if the state is invalid
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalOperationException
     *             if the operation does not apply to the task type
     * @throws BPMTaskAlreadyClaimedByAnotherUserException
     *             if the task is already claimed by another user
     */
    public void claimAndComplete(URI taskInstanceId, DataObject taskOutputData, CustomAction customAction) throws BPMException;

    /**
     * Returns the details of the task with the given task instance id.
     * 
     * @param taskInstanceId
     *            task identifier
     * @return an instance of {@link TaskDetail}.
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid or if the task instance for the given {@link URI} does not exist.
     */
    public TaskDetail getTaskDetail(URI taskInstanceId) throws BPMException;

    /**
     * Returns an abstract of the task with the given task instance id.
     * 
     * @param taskInstanceId
     *            task identifier
     * @return an instance of {@link TaskAbstract}.
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid or if the task instance for the given {@link URI} does not exist.
     */
    public TaskAbstract getTaskAbstract(URI taskInstanceId) throws BPMException;

    /**
     * Returns an abstract of the task with the given task instance id and specified language.
     * 
     * @param taskInstanceId
     *            task identifier
     * @param language
     *            parameter of type {@link String} specifying the locale of the fetched result.
     * @return an instance of {@link TaskAbstract}.
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid or if the task instance for the given {@link URI} does not exist.
     */
    public TaskAbstract getTaskAbstract(URI taskInstanceId, String language) throws BPMException;

    /**
     * Returns an abstract of the task with the given task instance id.
     * 
     * @param taskInstanceId
     *            task identifier
     * @param customAttributesCriteria
     *            an instance of {@link TaskAbstractCustomAttributesCriteria} indicating Custom Attributes to be included
     * @return an instance of {@link TaskAbstract}.
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid or if the task instance for the given {@link URI} does not exist.
     */
    public TaskAbstract getTaskAbstract(URI taskInstanceId, TaskAbstractCustomAttributesCriteria customAttributesCriteria)
            throws BPMException;
    
    /**
     * Returns an abstract of the task with the given task instance id and specified language.
     * 
     * @param taskInstanceId
     *            task identifier
     * @param customAttributesCriteria
     *            an instance of {@link TaskAbstractCustomAttributesCriteria} indicating Custom Attributes to be included
     * @param language
     *            parameter of type {@link String} specifying the locale of the fetched results.
     * @return an instance of {@link TaskAbstract}.
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid or if the task instance for the given {@link URI} does not exist.
     */
    public TaskAbstract getTaskAbstract(URI taskInstanceId, TaskAbstractCustomAttributesCriteria customAttributesCriteria, String language)
            throws BPMException;

    /**
     * Returns a list of {@link TaskAbstract} for which the user with the given <code>logonID</code> is the task processor. Returns an empty
     * list if no tasks are found for the specified <code>logonID</code>.
     * <p>
     * Allows also to apply parameters to specify task statuses, parameters to sort the result and parameters to specify the exact chunk to
     * be returned. This can also be used to provide paging for the returned tasks.
     * </p>
     * <p>
     * Please note: When applying the firstResult parameter to {@link QueryResultParameters} the returned result is stateless. This means
     * the result may have skipped entries or it contains entries which were returned by a previous query with a different firstResult.
     * </p>
     * <p>
     * Example usage: To fetch a maximum of two tasks for a user, which are ready or in progress and are sorted based on their created time
     * in ascending order, code would look similar to :
     * </p>
     * 
     * <pre>
     * String logonID = &quot;Rahul&quot;;
     * 
     * QueryResultParameters qrp = new QueryResultParameters();
     * qrp.setFirstResult(0);
     * qrp.setMaxResults(2);
     * 
     * TaskAbstractStatusCriteria includeReadyTask = new TaskAbstractStatusCriteria(Status.READY);
     * TaskAbstractStatusCriteria includeInProgressTask = new TaskAbstractStatusCriteria(Status.IN_PROGRESS);
     * 
     * TaskAbstractAttribute attributeToSortOn = TaskAbstractAttribute.CREATED_TIME;
     * boolean isAscending = true;
     * TaskAbstractSortCriteria sortCriteria = new TaskAbstractSortCriteria(attributeToSortOn, isAscending);
     * 
     * TaskInstanceManager taskInstanceManager = BPMFactory.getTaskInstanceManager();
     * taskInstanceManager.getTaskAbstractByLogonID(logonID, qrp, includeReadyTask, includeInProgressTask, sortCriteria);
     * </pre>
     * 
     * @param logonID
     *            logon ID of the user whose tasks are to be fetched.
     * @param resultParameters
     *            Optional set of parameters to specify result size and offset. May be <code>null</code>.
     * @param queryCriteria
     *            Optional set of {@link TaskAbstractQueryCriteria} instances specifying query parameters to sort,to get custom attribute(s)
     *            value as part of {@link TaskAbstract} and to specify the statuses the returned tasks should be in. May be
     *            <code>null</code>. For sorting, see {@link TaskAbstractSortCriteria} for the supported attributes to sort on. To get
     *            custom attribute(s) value of {@link TaskAbstract}, use an instance of {@link TaskAbstractCustomAttributesCriteria}.To
     *            specify statuses, use an instance of {@link TaskAbstractStatusCriteria}.
     * @return a list of {@link TaskAbstract} as returned by the underlying query.
     * @throws BPMIllegalArgumentException
     *             if the passed <code>logonID</code> is null or empty
     * @throws BPMIllegalAccessException
     *             if the logged on user is not authorized to perform the operation
     */

    public List<TaskAbstract> getTaskAbstractsByLogonID(String logonID, QueryResultParameters resultParameters,
            TaskAbstractQueryCriteria... queryCriteria) throws BPMException;

    /**
     * <p>
     * Returns the set of instances of type {@link TaskAbstract} for the logged in user and for the specified task statuses. This method
     * caters to the need of creating end user task lists. Hence, only tasks of which the logged in user is actual owner or potential owner
     * (and no one else has claimed the task yet) are returned.
     * </p>
     * <p>
     * Note that the current implementation will not return any tasks in states <i>Failed</i> and <i>Suspended</i>.
     * </p>
     * 
     * @param statuses
     *            Set of valid states the returned tasks should be in. Note that the states <i>Failed</i> and <i>Suspended</i> are not
     *            considered as valid states for end user task lists.<br>
     *            If <tt>null</tt> is provided as argument, the abstracts for the tasks in all valid states are returned.
     * @return a set of instances of {@link TaskAbstract}
     * @throws BPMException
     *             if the argument contains invalid states
     */
    public Set<TaskAbstract> getMyTaskAbstracts(Set<Status> statuses) throws BPMException;

    /**
     * Returns the set of instances of {@link TaskAbstract} for the logged in user and for the specified task statuses. If <tt>null</tt> is
     * provided as argument, the abstracts for the tasks with a valid status are returned.
     * <p>
     * Allows also to apply parameters to sort the result and parameters to specify the exact chunk to be returned. This can be used to
     * provide paging for the returned tasks.
     * </p>
     * <p>
     * Please note: When applying the firstResult parameter to {@link QueryResultParameters} the returned result is stateless. This means
     * the result may have skipped entries or contain entries which were returned by a previous query with a different firstResult.
     * </p>
     * 
     * @param statuses
     *            A {@link Set} of {@link Status} of the tasks to be returned
     * @param resultParameters
     *            Optional set of parameters to specify result size and offset. May be <code>null</code>
     * @param queryCriteria
     *            Optional set of {@link TaskAbstractQueryCriteria} instances specifying query parameters for sort and to get custom
     *            attribute(s) value as part of {@link TaskAbstract}. May be <code>null</code>. For sorting, see
     *            {@link TaskAbstractSortCriteria} for the supported attributes to sort on. To get custom attribute(s) value of
     *            {@link TaskAbstract}, use an instance of {@link TaskAbstractCustomAttributesCriteria}.
     * @return a list of instances of {link TaskAbstract} as returned by the underlying query.
     * @throws BPMException
     *             In case of any error
     */
    public List<TaskAbstract> getMyTaskAbstracts(Set<Status> statuses, QueryResultParameters resultParameters,
            TaskAbstractQueryCriteria... queryCriteria) throws BPMException;

    /**
     * Returns the set of instances of {@link TaskAbstract} for a given process instance. The results can be filtered by statuses and
     * contains all tasks that are visible to him (e.g. as Task Administrator).
     * 
     * @param processInstanceId
     *            a process instance identifier.
     * @param statuses
     *            Set of {@link Status} instances specifying the statuses of tasks to be returned. If an empty set is passed, the query will
     *            implicitly return tasks for all statuses.
     * @return Set of instances of {@link TaskAbstract} satisfying the input criteria.
     * @throws BPMException
     *             In case of any error
     */
    public Set<TaskAbstract> getTaskAbstractsByParent(URI processInstanceId, Set<Status> statuses) throws BPMException;

    /**
     * Returns the set of instances of {@link TaskAbstract} for a given process instance. The result can be filtered by statuses and it
     * contains only the tasks the logged in user is potential or actual owner.
     * 
     * @param processInstanceId
     *            a process instance identifier.
     * @param statuses
     *            Set of {@link Status} instances specifying the statuses of tasks to be returned. If an empty set is passed, the query will
     *            implicitly return tasks for all statuses.
     * @return Set of instances of {@link TaskAbstract} satisfying the input criteria.
     * @throws BPMException
     *             In case of any error
     */
    public Set<TaskAbstract> getMyTaskAbstractsByParent(URI processInstanceId, Set<Status> statuses) throws BPMException;

    /**
     * Returns the set of instances of {@link TaskAbstract} for which the logged-in user have been substituted to work for at least one
     * other user at the moment.
     * <p>
     * Allows also to apply parameters to sort the result and parameters to specify the exact chunk to be returned. This can be used to
     * provide paging for the returned tasks.
     * </p>
     * <p>
     * Please note: When applying the firstResult parameter to {@link QueryResultParameters} the returned result is stateless. This means
     * the result may have skipped entries or contain entries which were returned by a previous query with a different firstResult.
     * </p>
     * 
     * @param statuses
     *            Set of {@link Status} instances specifying the statuses of tasks to be returned.
     * @param resultParameters
     *            Optional set of parameters to specify result size and offset. May be <code>null</code>
     * @param queryCriteria
     *            Optional set of {@link TaskAbstractQueryCriteria} instances specifying query parameters for sort and to get custom
     *            attribute(s) value as part of {@link TaskAbstract}. May be <code>null</code>. For sorting, see
     *            {@link TaskAbstractSortCriteria} for the supported attributes to sort on. To get custom attribute(s) value of
     *            {@link TaskAbstract}, use an instance of {@link TaskAbstractCustomAttributesCriteria}.
     * @param substitutedUsers
     *            list of users that should be checked for substitution
     * @return Set of instances of {@link TaskAbstract}
     * @throws BPMException
     *             In case of any error
     */
    public Set<TaskAbstract> getTaskAbstractsForMySubstitutedUsers(IUser[] substitutedUsers, Set<Status> statuses,
            QueryResultParameters resultParameters, TaskAbstractQueryCriteria... queryCriteria) throws BPMException;

    /**
     * Returns the set of instances of {@link TaskAbstract} for which the logged-in user have been substituted to work for at least one
     * other user at the moment.
     * <p>
     * Allows also to apply parameters to sort the result and parameters to specify the exact chunk to be returned. This can be used to
     * provide paging for the returned tasks.
     * </p>
     * <p>
     * Please note: When applying the firstResult parameter to {@link QueryResultParameters} the returned result is stateless. This means
     * the result may have skipped entries or contain entries which were returned by a previous query with a different firstResult.
     * </p>
     * 
     * @param statuses
     *            Set of {@link Status} instances specifying the statuses of tasks to be returned.
     * @param resultParameters
     *            Optional set of parameters to specify result size and offset. May be <code>null</code>
     * @param queryCriteria
     *            Optional set of {@link TaskAbstractQueryCriteria} instances specifying query parameters for sort and to get custom
     *            attribute(s) value as part of {@link TaskAbstract}. May be <code>null</code>. For sorting, see
     *            {@link TaskAbstractSortCriteria} for the supported attributes to sort on. To get custom attribute(s) value of
     *            {@link TaskAbstract}, use an instance of {@link TaskAbstractCustomAttributesCriteria}.
     * @return Set of instances of {@link TaskAbstract}
     * @throws BPMException
     *             In case of any error
     */
    public Set<TaskAbstract> getTaskAbstractsForAllMySubstitutedUsers(Set<Status> statuses, QueryResultParameters resultParameters,
            TaskAbstractQueryCriteria... queryCriteria) throws BPMException;

    /**
     * Returns the set of instances of {@link TaskAbstract} for which the logged-in user have been substituted to work for at least one
     * other user at the moment.
     * 
     * @param statuses
     *            Set of {@link Status} instances specifying the statuses of tasks to be returned.
     * @param substitutedUsers
     *            list of users that should be checked for substitution
     * @return Set of instances of {@link TaskAbstract}
     * @throws BPMException
     *             In case of any error
     */
    public Set<TaskAbstract> getTaskAbstractsForMySubstitutedUsers(IUser[] substitutedUsers, Set<Status> statuses) throws BPMException;

    /**
     * Returns the set of instances of {@link TaskAbstract} the currently logged-in user is eligible to work on, because they is the
     * substitute of at least one other user at the moment.
     * 
     * @param statuses
     *            Set of {@link Status} instances specifying the statuses of tasks to be returned.
     * @return Set of instances of {@link TaskAbstract}
     * @throws BPMException
     *             In case of any error
     */
    public Set<TaskAbstract> getTaskAbstractsForAllMySubstitutedUsers(Set<Status> statuses) throws BPMException;

    /**
     * Execution of the task fails and a fault is returned.
     * 
     * @param taskInstanceId
     *            task identifier
     * @param fault
     *            the {@link Fault} object representing the reason why the execution of the task has failed
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     */
    public void fail(URI taskInstanceId, Fault fault) throws BPMException;

    /**
     * Generates the URL pointing to the default Task Execution UI for the specified task instance id.<br>
     * The application property 'http.baseurl' will be used to determine the target server and port address.
     * 
     * @param taskInstanceId
     *            task identifier
     * @return the generated Task Execution UI URL
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     */
    public URL generateTaskExecutionUrl(URI taskInstanceId) throws BPMException;

    /**
     * <p>
     * Triggers the task action 'Release' (i.e. that the task is released by the actual owner and made available for all potential owners
     * again).
     * </p>
     * <p>
     * The implementation checks if the user that tries to release the task
     * </p>
     * <ul>
     * <li>is either the current actual owner and not one of the excluded owners</li>
     * <li>or is a Task Administrator</li>
     * </ul>
     * 
     * @param taskInstanceId
     *            the task that should be released
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalOperationException
     *             if the operation does not apply to the task type
     */
    public void release(URI taskInstanceId) throws BPMException;

    /**
     * Sets the priority of the given task to a new value NOTE: Priority VERY_LOW is not supported and will result in an
     * BPMIllegalArgumentException
     * 
     * @param taskInstanceId
     *            the task of which the priority should be changed
     * @param prioriy
     *            the new priority level
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid (e.g. if the priority is VERY_LOW)
     */
    public void setPriority(URI taskInstanceId, Priority prioriy) throws BPMException;

    /**
     * <p>
     * Triggers the 'Delegate' task action. Thereby, the delegating user is assigning the delegatee as the actual owner of this task. I.e.
     * that the task will be assigned after successfully delegating the task.<br>
     * The delegatee does not necessarily need to be a potential owner. If not so, the set of potential owners is enlarged with the
     * delegatee.
     * </p>
     * <p>
     * The implementation checks if:
     * </p>
     * <ul>
     * <li>the delegating user is the actual owner (in case the task has already been assigned before)</li>
     * <li>the delegating user is a potential owner</li>
     * <li>neither the delegating user nor the delegatee is one of the excluded owners</li>
     * </ul>
     * 
     * @param taskInstanceId
     *            the task that is to be delegated
     * @param newOwner
     *            the user the task is delegated to
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalOperationException
     *             if the operation does not apply to the task type
     */
    public void delegate(URI taskInstanceId, IUser newOwner) throws BPMException;

    /**
     * Triggers the 'Nominate' task action. Thereby, the administrator is assigning the nominated user as the actual owner of this task.
     * I.e.&nbsp;that the task will be assigned after successfully nominating. The nominated user does not necessarily need to be a
     * potential owner. If not so, the set of potential owners is enlarged with the nominated user.
     * 
     * @param newOwner
     *            the user the task is nominated to
     * @param taskInstanceId
     *            the task that is to be nominated
     * @throws BPMIllegalAccessException
     *             if the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             if an argument is invalid
     * @throws BPMIllegalOperationException
     *             if the operation does not apply to the task type
     */
    public void nominate(URI taskInstanceId, IUser newOwner) throws BPMException;

    /**
     * Returns amount of all tasks, which are directly visible for the currently logged-in user (substitution rules will NOT be considered).
     * 
     * @param statuses
     *            Set of {@link Status} instances specifying the statuses of tasks to be considered.<br>
     *            Following statuses are not supported: Status.FAILED and Status.SUSPENDED.
     * @return task count
     * @throws BPMException
     *             In case of any error
     */
    public int getMyTaskCount(Set<Status> statuses) throws BPMException;

    /**
     * Returns the amount of tasks, which are visible for the currently logged-in user because of substitution rules (directly visible tasks
     * will NOT be considered).
     * 
     * @param substitutedUsers
     *            list of users that should be checked for substitution
     * @param statuses
     *            Set of {@link Status} instances specifying the statuses of tasks to be considered.<br>
     *            Following statuses are not supported: Status.FAILED and Status.SUSPENDED.
     * @return task count
     * @throws BPMException
     *             In case of any error
     */
    public int getTaskCountForMySubstitutedUsers(IUser[] substitutedUsers, Set<Status> statuses) throws BPMException;

    /**
     * Returns the amount of tasks, which are visible for the currently logged-in user because of substitution rules (directly visible tasks
     * will NOT be considered).
     * 
     * @param statuses
     *            Set of {@link Status} instances specifying the statuses of tasks to be considered.<br>
     *            Following statuses are not supported: Status.FAILED and Status.SUSPENDED.
     * @return task count
     * @throws BPMException
     *             In case of any error
     */
    public int getTaskCountForAllMySubstitutedUsers(Set<Status> statuses) throws BPMException;

    /**
     * For each TaskModelId it returns per requested user the amount of owned tasks. Only tasks are considered for which the currently
     * logged-on user is task administrator or process administrator of the parent process.
     * <p>
     * Example Usage : There are two users user1 and user2 who are working on task models, DefaultTask and TestTask, as follows:<br>
     * user1 is working on two instances of DefaultTask and one instance of TestTask.<br>
     * user2 is working on three instances of TestTask.
     * 
     * <pre>
     * 
     * IUser[] users = { user1, user2 };
     * 
     * TaskAbstractStatusCriteria includeReadyTask = new TaskAbstractStatusCriteria(Status.READY);
     * TaskAbstractStatusCriteria includeInProgressTask = new TaskAbstractStatusCriteria(Status.IN_PROGRESS);
     * 
     * TaskAbstractModelCriteria includeDefaultTask = new TaskAbstractModelCriteria(taskModelIdForDefaultTask);
     * TaskAbstractModelCriteria includeTestTask = new TaskAbstractModelCriteria(taskModelIdForTestTask);
     * 
     * TaskInstanceManager taskInstanceManager = BPMFactory.getTaskInstanceManager();
     * taskInstanceManger.getTaskCountPerTaskModel(users, includeReadyTask, includeInProgressTask, includeDefaultTask, includeTestTask);
     * 
     * </pre>
     * 
     * It will return a map as follows:
     * <table border="2" summary="Returned values">
     * <tr>
     * <th>TaskModelId</th>
     * <th>User</th>
     * <th>Count</th>
     * </tr>
     * <tr>
     * <td>defaultTaskModelId</td>
     * <td>user1</td>
     * <td>2</td>
     * </tr>
     * <tr>
     * <td rowspan="2">testTaskModelId</td>
     * <td>user1</td>
     * <td>1</td>
     * </tr>
     * <tr>
     * <td>user2</td>
     * <td>3</td>
     * </tr>
     * </table>
     * 
     * @param users
     *            List of {@link IUser} for whom the count is required. This parameter must not be null.
     * @param queryCriteria
     *            Optional set of {@link TaskAbstractQueryCriteria} instances specifying query parameters to specify the statuses and to
     *            specify the task model the returned tasks should be in . May be <code>null</code>. If null is provided specifically, empty
     *            sets of lifecycle and model Id are passed. For this API the supported query criteria are TaskAbstractStatusCriteria and
     *            TaskAbstractModelCriteria.To specify statuses, use an instance of {@link TaskAbstractStatusCriteria}. For specifying the
     *            task model id use an instance of {@link TaskAbstractModelCriteria}.
     * @return For each TaskModelId it returns per requested user the amount of owned tasks. It returns an empty map if the user does not
     *         own tasks for the given task model id.
     * @throws BPMIllegalArgumentException
     *             if the passed <code>users</code> is null or empty.<br>
     *             if any other query criteria is passed apart from TaskAbstractStatusCriteria or TaskAbstractModelCriteria.
     */
    public Map<URI, Map<IUser, Integer>> getTaskCountPerTaskModel(IUser[] users, TaskAbstractQueryCriteria... queryCriteria)
            throws BPMException;

    /**
     * Returns a list of {@link Note}s visible to the {@link TaskAbstract}
     * 
     * @param taskInstanceId
     *            {@link URI} of a {@link TaskAbstract}
     * @return A list of {@link Note}s that are visible to the {@link TaskAbstract}
     * @throws BPMIllegalAccessException
     *             If the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             If task instance id is invalid
     */
    public List<Note> getNotes(URI taskInstanceId) throws BPMException;

    /**
     * Returns a {@link Note} identified by the given {@link URI}
     * 
     * @param noteId
     *            {@link URI} that uniquely identifies the {@link Note}
     * @return A {@link Note} identified by the given {@link URI}
     * @throws BPMIllegalArgumentException
     *             If note id is invalid or if the user has no permission for the task that
     *             the note is attached to
     */
    public Note getNote(URI noteId) throws BPMException;

    /**
     * Returns a unique identifier of the newly added {@link Note} <BR>
     * Adds a {@link Note} to the given {@link TaskAbstract} and returns a unique identifier of the {@link Note}.
     * 
     * @param taskInstanceId
     *            {@link URI} of a {@link TaskAbstract} to add the {@link Note}
     * @param content
     *            The content of the {@link Note} to add as {@link String}
     * @param isLocal
     *            This parameter defines the visibility of the {@link Note} in the parent {@link ProcessInstance}. <BR>
     *            A value true sets the visibility of the {@link Note} as local to the {@link TaskAbstract} where as a value false sets the
     *            visibility of the {@link Note} as visible to all {@link TaskAbstract}s of the parent {@link ProcessInstance}.
     * @return A unique identifier of the newly added {@link Note}
     * @throws BPMIllegalAccessException
     *             If the user is not authorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             If task instance id is invalid
     */
    public URI addNote(URI taskInstanceId, String content, boolean isLocal) throws BPMException;

    /**
     * Returns a list of {@link TaskAbstract}s either owned or substituted by the logged in user as specified by the given criteria.
     * <p>
     * An invoker of the method can influence the resulting list by providing a variable argument list of type
     * {@link TaskAbstractFetchCriteria}:
     * </p>
     * <table border="1" summary="Overview on different types of criteria">
     * <tr>
     * <th>{@link TaskAbstractFetchCriteria}</th>
     * <th>Explanation</th>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractOwnerCriteria}</td>
     * <td><b>Task Ownership:</b> If specified, this method returns {@link TaskAbstract}s for which the logged in user is owner for. Cannot
     * be used in conjunction with {@link TaskAbstractSubstitutionCriteria}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractSubstitutionCriteria}</td>
     * <td><b>Task Substitution:</b> If specified, this method returns {@link TaskAbstract}s for which the logged in user is a substitute
     * for. Cannot be used in conjunction with {@link TaskAbstractOwnerCriteria}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterCriteria}</td>
     * <td><b>Filtering:</b> To filter for particular attributes of a {@link TaskAbstract}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractCustomAttributesFilterCriteria}</td>
     * <td><b>Filtering:</b> To filter {@link TaskAbstract}s based on custom attributes. In order to distinguish whether filtering should
     * consider either exact value match or value ranges, there are two different implementations:
     * {@link TaskAbstractCustomAttributesValueFilterCriteria} and {@link TaskAbstractCustomAttributesRangeFilterCriteria}.</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractCustomAttributesOrFilterCriteria}</td>
     * <td><b>Filtering:</b> To filter {@link TaskAbstract}s based on custom attributes with 'OR' logic. If used, no other instance of {@link TaskAbstractCustomAttributesFilterCriteria} is allowed.</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractSortCriteria}</td>
     * <td><b>Sorting:</b> To sort the result</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractCustomAttributesCriteria}</td>
     * <td><b>Custom Attributes:</b> To get the value of custom attribute(s) of the {@link TaskAbstract}</td>
     * </tr>
     * </table>
     * 
     * @param resultParameters
     *            Optional parameters to specify the result size and offset. <code>null</code> returns the full list.
     * @param fetchCriteria
     *            Variable argument list of type {@link TaskAbstractFetchCriteria} specifying the criteria for fetching the results as
     *            described in the table above.
     * @return A list of instances of {@link TaskAbstract} as returned by the underlying query.
     * @throws BPMIllegalArgumentException
     *             In case the usage of the parameters of this method is incorrect. Refer to the Javadoc of the provided arguments.
     * @throws BPMException
     *             In case of any technical issue.
     */
    public List<TaskAbstract> getTaskAbstracts(QueryResultParameters resultParameters, TaskAbstractFetchCriteria... fetchCriteria)
            throws BPMException;
    
    /**
     * Returns a list of {@link TaskAbstract}s either owned or substituted by the logged in user as specified by the given criteria and specified language.
     * <p>
     * An invoker of the method can influence the resulting list by providing a variable argument list of type
     * {@link TaskAbstractFetchCriteria}:
     * </p>
     * <table border="1" summary="Overview on different types of criteria">
     * <tr>
     * <th>{@link TaskAbstractFetchCriteria}</th>
     * <th>Explanation</th>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractOwnerCriteria}</td>
     * <td><b>Task Ownership:</b> If specified, this method returns {@link TaskAbstract}s for which the logged in user is owner for. Cannot
     * be used in conjunction with {@link TaskAbstractSubstitutionCriteria}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractSubstitutionCriteria}</td>
     * <td><b>Task Substitution:</b> If specified, this method returns {@link TaskAbstract}s for which the logged in user is a substitute
     * for. Cannot be used in conjunction with {@link TaskAbstractOwnerCriteria}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractFilterCriteria}</td>
     * <td><b>Filtering:</b> To filter for particular attributes of a {@link TaskAbstract}</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractCustomAttributesFilterCriteria}</td>
     * <td><b>Filtering:</b> To filter {@link TaskAbstract}s based on custom attributes. In order to distinguish whether filtering should
     * consider either exact value match or value ranges, there are two different implementations:
     * {@link TaskAbstractCustomAttributesValueFilterCriteria} and {@link TaskAbstractCustomAttributesRangeFilterCriteria}.</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractCustomAttributesOrFilterCriteria}</td>
     * <td><b>Filtering:</b> To filter {@link TaskAbstract}s based on custom attributes with 'OR' logic. If used, no other instance of {@link TaskAbstractCustomAttributesFilterCriteria} is allowed.</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractSortCriteria}</td>
     * <td><b>Sorting:</b> To sort the result</td>
     * </tr>
     * <tr>
     * <td>{@link TaskAbstractCustomAttributesCriteria}</td>
     * <td><b>Custom Attributes:</b> To get the value of custom attribute(s) of the {@link TaskAbstract}</td>
     * </tr>
     * </table>
     * 
     * @param resultParameters
     *            Optional parameters to specify the result size and offset. <code>null</code> returns the full list.
     * @param language
     *            parameter of type {@link String} specifying the locale of the fetched results.
     * @param fetchCriteria
     *            Variable argument list of type {@link TaskAbstractFetchCriteria} specifying the criteria for fetching the results as
     *            described in the table above.
     * @return A list of instances of {@link TaskAbstract} as returned by the underlying query.
     * @throws BPMIllegalArgumentException
     *             In case the usage of the parameters of this method is incorrect. Refer to the Javadoc of the provided arguments.
     * @throws BPMException
     *             In case of any technical issue.
     */
    public List<TaskAbstract> getTaskAbstracts(QueryResultParameters resultParameters, String language, TaskAbstractFetchCriteria... fetchCriteria)
            throws BPMException;

    /**
     * Returns a list of {@link Attachment}s visible to the {@link TaskAbstract} and its parent {@link ProcessInstance}
     * 
     * @param taskInstanceId
     *            {@link URI} of a {@link TaskAbstract}
     * @return A list of {@link Attachment}s that are visible to the {@link TaskAbstract} and its parent {@link ProcessInstance}
     * @throws BPMIllegalAccessException
     *             If the user is unauthorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             If task instance id is invalid
     */
    public List<Attachment> getAttachments(URI taskInstanceId) throws BPMException;

    /**
     * Returns an {@link Attachment} identified by the given {@link URI}conforming following conditions
     * <ul>
     * <li>If attachment is local to the task instance, then taskInstanceId should be of same task to which attachment belongs to
     * <li>If attachment is at process instance level then taskInstanceId and attachmentId must belong to same process instance
     * <li>Logged on user should have access to task for which taskInstanceId has been passed
     * </ul>
     * 
     * @param taskInstanceId
     *            {@link URI} of a {@link TaskAbstract}
     * @param attachmentId
     *            {@link URI} that uniquely identifies the {@link Attachment}
     * @return An {@link Attachment} identified by the given {@link URI}
     * @throws BPMIllegalAccessException
     *             If the user is unauthorized to perform the operation
     * @throws BPMIllegalArgumentException
     *             If attachment id is invalid
     */
    public Attachment getAttachment(URI taskInstanceId, URI attachmentId) throws BPMException;
}
