package com.sap.bpm.api;

/**
 * Optional set of query parameters used within certain API methods which e.g. allow to set the index of the first result or the maximum
 * number of results which are returned.
 * 
 * @sap.ApiForReference
 */
public final class QueryResultParameters {

    private Integer firstResult;
    private Integer maxResults;

    public QueryResultParameters() {}

    public QueryResultParameters(Integer firstResult, Integer maxResults) {
        super();
        setFirstResult(firstResult);
        setMaxResults(maxResults);
    }

    /**
     * Returns the index (starting with 0) of the first result which may be fetched by the JDBC call. May return <code>null</code>, which
     * means that no start index shall be used
     * 
     * @return the index of the first result or <code>null</code>
     */
    public Integer getFirstResult() {
        return firstResult;
    }

    /**
     * Sets the index (starting with 0) of the first result which may be fetched by the JDBC call. May be <code>null</code>, which means
     * that no start index shall be used
     * 
     * @param startPosition
     *            The index of the first result or <code>null</code>
     */
    public void setFirstResult(Integer startPosition) {
        if (startPosition != null && startPosition < 0) {
            throw new IllegalArgumentException("FirstResult parameter was set \"" + startPosition + "\" but a value >= 0 is required ");
        }
        this.firstResult = startPosition;
    }

    /**
     * Returns the maximum number of results which shall be returned by the query. May return <code>null</code>, which means the number of
     * results shall not be limited
     * 
     * @return The number of results which shall be returned or <code>null</code> in case the number of results is not limited
     */
    public Integer getMaxResults() {
        return maxResults;
    }

    /**
     * Sets the maximum number of results which shall be returned by the query. May be <code>null</code>, which means the number of results
     * shall not be limited
     * 
     * @param maxResults
     *            The number of results which shall be returned or <code>null</code> in case the number of results is not limited
     * @throws IllegalArgumentException
     *             in case of values &lt; 1
     */
    public void setMaxResults(Integer maxResults) throws IllegalArgumentException {
        if (maxResults != null && maxResults < 1) {
            throw new IllegalArgumentException("MaxResults parameter was set \"" + maxResults + "\" but a value >= 1 is required ");
        }
        this.maxResults = maxResults;
    }

    public String toString() {
        return "SQLTemplateParameters [maxResults=" + maxResults + ", firstResult=" + firstResult + "]";
    }

}
