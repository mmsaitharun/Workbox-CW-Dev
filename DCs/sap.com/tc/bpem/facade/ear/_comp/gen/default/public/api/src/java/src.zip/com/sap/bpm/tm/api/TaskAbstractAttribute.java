package com.sap.bpm.tm.api;


/**
 * Attributes of an {@link TaskAbstract} which can be sorted on.
 * 
 * @see TaskAbstractQueryCriteria
 * @see TaskInstanceManager#getMyTaskAbstracts(java.util.Set, com.sap.bpm.api.QueryResultParameters, TaskAbstractQueryCriteria...)
 * @see TaskAbstract
 */
public enum TaskAbstractAttribute {
	
//	/**
//	 * See {@link TaskAbstract#getTaskType()}
//	 */
//	TASK_TYPE,
//	
//	/**
//	 * See {@link TaskAbstract#getPresentationName()}
//	 */
//	NAME,
	
	/**
	 * See {@link TaskAbstract#getStatus()}
	 */
	STATUS,

	/**
	 * See {@link TaskAbstract#getPriority()}
	 */
	PRIORITY,
	
	/**
	 * See {@link TaskAbstract#getCreatedTime()}
	 */
	CREATED_TIME,
	
	/**
	 * See {@link TaskAbstract#getActivationTime()}
	 */
	ACTIVATION_TIME, 

	/**
	 * See {@link TaskAbstract#getExpirationTime()}
	 */
	EXPIRATION_TIME,	

	/**
	 * See {@link TaskAbstract#getCompleteByTime()}
	 */
	COMPLETE_BY_TIME,
	
	/**
	 * See {@link TaskAbstract#getCompletedTime()}
	 */
	COMPLETED_TIME,
	
	/**
	 * See {@link TaskAbstract#getStartByTime()}
	 */
	START_BY_TIME,
	
	/**
	 * See {@link TaskAbstract#isEscalated()}
	 */
	IS_ESCALATED,
	
	/**
	 * See {@link TaskAbstract#getId()}
	 */
	ID, 

}
