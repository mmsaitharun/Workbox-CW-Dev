package com.sap.bpm.tm.api;

import com.sap.bpm.exception.api.BPMIllegalArgumentException;

/**
 * Descriptor to specify the sort criteria for task abstract queries.
 * 
 * @see TaskAbstractAttribute
 */
public final class TaskAbstractSortCriteria implements TaskAbstractQueryCriteria, TaskAbstractFetchCriteria {

    private final TaskAbstractAttribute attribute;
    private final boolean isAscending;

    /**
     * Sort column is determined by a {@link TaskAbstractAttribute} value
     * 
     * @param attributeName
     *            - must not be <code>null</code>.
     * @param isAscending
     *            true in case the sort order shall be ascending
     */
    public TaskAbstractSortCriteria(TaskAbstractAttribute attributeName, boolean isAscending) {
        if (attributeName == null) {
            throw new BPMIllegalArgumentException("Value for 'attributeName' parameter must not be null.");
        }
        this.attribute = attributeName;
        this.isAscending = isAscending;
    }

    /**
     * Returns the attribute which is used to sort the result
     * 
     * @return the name as String
     */
    public TaskAbstractAttribute getAttribute() {
        return attribute;
    }

    /**
     * Sort order ascending or descending
     * 
     * @return true if ascending sort order or false for descending
     */
    public boolean isAscending() {
        return isAscending;
    }

    @Override
    public String toString() {
        return String.format("TaskAbstractSortCriteria [attribute=%s, isAscending=%s]", attribute, isAscending);
    }

}
