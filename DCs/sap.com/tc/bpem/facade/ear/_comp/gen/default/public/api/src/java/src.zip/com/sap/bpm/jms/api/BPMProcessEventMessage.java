package com.sap.bpm.jms.api;

import java.net.URI;

import com.sap.bpm.exception.api.BPMException;
import com.sap.bpm.pm.api.ProcessDefinition;
import com.sap.bpm.pm.api.ProcessInstance;
import com.sap.bpm.pm.api.ProcessInstanceManager;

/**
 * A set of getter methods specific to {@link BPMEventType}s related to processes. Instances of {@link BPMEventMessage} can be cast to this
 * interface in such cases:
 * 
 * <pre>
 * BPMProcessEventMessage bpmProcessEventMessage = null;
 * if (bpmEventMessage.getBPMEventType().isProcessEventType()) {
 *     bpmProcessEventMessage = (BPMProcessEventMessage) bpmEventMessage;
 *     // process message
 * }
 * </pre>
 * <p>
 * The entities related to {@link URI}s returned by {@link #getProcessDefinitionId()} and {@link #getProcessInstanceId()} can be retrieved
 * from {@link ProcessInstanceManager}.
 * </p>
 * 
 * @sap.ApiForReference
 */
public interface BPMProcessEventMessage extends BPMEventMessage {

    /**
     * Returns the ID of the related process definition
     * 
     * @return The {@link URI} of the {@link ProcessDefinition} related to the event
     * @throws BPMException
     *             In case of any error
     */
    public URI getProcessDefinitionId() throws BPMException;

    /**
     * Returns the ID of the related process instance
     * 
     * @return The {@link URI} of the {@link ProcessInstance} related to the event
     * @throws BPMException
     *             In case of any error
     */
    public URI getProcessInstanceId() throws BPMException;

}
