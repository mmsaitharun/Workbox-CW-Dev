package com.sap.bpm.pm.api;

/**
 * Enumerates filtering operators for {@link ProcessInstanceFilterCriteria}.
 */
public enum ProcessInstanceFilterOperator {
    /**
     * Indicates that for a {@link ProcessInstance} to satisfy the filtering criteria its property value should be equal to the value
     * specified in the filtering criteria for this property.
     */
    EQUALS,

    /**
     * Indicates that for a {@link ProcessInstance} to satisfy the filtering criteria its property value should not be equal to the value
     * specified in the filtering criteria for this property.
     */
    NOT_EQUALS,

    /**
     * Indicates that for a {@link ProcessInstance} to satisfy the filtering criteria its property value should be greater than or equal to
     * the value specified in the filtering criteria for this property.
     */
    FROM,

    /**
     * Indicates that for a {@link ProcessInstance} to satisfy the filtering criteria its property value should be less than or equal to the
     * value specified in the filtering criteria for this property.
     */
    TO
}
