package com.incture.pmc.poadapter.dto;

import java.util.HashMap;
import java.util.Map;

public class CustomAttributeDto {

	/**
	 * 
	 */
	private Map<String, Object> customAttribute = new HashMap<String, Object>();

	public Map<String, Object> getCustomAttribute() {
		return customAttribute;
	}

	public void setCustomAttribute(Map<String, Object> customAttribute) {
		this.customAttribute = customAttribute;
	}

}
