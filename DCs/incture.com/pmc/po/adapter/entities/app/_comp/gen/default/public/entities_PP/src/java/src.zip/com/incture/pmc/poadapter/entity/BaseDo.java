package com.incture.pmc.poadapter.entity;

/**
 * Base Do Interface
 * 
 * @author INC00400
 * @version 1.0
 * @since 2017-05-09
 */
public interface BaseDo {
	public Object getPrimaryKey();
}
