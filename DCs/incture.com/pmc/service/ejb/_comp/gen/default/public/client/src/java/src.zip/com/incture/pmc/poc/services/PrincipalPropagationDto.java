//package com.incture.pmc.poc.services;
//
//import javax.xml.bind.annotation.XmlRootElement;
//
//@XmlRootElement
//public class PrincipalPropagationDto {
//	private String EmployeeId;
//	private String City;
//	private String FirstName;
//	private String LastName;
//
//	@Override
//	public String toString() {
//		return "PrincipalPropagationDto [EmployeeId=" + EmployeeId + ", City=" + City + ", FirstName=" + FirstName + ", LastName=" + LastName + "]";
//	}
//
//	public String getEmployeeId() {
//		return EmployeeId;
//	}
//
//	public void setEmployeeId(String employeeId) {
//		EmployeeId = employeeId;
//	}
//
//	public String getCity() {
//		return City;
//	}
//
//	public void setCity(String city) {
//		City = city;
//	}
//
//	public String getFirstName() {
//		return FirstName;
//	}
//
//	public void setFirstName(String firstName) {
//		FirstName = firstName;
//	}
//
//	public String getLastName() {
//		return LastName;
//	}
//
//	public void setLastName(String lastName) {
//		LastName = lastName;
//	}
//
//}
