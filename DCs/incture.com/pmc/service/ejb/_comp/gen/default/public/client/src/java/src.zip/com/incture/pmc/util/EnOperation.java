package com.incture.pmc.util;

public enum EnOperation {
	CREATE, RETRIEVE, UPDATE, DELETE;
}