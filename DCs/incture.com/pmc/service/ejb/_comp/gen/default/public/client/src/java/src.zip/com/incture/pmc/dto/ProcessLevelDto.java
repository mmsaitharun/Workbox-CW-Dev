package com.incture.pmc.dto;

public class ProcessLevelDto {

}
