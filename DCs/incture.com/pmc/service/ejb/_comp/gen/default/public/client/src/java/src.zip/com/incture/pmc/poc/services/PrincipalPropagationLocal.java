//package com.incture.pmc.poc.services;
//
//import javax.ejb.Local;
//
//@Local
//public interface PrincipalPropagationLocal {
//
//	void doPost(PrincipalPropagationDto propagationDto);
//
//}
